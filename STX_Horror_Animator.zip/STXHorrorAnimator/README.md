# STX Horror Animator

Offline **2D / 2.5D character animation studio for Android** (Kotlin · Jetpack Compose · no servers, no API keys, no paid libraries).
It animates imported PNG/JPG/WEBP characters with **bones, IK, procedural motion presets, face/mouth/blink systems, camera + parallax,
weather particles, lights, audio and lip-sync**, and renders the real animation to **MP4**.
It is not a slideshow maker: everything is evaluated per frame from a skeleton, procedural motion and keyframes.

## Build

### A) GitHub Actions (no setup)
1. Push this folder to a GitHub repository.
2. The included workflow `.github/workflows/build-apk.yml` builds on every push (or run it manually: Actions → Build APK → Run workflow) → download the `app-debug-apk` artifact.

### B) Android Studio
Open the folder (Hedgehog or newer, JDK 17) → *Run*. Android Studio creates the Gradle wrapper automatically.

### C) Command line
```
gradle wrapper --gradle-version 8.9      # once, creates ./gradlew
./gradlew :app:assembleDebug             # APK: app/build/outputs/apk/debug/
```
Requirements: JDK 17, Android SDK 34 (platforms;android-34, build-tools 34). minSdk 26 (Android 8.0), target 34.

## First run
Tap **▶ Sample horror scene** on the home screen. It generates (offline, from code) the character art, a rigged skeleton, sound effects and three scenes:
1. *Walk to the gate* – procedural walk cycle with travel, blinking, idle breathing, looking around, parallax camera push-in, rain, fog, wind-driven hair/scarf, flashlight attached to the hand bone, lantern, keyframed lightning + thunder.
2. *He speaks* – voice audio drives mouth keyframes (lip-sync), gesturing, brows, pointing, fear reaction, heartbeat, handheld camera + depth of field.
3. *The ghost* – ghost transparency/distortion, glitch, chromatic aberration, red flash, blood-tint, moving shadows, shake + fast zoom.

Press ▶ – the characters move continuously; scrub the timeline to see the keyframes and preset clips; open **Export** to render an MP4.

## Screens / workflow
| Area | Where | What it does |
|---|---|---|
| Home / Projects / New project / Settings | start screen | create (16:9, 9:16, 1:1, 4:3; 24/25/30/60 fps), rename, duplicate, delete, crash-recovery prompt |
| Assets | tab | import PNG/JPG/WEBP, layer order, opacity, blend modes, crop, polygon mask, anchor/pivot, parallax depth, ghost flag, mesh sway (hair/cloth), face roles, **Cut into parts** (polygon tool + auto humanoid split) |
| Character Rig | tab | humanoid template (front/side), add/delete/re-parent bones, joint drag, pivots, IK chains + IK drag handle, constraints, secondary motion, **auto-rig from named parts**, mirror L↔R (bones and images), pose copy/paste + library |
| Animation / Timeline | tab + bottom timeline | keyframes for position, rotation, scale, opacity, pivot, skew, camera, effects, bones, face; ease in/out/in-out/bezier/custom/bounce/elastic/hold; copy/paste, duplicate range, loop, reverse, speed; 14 editable procedural presets; bake presets to keyframes |
| Face | tab | eyes open/half/closed, 5 brows, 6 mouths, head look L/R/U/D, expressions, auto-blink, talking, expression library |
| Camera | tab | zoom, pan, tilt, roll, shake, handheld, follow/track, focus + depth of field, parallax strength, 7 presets (Horror Zoom, Slow Push In, Fast Zoom, Shake, Heartbeat, Reveal, Dramatic Pull Back) |
| Effects | tab | rain (light/normal/heavy), snow, fog, smoke, dust, wind, lightning, vignette, grain, chromatic aberration, glitch, motion blur, glow, ground shadow, grading, darkness, red flash, flicker, blood-tint overlay (non-graphic), ghost, ghost distortion, moving shadows + lights: flashlight, lantern, headlights, bulb, candle, spot |
| Audio | tab | MP3/WAV/M4A import, trim/sync/fades/loop, voice/dialogue/music/SFX/ambience buses, master/music/voice/SFX volumes, built-in generated horror SFX, **voice → lip-sync keyframes** |
| Scene | tab | multiple scenes, duration, background, **library** (characters, rigs, poses, animations, expressions, props, backgrounds, effects reusable across projects) |
| Export | tab | MP4 (H.264 + AAC) 1080p/720p/480p, 24/25/30/60 fps, 4 quality levels, current scene or whole project |

Touch: one finger select/move · pinch zoom canvas · two-finger pan · two-finger twist rotates the selected layer (⟳ tool) · pinch scales it (⤢ tool) · long press = context menu · double-tap = reset view · bone handles are 46 px touch targets.

## Architecture
```
model/    Project, Scene, Layer, Bone, Character, Track/Key, ProcClip, Effect, Light, AudioClip + JSON (reliable project format)
engine/   Anim (easing, keys) · Presets (procedural motion) · Rig (FK, CCD IK, constraints, secondary motion, mirror, auto-rig)
          Renderer (one renderer for preview AND export) · Fx (weather, lightning, post)
data/     ProjectRepo (atomic saves, autosave, recovery, library) · BitmapCache (sample-size decoding, LRU) · PartCutter
audio/    decoder, lip-sync, procedural SFX, mixer, live preview
export/   MediaCodec H.264/AAC exporter
ui/       Compose UI, EditorState (undo/redo, playback, autosave), StageView (touch canvas), Timeline
sample/   procedural sample project
```
* **Project format**: `projects/<id>/project.json` + `assets/` (JSON, atomic writes). Autosave every 8 s to `autosave.json`; newer autosave is offered for recovery after a crash. Undo/redo = 60 snapshots.
* **Deterministic evaluation**: every frame is a pure function of time (rain, noise, shake, blink timing…), so scrubbing, preview and export match exactly.
* **Performance**: images are decoded with `inSampleSize` to the needed size (640 / 1100 / 2048 px), LRU cache = ¼ of the heap, low-preview mode renders at reduced resolution, export uses full quality.

## Honest notes on "closest real alternative"
* **Full-image animation**: automatic segmentation of arbitrary art is not possible offline without ML. The app provides the polygon *Cut into parts* tool plus an *Auto-split humanoid* helper based on the visible silhouette; you adjust regions by cutting them manually. Cut areas can be erased from the original, but no inpainting is done behind moved limbs (draw/import a body layer that is complete underneath).
* **Mesh deformation**: hair/scarf/cloth use a vertex-mesh sway (secondary motion + wind + character-velocity drag) and ghosts use a wave mesh; limbs are rigid bone-attached images (no skinning weights).
* **Lighting** reveals the scene through a darkness mask and adds coloured additive glow; there are no normal-map shaded lights.
* **Export** renders frames on the CPU into H.264 via MediaCodec (slower than GPU, but works on every device). 1080p/60 on a phone can take minutes per scene.
* **Voice**: lip-sync is amplitude based (closed/small/medium/wide). The sample voice is a synthetic tone babble – import your own recording for real use.
* Sound generated in-app is simple synthesis; import real SFX for production.

## Licence
Apache-2.0. Uses only AndroidX / Jetpack Compose / Kotlin coroutines.
