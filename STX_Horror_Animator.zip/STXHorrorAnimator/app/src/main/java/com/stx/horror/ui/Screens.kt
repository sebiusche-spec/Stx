package com.stx.horror.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.stx.horror.data.ProjectRepo
import com.stx.horror.data.ProjectInfo
import com.stx.horror.prefs
import com.stx.horror.sample.SampleProject
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date

fun openProject(repo: ProjectRepo, ctx: android.content.Context, id: String, recover: Boolean): EditorState? {
    val p = repo.load(id, recover) ?: return null
    val st = EditorState(ctx, repo, p)
    val pr = ctx.prefs()
    st.lowPreview = pr.getBoolean("lowPreview", true); st.loopPlay = pr.getBoolean("loop", true); st.showBones = pr.getBoolean("bones", true)
    st.selChar = p.scenes.firstOrNull()?.characters?.firstOrNull()?.id ?: ""
    return st
}

@Composable
fun HomeScreen(repo: ProjectRepo, onOpen: (EditorState) -> Unit, onSettings: () -> Unit) {
    val ctx = LocalContext.current
    var list by remember { mutableStateOf(repo.list()) }
    var showNew by remember { mutableStateOf(false) }
    var recover by remember { mutableStateOf<ProjectInfo?>(null) }
    var menu by remember { mutableStateOf<ProjectInfo?>(null) }
    var rename by remember { mutableStateOf<ProjectInfo?>(null) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val crash = remember { File(ctx.filesDir, "last_crash.txt").exists() }

    fun open(info: ProjectInfo) { if (info.hasRecovery) recover = info else openProject(repo, ctx, info.id, false)?.let(onOpen) }

    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF14040A), C.Bg))).padding(16.dp)) {
        Text("STX", color = C.Red, fontSize = 38.sp, fontWeight = FontWeight.Black, letterSpacing = 6.sp)
        Text("HORROR ANIMATOR", color = C.Neon, fontSize = 15.sp, letterSpacing = 5.sp, fontWeight = FontWeight.Bold)
        Text("2D / 2.5D character animation studio · offline · open source", color = C.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp, bottom = 14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Neon("＋  New project", Modifier.weight(1f), C.Neon) { showNew = true }
            Neon(if (busy) "Building…" else "▶  Sample horror scene", Modifier.weight(1f), C.Red, enabled = !busy) {
                busy = true
                scope.launch {
                    val id = withContext(Dispatchers.Default) { SampleProject.create(ctx, repo) }
                    busy = false; list = repo.list()
                    openProject(repo, ctx, id, false)?.let(onOpen)
                }
            }
            Neon("⚙", color = C.Violet) { onSettings() }
        }
        if (crash) Text("The app closed unexpectedly last time. Your work is protected by autosave – open the project to recover it.", color = C.Amber, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.height(14.dp))
        Title("Projects")
        if (list.isEmpty()) Text("No projects yet. Create one or open the sample scene to see continuous character animation (walking, talking, blinking, rain, lightning, camera).", color = C.Muted, fontSize = 13.sp)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(list) { p ->
                Glass(Modifier.fillMaxWidth().clickable { open(p) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(p.name, color = C.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                            Text("${p.scenes} scene(s) · ${DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(p.modified))}" + if (p.hasRecovery) "  · unsaved changes found" else "", color = if (p.hasRecovery) C.Amber else C.Muted, fontSize = 11.sp)
                        }
                        Box {
                            Text("⋮", color = C.Text, fontSize = 22.sp, modifier = Modifier.clickable { menu = p }.padding(8.dp))
                            DropdownMenu(expanded = menu?.id == p.id, onDismissRequest = { menu = null }) {
                                DropdownMenuItem(text = { Text("Rename") }, onClick = { rename = p; menu = null })
                                DropdownMenuItem(text = { Text("Duplicate") }, onClick = { repo.duplicate(p.id); list = repo.list(); menu = null })
                                DropdownMenuItem(text = { Text("Delete") }, onClick = { repo.delete(p.id); list = repo.list(); menu = null })
                            }
                        }
                    }
                }
            }
        }
    }

    if (showNew) NewProjectDialog(onDismiss = { showNew = false }) { name, w, h, fps ->
        showNew = false
        val p = repo.create(name, w, h, fps); list = repo.list()
        openProject(repo, ctx, p.id, false)?.let(onOpen)
    }
    recover?.let { info ->
        AlertDialog(onDismissRequest = { recover = null }, title = { Text("Recover unsaved work?") },
            text = { Text("“${info.name}” has newer autosaved changes (the app may have closed unexpectedly).") },
            confirmButton = { TextButton({ recover = null; openProject(repo, ctx, info.id, true)?.let(onOpen) }) { Text("Recover") } },
            dismissButton = { TextButton({ recover = null; repo.discardAutosave(info.id); openProject(repo, ctx, info.id, false)?.let(onOpen) }) { Text("Discard") } })
    }
    rename?.let { info ->
        var n by remember { mutableStateOf(info.name) }
        AlertDialog(onDismissRequest = { rename = null }, title = { Text("Rename project") },
            text = { OutlinedTextField(n, { n = it }, singleLine = true) },
            confirmButton = { TextButton({ repo.rename(info.id, n); list = repo.list(); rename = null }) { Text("OK") } },
            dismissButton = { TextButton({ rename = null }) { Text("Cancel") } })
    }
}

@Composable
fun NewProjectDialog(onDismiss: () -> Unit, onCreate: (String, Int, Int, Int) -> Unit) {
    var name by remember { mutableStateOf("My Horror Short") }
    val aspects = listOf("16:9 landscape" to (1920 to 1080), "9:16 vertical" to (1080 to 1920), "1:1 square" to (1080 to 1080), "4:3" to (1440 to 1080))
    var a by remember { mutableStateOf(0) }; var fps by remember { mutableStateOf(30) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("New project") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Name") }, singleLine = true)
                Label("Format"); Row { aspects.forEachIndexed { i, x -> Tag(x.first, a == i) { a = i } } }
                Label("Frame rate"); Row { listOf(24, 25, 30, 60).forEach { Tag("$it fps", fps == it) { fps = it } } }
            }
        },
        confirmButton = { TextButton({ onCreate(name, aspects[a].second.first, aspects[a].second.second, fps) }) { Text("Create") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } })
}

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val pr = ctx.prefs()
    var low by remember { mutableStateOf(pr.getBoolean("lowPreview", true)) }
    var loop by remember { mutableStateOf(pr.getBoolean("loop", true)) }
    var bones by remember { mutableStateOf(pr.getBoolean("bones", true)) }
    var crash by remember { mutableStateOf(File(ctx.filesDir, "last_crash.txt").let { if (it.exists()) it.readText() else "" }) }
    Column(Modifier.fillMaxSize().background(C.Bg).padding(16.dp).verticalScroll(rememberScrollState())) {
        Row(verticalAlignment = Alignment.CenterVertically) { Neon("← Back") { onBack() }; Spacer(Modifier.width(12.dp)); Text("Settings", color = C.Text, fontSize = 22.sp, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(12.dp))
        Glass(Modifier.fillMaxWidth()) {
            Title("Editing")
            Toggle("Low preview quality while editing (faster, full quality is always used for export)", low) { low = it; pr.edit().putBoolean("lowPreview", it).apply() }
            Toggle("Loop playback", loop) { loop = it; pr.edit().putBoolean("loop", it).apply() }
            Toggle("Show bones on the stage", bones) { bones = it; pr.edit().putBoolean("bones", it).apply() }
        }
        Spacer(Modifier.height(10.dp))
        Glass(Modifier.fillMaxWidth()) {
            Title("About")
            Text("STX Horror Animator 1.0 – offline 2D/2.5D character animation. Open source (Apache-2.0). No accounts, no servers, no API keys. Autosave every 8 seconds with crash recovery.", color = C.Muted, fontSize = 12.sp)
        }
        if (crash.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            Glass(Modifier.fillMaxWidth()) {
                Title("Last crash log"); Text(crash.take(1500), color = C.Muted, fontSize = 10.sp)
                Neon("Clear log") { File(ctx.filesDir, "last_crash.txt").delete(); crash = "" }
            }
        }
    }
}
