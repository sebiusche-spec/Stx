package com.stx.horror.data

import android.graphics.*
import com.stx.horror.model.*
import kotlin.math.max
import kotlin.math.min

/**
 * Turns a single full character image into movable parts. The user (or the auto-split helper) defines
 * polygon regions on the image; every region is cut out into its own transparent PNG layer.
 */
object PartCutter {
    class Region(val label: String, val poly: FloatArray)   // polygon in source image pixels

    /** Cuts the polygon region out of the source bitmap. Returns bitmap (cropped to the polygon bounds) and its top-left in the source. */
    fun cut(src: Bitmap, poly: FloatArray, feather: Float = 1.5f): Pair<Bitmap, Point>? {
        if (poly.size < 6) return null
        var minX = Float.MAX_VALUE; var minY = Float.MAX_VALUE; var maxX = -Float.MAX_VALUE; var maxY = -Float.MAX_VALUE
        var i = 0
        while (i + 1 < poly.size) { minX = min(minX, poly[i]); maxX = max(maxX, poly[i]); minY = min(minY, poly[i + 1]); maxY = max(maxY, poly[i + 1]); i += 2 }
        val l = max(0, minX.toInt() - 1); val t = max(0, minY.toInt() - 1)
        val r = min(src.width, maxX.toInt() + 2); val b = min(src.height, maxY.toInt() + 2)
        if (r - l < 2 || b - t < 2) return null
        val out = Bitmap.createBitmap(r - l, b - t, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val path = Path(); path.moveTo(poly[0] - l, poly[1] - t)
        i = 2; while (i + 1 < poly.size) { path.lineTo(poly[i] - l, poly[i + 1] - t); i += 2 }; path.close()
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        c.drawPath(path, p)                                   // mask (alpha)
        p.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        c.drawBitmap(src, -l.toFloat(), -t.toFloat(), p)      // keep source colour only inside the mask
        if (feather > 0.5f) {
            // soften the cut edge slightly so the part blends in
            val soft = Paint(Paint.ANTI_ALIAS_FLAG); soft.style = Paint.Style.STROKE; soft.strokeWidth = feather
            soft.xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT); soft.color = Color.argb(70, 0, 0, 0); c.drawPath(path, soft)
        }
        return out to Point(l, t)
    }

    /** Removes (erases) the polygon area from a copy of the bitmap - used to cut limbs out of the body layer. */
    fun erase(src: Bitmap, polys: List<FloatArray>): Bitmap {
        val out = src.copy(Bitmap.Config.ARGB_8888, true)
        val c = Canvas(out)
        val p = Paint(Paint.ANTI_ALIAS_FLAG); p.xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        for (poly in polys) {
            if (poly.size < 6) continue
            val path = Path(); path.moveTo(poly[0], poly[1])
            var i = 2; while (i + 1 < poly.size) { path.lineTo(poly[i], poly[i + 1]); i += 2 }; path.close()
            c.drawPath(path, p)
        }
        return out
    }

    fun rect(l: Float, t: Float, r: Float, b: Float) = floatArrayOf(l, t, r, t, r, b, l, b)
    fun ellipse(cx: Float, cy: Float, rx: Float, ry: Float, n: Int = 20): FloatArray {
        val a = FloatArray(n * 2)
        for (i in 0 until n) { val ang = 2.0 * Math.PI * i / n; a[i * 2] = cx + (rx * Math.cos(ang)).toFloat(); a[i * 2 + 1] = cy + (ry * Math.sin(ang)).toFloat() }
        return a
    }

    /** Alpha bounding box of the image (the visible character). */
    fun alphaBounds(src: Bitmap): RectF {
        val w = src.width; val h = src.height
        var l = w; var t = h; var r = -1; var b = -1
        val row = IntArray(w)
        val stepY = max(1, h / 512)
        var y = 0
        while (y < h) {
            src.getPixels(row, 0, w, 0, y, w, 1)
            for (x in 0 until w) if ((row[x] ushr 24) > 24) { if (x < l) l = x; if (x > r) r = x; if (y < t) t = y; if (y > b) b = y }
            y += stepY
        }
        if (r < 0) return RectF(0f, 0f, w.toFloat(), h.toFloat())
        return RectF(l.toFloat(), t.toFloat(), r.toFloat(), b.toFloat())
    }

    /** Standard humanoid split using proportions of the visible character (front/side view). Regions overlap the body slightly. */
    fun humanoidRegions(bounds: RectF): List<Region> {
        val x0 = bounds.left; val y0 = bounds.top; val w = bounds.width(); val h = bounds.height(); val cx = x0 + w / 2f
        fun X(u: Float) = x0 + w * u
        fun Y(v: Float) = y0 + h * v
        return listOf(
            Region("Head", ellipse(cx, Y(0.085f), w * 0.2f, h * 0.095f)),
            Region("Hair", rect(X(0.28f), Y(0.0f), X(0.72f), Y(0.07f))),
            Region("Left Eye", ellipse(X(0.43f), Y(0.085f), w * 0.04f, h * 0.012f)),
            Region("Right Eye", ellipse(X(0.57f), Y(0.085f), w * 0.04f, h * 0.012f)),
            Region("Mouth", ellipse(cx, Y(0.125f), w * 0.06f, h * 0.012f)),
            Region("Torso", floatArrayOf(X(0.28f), Y(0.17f), X(0.72f), Y(0.17f), X(0.7f), Y(0.5f), X(0.3f), Y(0.5f))),
            Region("Left Upper Arm", rect(X(0.08f), Y(0.18f), X(0.3f), Y(0.36f))),
            Region("Left Forearm", rect(X(0.04f), Y(0.36f), X(0.26f), Y(0.52f))),
            Region("Left Hand", rect(X(0.0f), Y(0.52f), X(0.24f), Y(0.6f))),
            Region("Right Upper Arm", rect(X(0.7f), Y(0.18f), X(0.92f), Y(0.36f))),
            Region("Right Forearm", rect(X(0.74f), Y(0.36f), X(0.96f), Y(0.52f))),
            Region("Right Hand", rect(X(0.76f), Y(0.52f), X(1.0f), Y(0.6f))),
            Region("Left Thigh", rect(X(0.28f), Y(0.5f), X(0.5f), Y(0.74f))),
            Region("Left Lower Leg", rect(X(0.28f), Y(0.74f), X(0.5f), Y(0.94f))),
            Region("Left Foot", rect(X(0.24f), Y(0.94f), X(0.52f), Y(1.0f))),
            Region("Right Thigh", rect(X(0.5f), Y(0.5f), X(0.72f), Y(0.74f))),
            Region("Right Lower Leg", rect(X(0.5f), Y(0.74f), X(0.72f), Y(0.94f))),
            Region("Right Foot", rect(X(0.48f), Y(0.94f), X(0.76f), Y(1.0f)))
        )
    }
}
