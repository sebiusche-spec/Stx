package com.stx.horror.model

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

fun newId(): String = UUID.randomUUID().toString().substring(0, 8)

// ---------------------------------------------------------------- small JSON helpers
fun JSONObject.f(k: String, d: Float = 0f): Float = optDouble(k, d.toDouble()).toFloat()
fun JSONObject.i(k: String, d: Int = 0): Int = optInt(k, d)
fun JSONObject.b(k: String, d: Boolean = false): Boolean = optBoolean(k, d)
fun JSONObject.s(k: String, d: String = ""): String = optString(k, d)
fun JSONObject.putF(k: String, v: Float): JSONObject = put(k, v.toDouble())
fun JSONArray.objects(): List<JSONObject> = (0 until length()).map { getJSONObject(it) }
fun JSONArray.strings(): List<String> = (0 until length()).map { getString(it) }
fun List<String>.toJsonArray(): JSONArray = JSONArray().also { a -> forEach { a.put(it) } }

// ---------------------------------------------------------------- enums
enum class Ease(val label: String) {
    LINEAR("Linear"), EASE_IN("Ease in"), EASE_OUT("Ease out"), EASE_IN_OUT("Ease in/out"),
    BEZIER("Bezier / custom"), BOUNCE("Bounce"), ELASTIC("Elastic"), HOLD("Hold (step)")
}

enum class Blend(val label: String) {
    NORMAL("Normal"), ADD("Add"), MULTIPLY("Multiply"), SCREEN("Screen"),
    OVERLAY("Overlay"), DARKEN("Darken"), LIGHTEN("Lighten")
}

enum class FxType(val label: String, val group: String) {
    RAIN("Rain", "Weather"), SNOW("Snow", "Weather"), FOG("Fog", "Weather"), SMOKE("Smoke", "Weather"),
    DUST("Dust", "Weather"), WIND("Wind", "Weather"),
    LIGHTNING("Lightning + thunder flash", "Horror"), VIGNETTE("Vignette", "Horror"),
    GRAIN("Film grain", "Horror"), CHROMATIC("Chromatic aberration", "Horror"), GLITCH("Glitch", "Horror"),
    MOTION_BLUR("Motion blur", "Horror"), GLOW("Glow / bloom", "Horror"), SHADOW("Ground shadow", "Horror"),
    GRADE("Color grading", "Horror"), DARKNESS("Darkness", "Horror"), RED_FLASH("Red flash", "Horror"),
    FLICKER("Flicker", "Horror"), BLOOD("Blood-tint overlay (non-graphic)", "Horror"),
    GHOST("Ghost transparency", "Ghost"), GHOST_DISTORT("Ghost distortion", "Ghost"),
    SHADOW_MOVE("Moving shadows", "Horror")
}

enum class LightType(val label: String) {
    FLASHLIGHT("Flashlight"), LANTERN("Lantern"), HEADLIGHTS("Car headlights"),
    BULB("Flickering bulb"), CANDLE("Candle"), SPOT("Spot")
}

enum class AudioKind(val label: String) { VOICE("Voice"), DIALOGUE("Dialogue"), MUSIC("Music"), SFX("SFX"), AMBIENT("Ambience") }

// ---------------------------------------------------------------- keyframes
class Key(var t: Float, var v: Float, var ease: Ease = Ease.EASE_IN_OUT) {
    var x1 = 0.42f; var y1 = 0f; var x2 = 0.58f; var y2 = 1f   // bezier control points (custom easing)
    fun copyKey() = Key(t, v, ease).also { it.x1 = x1; it.y1 = y1; it.x2 = x2; it.y2 = y2 }
    fun toJson() = JSONObject().putF("t", t).putF("v", v).put("e", ease.name)
        .putF("x1", x1).putF("y1", y1).putF("x2", x2).putF("y2", y2)
    companion object {
        fun fromJson(o: JSONObject) = Key(o.f("t"), o.f("v"), runCatching { Ease.valueOf(o.s("e")) }.getOrDefault(Ease.LINEAR)).also {
            it.x1 = o.f("x1", 0.42f); it.y1 = o.f("y1", 0f); it.x2 = o.f("x2", 0.58f); it.y2 = o.f("y2", 1f)
        }
    }
}

class Track(val target: String, val prop: String) {
    val keys = mutableListOf<Key>()
    fun sort() { keys.sortBy { it.t } }
    fun toJson() = JSONObject().put("target", target).put("prop", prop)
        .put("keys", JSONArray().also { a -> keys.forEach { a.put(it.toJson()) } })
    companion object {
        fun fromJson(o: JSONObject) = Track(o.s("target"), o.s("prop")).also { tr ->
            o.getJSONArray("keys").objects().forEach { tr.keys.add(Key.fromJson(it)) }
            tr.sort()
        }
    }
}

// ---------------------------------------------------------------- layers, rigs, characters
class Layer(var id: String = newId(), var name: String = "Layer") {
    var image = ""                              // asset file name inside project assets
    var states = mutableListOf<String>()        // optional state images (eyes: open/half/closed, mouth: closed/small/medium/wide/smile/fear)
    var imgW = 100; var imgH = 100              // original pixel size
    var x = 0f; var y = 0f; var rot = 0f; var sx = 1f; var sy = 1f
    var opacity = 1f
    var px = 0.5f; var py = 0.5f                // pivot, normalized to the image
    var skx = 0f; var sky = 0f                  // skew (degrees)
    var depth = 50f                             // parallax depth: 100 far .. 20 near, 50 = character plane
    var blend = Blend.NORMAL
    var visible = true; var locked = false
    var charId = ""; var boneId = ""
    var role = ""                               // "", "eye", "brow", "mouth", "hair" ... (eye/brow/mouth drive face system)
    var side = ""                               // "L" / "R" for mirrored face parts
    var swayAmt = 0f; var swaySpeed = 1f        // mesh secondary motion (hair / cloth) degrees-ish
    var cropL = 0f; var cropT = 0f; var cropR = 1f; var cropB = 1f
    var mask: FloatArray? = null                // polygon (image px) clip mask
    var ghost = false                           // affected by ghost effects
    var shadowCaster = false
    var tint = 0                                // 0 = none, else ARGB multiply tint

    fun toJson() = JSONObject().put("id", id).put("name", name).put("image", image)
        .put("states", states.toJsonArray()).put("imgW", imgW).put("imgH", imgH)
        .putF("x", x).putF("y", y).putF("rot", rot).putF("sx", sx).putF("sy", sy).putF("opacity", opacity)
        .putF("px", px).putF("py", py).putF("skx", skx).putF("sky", sky).putF("depth", depth)
        .put("blend", blend.name).put("visible", visible).put("locked", locked)
        .put("charId", charId).put("boneId", boneId).put("role", role).put("side", side)
        .putF("swayAmt", swayAmt).putF("swaySpeed", swaySpeed)
        .putF("cropL", cropL).putF("cropT", cropT).putF("cropR", cropR).putF("cropB", cropB)
        .put("ghost", ghost).put("shadowCaster", shadowCaster).put("tint", tint)
        .also { o -> mask?.let { m -> o.put("mask", JSONArray().also { a -> m.forEach { v -> a.put(v.toDouble()) } }) } }

    fun copyOf(): Layer = fromJson(toJson()).also { it.id = newId() }

    companion object {
        fun fromJson(o: JSONObject) = Layer(o.s("id"), o.s("name")).also {
            it.image = o.s("image")
            it.states = (o.optJSONArray("states") ?: JSONArray()).strings().toMutableList()
            it.imgW = o.i("imgW", 100); it.imgH = o.i("imgH", 100)
            it.x = o.f("x"); it.y = o.f("y"); it.rot = o.f("rot"); it.sx = o.f("sx", 1f); it.sy = o.f("sy", 1f)
            it.opacity = o.f("opacity", 1f); it.px = o.f("px", .5f); it.py = o.f("py", .5f)
            it.skx = o.f("skx"); it.sky = o.f("sky"); it.depth = o.f("depth", 50f)
            it.blend = runCatching { Blend.valueOf(o.s("blend")) }.getOrDefault(Blend.NORMAL)
            it.visible = o.b("visible", true); it.locked = o.b("locked")
            it.charId = o.s("charId"); it.boneId = o.s("boneId"); it.role = o.s("role"); it.side = o.s("side")
            it.swayAmt = o.f("swayAmt"); it.swaySpeed = o.f("swaySpeed", 1f)
            it.cropL = o.f("cropL"); it.cropT = o.f("cropT"); it.cropR = o.f("cropR", 1f); it.cropB = o.f("cropB", 1f)
            it.ghost = o.b("ghost"); it.shadowCaster = o.b("shadowCaster"); it.tint = o.i("tint")
            o.optJSONArray("mask")?.let { a -> it.mask = FloatArray(a.length()) { i -> a.getDouble(i).toFloat() } }
        }
    }
}

class Bone(var id: String = newId(), var name: String = "bone", var parent: String = "", var charId: String = "") {
    var length = 60f
    var x = 0f; var y = 0f      // rest position of the bone origin in the parent's local frame
    var rot = 0f                // rest rotation (deg) relative to the parent
    var role = ""               // semantic role: hip, spine, neck, head, armL1, armL2, handL, legL1 ...
    var minRot = -180f; var maxRot = 180f   // constraint on the animated delta (degrees)
    var windAmp = 0f; var windFreq = 0.6f   // secondary motion (deg)
    var lagFollow = 0f; var lagDelay = 0.12f // follow-through (0..2)
    var ikLen = 0               // >0: this bone is an IK end bone, solved over `ikLen` bones of its chain
    var ikSign = 0              // preferred bend direction (-1,0,1)

    fun toJson() = JSONObject().put("id", id).put("name", name).put("parent", parent).put("charId", charId)
        .putF("length", length).putF("x", x).putF("y", y).putF("rot", rot).put("role", role)
        .putF("minRot", minRot).putF("maxRot", maxRot).putF("windAmp", windAmp).putF("windFreq", windFreq)
        .putF("lagFollow", lagFollow).putF("lagDelay", lagDelay).put("ikLen", ikLen).put("ikSign", ikSign)

    companion object {
        fun fromJson(o: JSONObject) = Bone(o.s("id"), o.s("name"), o.s("parent"), o.s("charId")).also {
            it.length = o.f("length", 60f); it.x = o.f("x"); it.y = o.f("y"); it.rot = o.f("rot"); it.role = o.s("role")
            it.minRot = o.f("minRot", -180f); it.maxRot = o.f("maxRot", 180f)
            it.windAmp = o.f("windAmp"); it.windFreq = o.f("windFreq", .6f)
            it.lagFollow = o.f("lagFollow"); it.lagDelay = o.f("lagDelay", .12f)
            it.ikLen = o.i("ikLen"); it.ikSign = o.i("ikSign")
        }
    }
}

class Character(var id: String = newId(), var name: String = "Character") {
    var x = 0f; var y = 0f; var rot = 0f; var sx = 1f; var sy = 1f; var opacity = 1f
    var lookRange = 14f          // px the face parts shift when looking sideways
    var lookTurn = 16f           // degrees the head turns for lookx = +-1
    var blinkSquash = true       // procedural eye squash when the eye layer has a single image
    fun toJson() = JSONObject().put("id", id).put("name", name).putF("x", x).putF("y", y).putF("rot", rot)
        .putF("sx", sx).putF("sy", sy).putF("opacity", opacity).putF("lookRange", lookRange).putF("lookTurn", lookTurn)
        .put("blinkSquash", blinkSquash)
    companion object {
        fun fromJson(o: JSONObject) = Character(o.s("id"), o.s("name")).also {
            it.x = o.f("x"); it.y = o.f("y"); it.rot = o.f("rot"); it.sx = o.f("sx", 1f); it.sy = o.f("sy", 1f)
            it.opacity = o.f("opacity", 1f); it.lookRange = o.f("lookRange", 14f); it.lookTurn = o.f("lookTurn", 16f)
            it.blinkSquash = o.b("blinkSquash", true)
        }
    }
}

/** A procedural animation clip placed on the timeline (editable, loopable, speed controlled). */
class ProcClip(var id: String = newId(), var charId: String = "", var preset: String = "Idle") {
    var start = 0f; var duration = 4f; var loop = true; var speed = 1f; var weight = 1f
    var fade = 0.25f
    var params = linkedMapOf<String, Float>()
    fun toJson() = JSONObject().put("id", id).put("charId", charId).put("preset", preset)
        .putF("start", start).putF("duration", duration).put("loop", loop).putF("speed", speed)
        .putF("weight", weight).putF("fade", fade)
        .put("params", JSONObject().also { p -> params.forEach { (k, v) -> p.putF(k, v) } })
    companion object {
        fun fromJson(o: JSONObject) = ProcClip(o.s("id"), o.s("charId"), o.s("preset")).also {
            it.start = o.f("start"); it.duration = o.f("duration", 4f); it.loop = o.b("loop", true)
            it.speed = o.f("speed", 1f); it.weight = o.f("weight", 1f); it.fade = o.f("fade", .25f)
            val p = o.optJSONObject("params")
            p?.keys()?.forEach { k -> it.params[k] = p.f(k) }
        }
    }
}

class Effect(var id: String = newId(), var type: FxType = FxType.VIGNETTE) {
    var enabled = true
    var start = 0f; var end = -1f              // end < 0 : until scene end
    var intensity = 1f
    var params = linkedMapOf<String, Float>()
    fun toJson() = JSONObject().put("id", id).put("type", type.name).put("enabled", enabled)
        .putF("start", start).putF("end", end).putF("intensity", intensity)
        .put("params", JSONObject().also { p -> params.forEach { (k, v) -> p.putF(k, v) } })
    companion object {
        fun fromJson(o: JSONObject) = Effect(o.s("id"), runCatching { FxType.valueOf(o.s("type")) }.getOrDefault(FxType.VIGNETTE)).also {
            it.enabled = o.b("enabled", true); it.start = o.f("start"); it.end = o.f("end", -1f); it.intensity = o.f("intensity", 1f)
            val p = o.optJSONObject("params")
            p?.keys()?.forEach { k -> it.params[k] = p.f(k) }
        }
    }
}

class Light(var id: String = newId(), var type: LightType = LightType.LANTERN) {
    var name = "Light"
    var x = 960f; var y = 540f; var radius = 380f; var intensity = 1f
    var color = 0xFFFFC878.toInt(); var falloff = 1.6f; var flicker = 0.2f
    var angle = 0f; var cone = 40f     // direction / half-angle for flashlight, headlights, spot
    var followChar = ""; var followBone = ""   // attach light to a character bone (e.g. hand)
    var enabled = true
    fun toJson() = JSONObject().put("id", id).put("type", type.name).put("name", name).putF("x", x).putF("y", y)
        .putF("radius", radius).putF("intensity", intensity).put("color", color).putF("falloff", falloff)
        .putF("flicker", flicker).putF("angle", angle).putF("cone", cone).put("followChar", followChar)
        .put("followBone", followBone).put("enabled", enabled)
    companion object {
        fun fromJson(o: JSONObject) = Light(o.s("id"), runCatching { LightType.valueOf(o.s("type")) }.getOrDefault(LightType.LANTERN)).also {
            it.name = o.s("name", "Light"); it.x = o.f("x"); it.y = o.f("y"); it.radius = o.f("radius", 380f)
            it.intensity = o.f("intensity", 1f); it.color = o.i("color", 0xFFFFC878.toInt()); it.falloff = o.f("falloff", 1.6f)
            it.flicker = o.f("flicker", .2f); it.angle = o.f("angle"); it.cone = o.f("cone", 40f)
            it.followChar = o.s("followChar"); it.followBone = o.s("followBone"); it.enabled = o.b("enabled", true)
        }
    }
}

class AudioClip(var id: String = newId(), var file: String = "", var name: String = "") {
    var kind = AudioKind.SFX
    var start = 0f          // position on the scene timeline (s)
    var trimIn = 0f         // offset into the source (s)
    var length = 5f         // played length (s)
    var sourceLen = 5f      // full source length (s)
    var gain = 1f; var fadeIn = 0f; var fadeOut = 0f
    var loop = false
    var charId = ""         // character that speaks this clip (for lip-sync)
    var muted = false
    fun toJson() = JSONObject().put("id", id).put("file", file).put("name", name).put("kind", kind.name)
        .putF("start", start).putF("trimIn", trimIn).putF("length", length).putF("sourceLen", sourceLen)
        .putF("gain", gain).putF("fadeIn", fadeIn).putF("fadeOut", fadeOut).put("loop", loop)
        .put("charId", charId).put("muted", muted)
    companion object {
        fun fromJson(o: JSONObject) = AudioClip(o.s("id"), o.s("file"), o.s("name")).also {
            it.kind = runCatching { AudioKind.valueOf(o.s("kind")) }.getOrDefault(AudioKind.SFX)
            it.start = o.f("start"); it.trimIn = o.f("trimIn"); it.length = o.f("length", 5f); it.sourceLen = o.f("sourceLen", 5f)
            it.gain = o.f("gain", 1f); it.fadeIn = o.f("fadeIn"); it.fadeOut = o.f("fadeOut"); it.loop = o.b("loop")
            it.charId = o.s("charId"); it.muted = o.b("muted")
        }
    }
}

class CameraCfg {
    var parallax = 1f           // parallax strength
    var followChar = ""; var followAmt = 0f; var followLag = 0.35f; var followOffX = 0f; var followOffY = 0f
    var focusDepth = 50f; var dof = 0f          // depth-of-field blur strength
    var handheld = 0f; var shake = 0f           // base values (also keyable: cam.handheld / cam.shake)
    fun toJson() = JSONObject().putF("parallax", parallax).put("followChar", followChar).putF("followAmt", followAmt)
        .putF("followLag", followLag).putF("followOffX", followOffX).putF("followOffY", followOffY)
        .putF("focusDepth", focusDepth).putF("dof", dof).putF("handheld", handheld).putF("shake", shake)
    companion object {
        fun fromJson(o: JSONObject?) = CameraCfg().also {
            if (o == null) return@also
            it.parallax = o.f("parallax", 1f); it.followChar = o.s("followChar"); it.followAmt = o.f("followAmt")
            it.followLag = o.f("followLag", .35f); it.followOffX = o.f("followOffX"); it.followOffY = o.f("followOffY")
            it.focusDepth = o.f("focusDepth", 50f); it.dof = o.f("dof"); it.handheld = o.f("handheld"); it.shake = o.f("shake")
        }
    }
}

class Scene(var id: String = newId(), var name: String = "Scene") {
    var duration = 10f
    var bgColor = 0xFF05060A.toInt()
    var wind = 0f                               // base wind (-1..1) affecting sway and particles
    val layers = mutableListOf<Layer>()
    val characters = mutableListOf<Character>()
    val bones = mutableListOf<Bone>()
    val tracks = mutableListOf<Track>()
    val clips = mutableListOf<ProcClip>()
    val effects = mutableListOf<Effect>()
    val lights = mutableListOf<Light>()
    val audio = mutableListOf<AudioClip>()
    var camera = CameraCfg()
    var ambient = 0f                            // 0..1 darkness used together with lights

    private var trackIndex: HashMap<String, Track>? = null
    private fun idx(): HashMap<String, Track> {
        var m = trackIndex
        if (m == null) { m = HashMap(); tracks.forEach { m[it.target + "|" + it.prop] = it }; trackIndex = m }
        return m
    }
    fun invalidateIndex() { trackIndex = null }
    fun track(target: String, prop: String): Track? = idx()[target + "|" + prop]
    fun trackOrCreate(target: String, prop: String): Track {
        track(target, prop)?.let { return it }
        val t = Track(target, prop); tracks.add(t); idx()[target + "|" + prop] = t; return t
    }
    fun removeTrack(t: Track) { tracks.remove(t); invalidateIndex() }
    fun tracksOf(target: String) = tracks.filter { it.target == target }
    fun layer(id: String) = layers.firstOrNull { it.id == id }
    fun bone(id: String) = bones.firstOrNull { it.id == id }
    fun character(id: String) = characters.firstOrNull { it.id == id }
    fun bonesOf(charId: String) = bones.filter { it.charId == charId }
    fun boneByRole(charId: String, role: String) = bones.firstOrNull { it.charId == charId && it.role == role }

    fun toJson() = JSONObject().put("id", id).put("name", name).putF("duration", duration).put("bgColor", bgColor)
        .putF("wind", wind).putF("ambient", ambient).put("camera", camera.toJson())
        .put("layers", JSONArray().also { a -> layers.forEach { a.put(it.toJson()) } })
        .put("characters", JSONArray().also { a -> characters.forEach { a.put(it.toJson()) } })
        .put("bones", JSONArray().also { a -> bones.forEach { a.put(it.toJson()) } })
        .put("tracks", JSONArray().also { a -> tracks.forEach { a.put(it.toJson()) } })
        .put("clips", JSONArray().also { a -> clips.forEach { a.put(it.toJson()) } })
        .put("effects", JSONArray().also { a -> effects.forEach { a.put(it.toJson()) } })
        .put("lights", JSONArray().also { a -> lights.forEach { a.put(it.toJson()) } })
        .put("audio", JSONArray().also { a -> audio.forEach { a.put(it.toJson()) } })

    companion object {
        fun fromJson(o: JSONObject) = Scene(o.s("id"), o.s("name")).also { s ->
            s.duration = o.f("duration", 10f); s.bgColor = o.i("bgColor", 0xFF05060A.toInt())
            s.wind = o.f("wind"); s.ambient = o.f("ambient"); s.camera = CameraCfg.fromJson(o.optJSONObject("camera"))
            o.optJSONArray("layers")?.objects()?.forEach { s.layers.add(Layer.fromJson(it)) }
            o.optJSONArray("characters")?.objects()?.forEach { s.characters.add(Character.fromJson(it)) }
            o.optJSONArray("bones")?.objects()?.forEach { s.bones.add(Bone.fromJson(it)) }
            o.optJSONArray("tracks")?.objects()?.forEach { s.tracks.add(Track.fromJson(it)) }
            o.optJSONArray("clips")?.objects()?.forEach { s.clips.add(ProcClip.fromJson(it)) }
            o.optJSONArray("effects")?.objects()?.forEach { s.effects.add(Effect.fromJson(it)) }
            o.optJSONArray("lights")?.objects()?.forEach { s.lights.add(Light.fromJson(it)) }
            o.optJSONArray("audio")?.objects()?.forEach { s.audio.add(AudioClip.fromJson(it)) }
        }
    }
}

class Project(var id: String = newId(), var name: String = "Untitled") {
    var width = 1920; var height = 1080; var fps = 30
    var volMaster = 1f; var volMusic = 0.8f; var volVoice = 1f; var volSfx = 1f
    var created = System.currentTimeMillis(); var modified = System.currentTimeMillis()
    val scenes = mutableListOf<Scene>()
    val assets = mutableListOf<String>()       // asset file names (images / audio) stored in the project

    fun toJson() = JSONObject().put("format", "stx-horror-animator").put("version", 1)
        .put("id", id).put("name", name).put("width", width).put("height", height).put("fps", fps)
        .putF("volMaster", volMaster).putF("volMusic", volMusic).putF("volVoice", volVoice).putF("volSfx", volSfx)
        .put("created", created).put("modified", modified)
        .put("assets", assets.toJsonArray())
        .put("scenes", JSONArray().also { a -> scenes.forEach { a.put(it.toJson()) } })

    companion object {
        fun fromJson(o: JSONObject) = Project(o.s("id"), o.s("name")).also { p ->
            p.width = o.i("width", 1920); p.height = o.i("height", 1080); p.fps = o.i("fps", 30)
            p.volMaster = o.f("volMaster", 1f); p.volMusic = o.f("volMusic", .8f)
            p.volVoice = o.f("volVoice", 1f); p.volSfx = o.f("volSfx", 1f)
            p.created = o.optLong("created", System.currentTimeMillis()); p.modified = o.optLong("modified", p.created)
            p.assets.addAll((o.optJSONArray("assets") ?: JSONArray()).strings())
            o.optJSONArray("scenes")?.objects()?.forEach { p.scenes.add(Scene.fromJson(it)) }
        }
    }
}
