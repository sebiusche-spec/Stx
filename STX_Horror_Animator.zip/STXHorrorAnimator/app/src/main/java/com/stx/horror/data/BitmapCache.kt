package com.stx.horror.data

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import java.io.File
import kotlin.math.max

/**
 * Memory aware bitmap cache. Images are decoded with inSampleSize so that they are never larger than the
 * resolution that is actually needed (low-quality preview while editing, full quality only while exporting).
 */
class BitmapCache {
    @Volatile var assetDir: File? = null
    private val maxBytes = (Runtime.getRuntime().maxMemory() / 4L).coerceIn(48L shl 20, 256L shl 20).toInt()
    private val lru = object : LruCache<String, Bitmap>(maxBytes) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.allocationByteCount
    }
    private val sizes = HashMap<String, IntArray>()

    fun clear() { lru.evictAll(); synchronized(sizes) { sizes.clear() } }

    fun fileFor(name: String): File? = assetDir?.let { File(it, name) }

    fun sizeOf(name: String): IntArray? {
        synchronized(sizes) { sizes[name]?.let { return it } }
        val f = fileFor(name) ?: return null
        if (!f.exists()) return null
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.absolutePath, o)
        if (o.outWidth <= 0) return null
        val r = intArrayOf(o.outWidth, o.outHeight)
        synchronized(sizes) { sizes[name] = r }
        return r
    }

    private fun bucket(maxDim: Int): Int { var b = 128; while (b < maxDim && b < 8192) b = b shl 1; return b }

    /** Returns a bitmap whose longest side is at most ~maxDim pixels (never upscaled). */
    fun get(name: String, maxDim: Int): Bitmap? {
        if (name.isEmpty()) return null
        val bk = bucket(maxDim)
        val key = "$name@$bk"
        lru.get(key)?.let { if (!it.isRecycled) return it }
        // a bigger cached version can serve smaller requests
        for (b in listOf(bk * 2, bk * 4)) lru.get("$name@$b")?.let { if (!it.isRecycled) return it }
        val f = fileFor(name) ?: return null
        if (!f.exists()) return null
        return try {
            val sz = sizeOf(name) ?: return null
            var sample = 1
            while (max(sz[0], sz[1]) / (sample * 2) >= bk) sample *= 2
            val o = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.ARGB_8888 }
            val bmp = BitmapFactory.decodeFile(f.absolutePath, o)
            if (bmp != null) lru.put(key, bmp)
            bmp
        } catch (e: OutOfMemoryError) {
            lru.evictAll(); null
        }
    }

    /** Cheap blur for depth-of-field: heavily downscaled copy that is upscaled with filtering. */
    fun blurred(name: String, maxDim: Int, level: Int): Bitmap? {
        val key = "$name@blur$level@${bucket(maxDim)}"
        lru.get(key)?.let { if (!it.isRecycled) return it }
        val src = get(name, maxDim) ?: return null
        val f = 1 shl (level + 1)
        val w = max(2, src.width / f); val h = max(2, src.height / f)
        return try {
            val small = Bitmap.createScaledBitmap(src, w, h, true)
            lru.put(key, small); small
        } catch (e: OutOfMemoryError) { null }
    }

    fun evict(name: String) {
        val snap = lru.snapshot().keys.filter { it.startsWith("$name@") }
        snap.forEach { lru.remove(it) }
        synchronized(sizes) { sizes.remove(name) }
    }
}
