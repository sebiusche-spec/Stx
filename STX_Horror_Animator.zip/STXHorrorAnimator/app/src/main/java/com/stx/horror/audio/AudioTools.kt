package com.stx.horror.audio

import android.media.*
import com.stx.horror.engine.Anim
import com.stx.horror.model.*
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.*

const val SR = 44100

object AudioDecoder {
    private val cache = HashMap<String, ShortArray>()
    private var cacheBytes = 0L

    @Synchronized fun get(f: File): ShortArray? {
        val key = f.absolutePath + f.lastModified()
        cache[key]?.let { return it }
        val d = decode(f) ?: return null
        if (cacheBytes + d.size * 2L > (96L shl 20)) { cache.clear(); cacheBytes = 0 }
        cache[key] = d; cacheBytes += d.size * 2L
        return d
    }

    /** Decodes any Android-supported audio (mp3, wav, m4a/aac, ogg) to mono 16-bit PCM at 44.1 kHz. */
    fun decode(f: File): ShortArray? {
        if (!f.exists()) return null
        val ex = MediaExtractor()
        try {
            ex.setDataSource(f.absolutePath)
            var track = -1
            for (i in 0 until ex.trackCount) if (ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) { track = i; break }
            if (track < 0) return null
            ex.selectTrack(track)
            val fmt = ex.getTrackFormat(track)
            val mime = fmt.getString(MediaFormat.KEY_MIME)!!
            val codec = MediaCodec.createDecoderByType(mime)
            codec.configure(fmt, null, null, 0); codec.start()
            var channels = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            var rate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var out = ShortArray(rate * 10); var n = 0
            val info = MediaCodec.BufferInfo()
            var inDone = false; var outDone = false
            while (!outDone) {
                if (!inDone) {
                    val ii = codec.dequeueInputBuffer(5000)
                    if (ii >= 0) {
                        val buf = codec.getInputBuffer(ii)!!
                        val sz = ex.readSampleData(buf, 0)
                        if (sz < 0) { codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true }
                        else { codec.queueInputBuffer(ii, 0, sz, ex.sampleTime, 0); ex.advance() }
                    }
                }
                val oi = codec.dequeueOutputBuffer(info, 5000)
                if (oi >= 0) {
                    val ob = codec.getOutputBuffer(oi)!!
                    ob.position(info.offset); ob.limit(info.offset + info.size)
                    val sb = ob.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                    val frames = sb.remaining() / max(1, channels)
                    if (n + frames > out.size) out = out.copyOf(max(out.size * 2, n + frames))
                    for (fr in 0 until frames) {
                        var sum = 0
                        for (ch in 0 until channels) sum += sb.get()
                        out[n++] = (sum / channels).toShort()
                    }
                    codec.releaseOutputBuffer(oi, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val nf = codec.outputFormat
                    channels = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT); rate = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                }
            }
            codec.stop(); codec.release()
            val pcm = out.copyOf(n)
            return if (rate == SR) pcm else resample(pcm, rate)
        } catch (e: Exception) { return null }
        finally { ex.release() }
    }

    private fun resample(src: ShortArray, rate: Int): ShortArray {
        val ratio = rate.toDouble() / SR
        val n = (src.size / ratio).toInt()
        val out = ShortArray(n)
        for (i in 0 until n) {
            val p = i * ratio; val i0 = p.toInt(); val fr = (p - i0).toFloat()
            val a = src[min(i0, src.size - 1)].toInt(); val b = src[min(i0 + 1, src.size - 1)].toInt()
            out[i] = (a + (b - a) * fr).toInt().toShort()
        }
        return out
    }

    fun durationSeconds(f: File): Float = get(f)?.let { it.size.toFloat() / SR } ?: 0f
}

/** Amplitude based lip-sync: voice audio -> mouth keyframes (0 closed, 1 small, 2 medium, 3 wide). Fully editable afterwards. */
object LipSync {
    fun envelope(pcm: ShortArray, windowSec: Float = 0.02f): FloatArray {
        val w = (SR * windowSec).toInt()
        val n = pcm.size / w
        val env = FloatArray(n)
        for (i in 0 until n) {
            var s = 0.0
            for (j in 0 until w) { val v = pcm[i * w + j] / 32768.0; s += v * v }
            env[i] = sqrt(s / w).toFloat()
        }
        return env
    }

    /** Waveform peaks for drawing (bucketed max abs, 0..1). */
    fun peaks(pcm: ShortArray, buckets: Int): FloatArray {
        val out = FloatArray(buckets); val per = max(1, pcm.size / buckets)
        for (b in 0 until buckets) {
            var m = 0
            val s = b * per; val e = min(pcm.size, s + per)
            var i = s; val step = max(1, (e - s) / 64)
            while (i < e) { m = max(m, abs(pcm[i].toInt())); i += step }
            out[b] = m / 32768f
        }
        return out
    }

    fun generate(sc: Scene, clip: AudioClip, charId: String, pcm: ShortArray): Int {
        val env = envelope(pcm)
        if (env.isEmpty()) return 0
        val sorted = env.sortedArray()
        val ref = max(0.02f, sorted[(sorted.size * 0.95f).toInt().coerceIn(0, sorted.size - 1)])
        val noise = sorted[(sorted.size * 0.15f).toInt().coerceIn(0, sorted.size - 1)]
        val tr = sc.trackOrCreate(charId, "mouth")
        // remove old keys inside the clip range
        val t0 = clip.start; val t1 = clip.start + clip.length
        tr.keys.removeAll { it.t >= t0 - 0.001f && it.t <= t1 + 0.001f }
        var last = -1; var lastT = -1f; var count = 0
        var smooth = 0f
        val dt = 0.02f
        val startIdx = (clip.trimIn / dt).toInt()
        val endIdx = min(env.size, ((clip.trimIn + clip.length) / dt).toInt())
        for (i in startIdx until endIdx) {
            smooth = smooth * 0.55f + max(0f, env[i] - noise * 1.2f) / ref * 0.45f
            val lvl = when { smooth < 0.14f -> 0; smooth < 0.36f -> 1; smooth < 0.66f -> 2; else -> 3 }
            val t = clip.start + (i - startIdx) * dt
            if (lvl != last && (t - lastT) >= 0.055f) {
                tr.keys.add(Key(t, lvl.toFloat(), Ease.HOLD)); last = lvl; lastT = t; count++
            }
        }
        tr.keys.add(Key(min(t1, sc.duration), 0f, Ease.HOLD))
        tr.sort()
        return count
    }
}

/** Offline procedural sound effects (no downloads, no licences) written as WAV files. */
object Sfx {
    val names = listOf("Thunder", "Footstep", "Footsteps (walk loop)", "Door creak", "Door slam", "Rain loop", "Wind loop", "Heartbeat", "Horror drone", "Jump scare hit", "Whisper noise", "Gate squeak")

    fun wav(file: File, d: FloatArray) {
        val n = d.size
        var peak = 0.0001f; for (v in d) peak = max(peak, abs(v))
        val bb = ByteBuffer.allocate(44 + n * 2).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()); bb.putInt(36 + n * 2); bb.put("WAVEfmt ".toByteArray()); bb.putInt(16); bb.putShort(1); bb.putShort(1)
        bb.putInt(SR); bb.putInt(SR * 2); bb.putShort(2); bb.putShort(16); bb.put("data".toByteArray()); bb.putInt(n * 2)
        val g = min(1f, 0.92f / peak)
        for (v in d) bb.putShort((v * g * 32767f).toInt().coerceIn(-32767, 32767).toShort())
        FileOutputStream(file).use { it.write(bb.array()) }
    }

    private class Rnd(var s: Int = 1234567) { fun next(): Float { s = s * 1664525 + 1013904223; return ((s ushr 8) and 0xFFFF) / 32768f - 1f } }
    private fun lp(x: FloatArray, a: Float): FloatArray { var y = 0f; for (i in x.indices) { y += a * (x[i] - y); x[i] = y }; return x }
    private fun noiseArr(n: Int, seed: Int): FloatArray { val r = Rnd(seed); return FloatArray(n) { r.next() } }

    fun generate(name: String, dir: File): String {
        val file = File(dir, name.lowercase().replace(Regex("[^a-z0-9]+"), "_").trim('_') + ".wav")
        val tau = (2.0 * PI).toFloat()
        val d: FloatArray = when (name) {
            "Thunder" -> {
                val n = SR * 5; val nz = lp(noiseArr(n, 3), 0.03f); val nz2 = lp(noiseArr(n, 9), 0.2f)
                FloatArray(n) { i -> val t = i / SR.toFloat(); val env = min(1f, t * 6f) * exp(-t * 0.85f) * (0.65f + 0.35f * sin(t * 7f)); (nz[i] * 5f + nz2[i] * 0.5f * exp(-t * 3f)) * env }
            }
            "Footstep" -> footstep(0.22f, 1f)
            "Footsteps (walk loop)" -> {
                val out = FloatArray((SR * 4.0).toInt())
                for (k in 0 until 4) { val s = footstep(0.2f, if (k % 2 == 0) 1f else 0.85f); val off = (k * SR * 1.0).toInt(); for (i in s.indices) if (off + i < out.size) out[off + i] += s[i] }
                out
            }
            "Door creak" -> {
                val n = (SR * 2.6).toInt(); val nz = noiseArr(n, 5)
                FloatArray(n) { i -> val t = i / SR.toFloat(); val f = 210f + 150f * sin(t * 2.1f) + 60f * t; val env = sin(PI.toFloat() * t / 2.6f)
                    (sin(tau * f * t) * 0.5f + sin(tau * f * 2.03f * t) * 0.25f + nz[i] * 0.08f) * env * (0.7f + 0.3f * sin(t * 31f)) }
            }
            "Gate squeak" -> {
                val n = (SR * 1.8).toInt()
                FloatArray(n) { i -> val t = i / SR.toFloat(); val f = 900f + 500f * sin(t * 3.7f) + 400f * t; sin(tau * f * t) * 0.4f * sin(PI.toFloat() * t / 1.8f) * (0.6f + 0.4f * sin(t * 47f)) }
            }
            "Door slam" -> {
                val n = SR * 2; val nz = lp(noiseArr(n, 11), 0.12f)
                FloatArray(n) { i -> val t = i / SR.toFloat(); (nz[i] * 6f + sin(tau * 70f * t) * 1.2f) * exp(-t * 7f) }
            }
            "Rain loop" -> {
                val n = SR * 6; val a = noiseArr(n, 21); val b = lp(noiseArr(n, 22), 0.5f)
                val x = FloatArray(n) { i -> a[i] * 0.35f + b[i] * 0.9f }
                loopFade(x, SR / 2)
            }
            "Wind loop" -> {
                val n = SR * 8; val nz = lp(noiseArr(n, 31), 0.05f)
                loopFade(FloatArray(n) { i -> val t = i / SR.toFloat(); nz[i] * 6f * (0.55f + 0.45f * sin(t * 0.9f) * sin(t * 0.37f + 1f)) }, SR)
            }
            "Heartbeat" -> {
                val n = (SR * 1.6).toInt()
                FloatArray(n) { i -> val t = i / SR.toFloat()
                    val a = exp(-t * 18f) * sin(tau * 55f * t); val b = if (t > 0.28f) exp(-(t - 0.28f) * 20f) * sin(tau * 48f * (t - 0.28f)) * 0.75f else 0f; a + b }
            }
            "Horror drone" -> {
                val n = SR * 10
                loopFade(FloatArray(n) { i -> val t = i / SR.toFloat()
                    (sin(tau * 55f * t) * 0.5f + sin(tau * 55.7f * t) * 0.5f + sin(tau * 82.4f * t + sin(t * 0.3f) * 2f) * 0.25f + sin(tau * 110.9f * t) * 0.12f * sin(t * 0.5f)) * (0.7f + 0.3f * sin(t * 0.25f)) }, SR)
            }
            "Jump scare hit" -> {
                val n = SR * 2; val nz = lp(noiseArr(n, 41), 0.4f)
                FloatArray(n) { i -> val t = i / SR.toFloat(); (sin(tau * 160f * t) * sin(tau * 163f * t) + sin(tau * 1700f * t) * 0.3f * exp(-t * 4f) + nz[i] * 1.2f) * exp(-t * 2.2f) }
            }
            else -> { // Whisper noise
                val n = SR * 4; val nz = noiseArr(n, 51); val l = lp(noiseArr(n, 52), 0.25f)
                FloatArray(n) { i -> val t = i / SR.toFloat(); (nz[i] * 0.25f + l[i] * 0.6f) * (0.5f + 0.5f * sin(t * 6.3f) * sin(t * 2.1f)).pow(2f) * 1.2f }
            }
        }
        wav(file, d)
        return file.name
    }

    private fun footstep(len: Float, gain: Float): FloatArray {
        val n = (SR * len).toInt(); val nz = lp(noiseArr(n, 7), 0.18f)
        return FloatArray(n) { i -> val t = i / SR.toFloat(); (nz[i] * 3f + sin(2f * PI.toFloat() * 85f * t) * 0.9f) * exp(-t * 28f) * gain }
    }
    private fun loopFade(x: FloatArray, fade: Int): FloatArray {
        // cross-fade the tail into the head so the loop is seamless
        for (i in 0 until fade) { val u = i / fade.toFloat(); val j = x.size - fade + i; x[j] = x[j] * (1f - u) + x[i] * u }
        return x.copyOf(x.size - fade)
    }
}

/** Mixes every audio clip of a scene to mono float samples (used for preview playback and export). */
class AudioMixer(private val assetsDir: File, private val project: Project) {
    private fun busGain(k: AudioKind) = when (k) {
        AudioKind.MUSIC -> project.volMusic
        AudioKind.VOICE, AudioKind.DIALOGUE -> project.volVoice
        else -> project.volSfx
    } * project.volMaster

    /** Fills out[0 until count] with the mix starting at sample index start (scene time = start / SR). */
    fun mix(sc: Scene, start: Long, out: FloatArray, count: Int) {
        java.util.Arrays.fill(out, 0, count, 0f)
        for (c in sc.audio) {
            if (c.muted || c.file.isEmpty()) continue
            val c0 = (c.start * SR).toLong(); val c1 = c0 + (c.length * SR).toLong()
            if (start + count < c0 || start > c1) continue
            val pcm = AudioDecoder.get(File(assetsDir, c.file)) ?: continue
            if (pcm.isEmpty()) continue
            val g = busGain(c.kind) * c.gain
            val trim = (c.trimIn * SR).toLong(); val fi = (c.fadeIn * SR).toLong(); val fo = (c.fadeOut * SR).toLong()
            val len = c1 - c0
            val srcLen = (c.sourceLen * SR).toLong().coerceIn(1, pcm.size.toLong()) 
            val from = max(start, c0); val to = min(start + count, c1)
            for (s in from until to) {
                val rel = s - c0
                var idx = trim + rel
                if (idx >= pcm.size) { if (c.loop) idx = trim + (rel % max(1L, pcm.size - trim)) else break }
                var env = 1f
                if (fi > 0 && rel < fi) env = rel / fi.toFloat()
                if (fo > 0 && rel > len - fo) env = min(env, (len - rel) / fo.toFloat())
                out[(s - start).toInt()] += pcm[idx.toInt().coerceIn(0, pcm.size - 1)] / 32768f * g * env
            }
            if (srcLen < 0) return
        }
    }
}

/** Live preview audio: streams the mix from a given scene time on a background thread. */
class AudioPreview(private val assetsDir: File) {
    @Volatile private var running = false
    private var thread: Thread? = null
    private var track: AudioTrack? = null

    fun start(project: Project, sc: Scene, fromTime: Float, speed: Float = 1f) {
        stop()
        if (sc.audio.isEmpty()) return
        running = true
        val mixer = AudioMixer(assetsDir, project)
        val minBuf = AudioTrack.getMinBufferSize(SR, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val at = AudioTrack(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build(),
            AudioFormat.Builder().setSampleRate(SR).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build(),
            max(minBuf, 8192), AudioTrack.MODE_STREAM, AudioManager.AUDIO_SESSION_ID_GENERATE)
        track = at
        thread = Thread {
            try {
                at.play()
                val chunk = 2048; val f = FloatArray(chunk); val s = ShortArray(chunk)
                var pos = (fromTime * SR).toLong()
                val endPos = (sc.duration * SR).toLong()
                while (running && pos < endPos) {
                    mixer.mix(sc, pos, f, chunk)
                    for (i in 0 until chunk) s[i] = (f[i] * 32767f).toInt().coerceIn(-32767, 32767).toShort()
                    at.write(s, 0, chunk)
                    pos += chunk
                }
            } catch (e: Exception) { }
            finally { runCatching { at.stop() }; runCatching { at.release() } }
        }.also { it.isDaemon = true; it.start() }
    }

    fun stop() {
        running = false
        thread?.let { runCatching { it.join(300) } }
        thread = null; track = null
    }
}
