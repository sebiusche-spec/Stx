package com.stx.horror.export

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.media.*
import com.stx.horror.audio.AudioMixer
import com.stx.horror.audio.SR
import com.stx.horror.data.BitmapCache
import com.stx.horror.engine.SceneRenderer
import com.stx.horror.model.*
import java.io.File
import java.nio.ByteBuffer
import kotlin.math.*

class ExportSettings(val height: Int, val fps: Int, val bitsPerPixel: Float, val allScenes: Boolean)

/**
 * Renders the real animation frame by frame with the same renderer as the preview (quality 2) and encodes
 * H.264/AAC into an MP4. No GL needed: frames are drawn into a bitmap, converted to YUV and queued with exact timestamps.
 */
object Exporter {
    class Result(val ok: Boolean, val message: String)

    fun export(project: Project, assetsDir: File, scenes: List<Scene>, st: ExportSettings, out: File, cacheDir: File,
               progress: (Float, String) -> Unit, cancelled: () -> Boolean): Result {
        val aspect = project.width.toFloat() / project.height
        val h = (st.height / 2) * 2
        val w = ((h * aspect).roundToInt() / 2) * 2
        val fps = st.fps
        val cache = BitmapCache(); cache.assetDir = assetsDir
        val renderer = SceneRenderer(cache)
        val totalFrames = scenes.sumOf { ceil(it.duration * fps).toInt() }.coerceAtLeast(1)
        val tmpVideo = File(cacheDir, "stx_video.mp4"); val tmpAudio = File(cacheDir, "stx_audio.m4a")
        tmpVideo.delete(); tmpAudio.delete()
        var encoder: MediaCodec? = null; var muxer: MediaMuxer? = null
        try {
            val bitrate = (w * h * fps * st.bitsPerPixel).toInt().coerceIn(800_000, 60_000_000)
            val fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
                setInteger(MediaFormat.KEY_BIT_RATE, bitrate); setInteger(MediaFormat.KEY_FRAME_RATE, fps)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            }
            encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            encoder.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE); encoder.start()
            muxer = MediaMuxer(tmpVideo.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            var track = -1; var started = false
            val info = MediaCodec.BufferInfo()
            fun drain(end: Boolean) {
                val enc = encoder!!
                while (true) {
                    val idx = enc.dequeueOutputBuffer(info, if (end) 10_000 else 0)
                    if (idx == MediaCodec.INFO_TRY_AGAIN_LATER) { if (!end) return else continue }
                    if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) { track = muxer!!.addTrack(enc.outputFormat); muxer!!.start(); started = true; continue }
                    if (idx < 0) continue
                    val buf = enc.getOutputBuffer(idx)!!
                    if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                    if (info.size > 0 && started) { buf.position(info.offset); buf.limit(info.offset + info.size); muxer!!.writeSampleData(track, buf, info) }
                    enc.releaseOutputBuffer(idx, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                }
            }
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            val px = IntArray(w * h)
            var frameNo = 0L
            for (sc in scenes) {
                val n = ceil(sc.duration * fps).toInt()
                for (f in 0 until n) {
                    if (cancelled()) { encoder.stop(); encoder.release(); muxer.release(); return Result(false, "Cancelled") }
                    bmp.eraseColor(Color.BLACK)
                    renderer.render(canvas, w, h, project, sc, f.toFloat() / fps, 2)
                    bmp.getPixels(px, 0, w, 0, 0, w, h)
                    var ii: Int
                    while (true) { ii = encoder.dequeueInputBuffer(10_000); if (ii >= 0) break; drain(false) }
                    val img = encoder.getInputImage(ii)!!
                    fillYuv(img, px, w, h)
                    encoder.queueInputBuffer(ii, 0, w * h * 3 / 2, frameNo * 1_000_000L / fps, 0)
                    drain(false)
                    frameNo++
                    if (frameNo % 3L == 0L) progress(frameNo.toFloat() / totalFrames * 0.9f, "Rendering frame $frameNo / $totalFrames")
                }
            }
            val last = encoder.dequeueInputBuffer(-1)
            encoder.queueInputBuffer(last, 0, 0, frameNo * 1_000_000L / fps, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
            drain(true)
            encoder.stop(); encoder.release(); encoder = null
            muxer.stop(); muxer.release(); muxer = null

            val hasAudio = scenes.any { s -> s.audio.any { !it.muted && it.file.isNotEmpty() } }
            if (hasAudio) {
                progress(0.92f, "Mixing audio…")
                encodeAudio(project, assetsDir, scenes, tmpAudio)
                progress(0.97f, "Muxing…")
                mux(tmpVideo, tmpAudio, out)
            } else { out.delete(); tmpVideo.copyTo(out, true) }
            tmpVideo.delete(); tmpAudio.delete()
            progress(1f, "Done")
            return Result(true, out.absolutePath)
        } catch (e: Throwable) {
            runCatching { encoder?.release() }; runCatching { muxer?.release() }
            return Result(false, "Export failed: ${e.message ?: e.javaClass.simpleName}")
        } finally { cache.clear() }
    }

    private fun fillYuv(img: android.media.Image, px: IntArray, w: Int, h: Int) {
        val yP = img.planes[0]; val uP = img.planes[1]; val vP = img.planes[2]
        val yb = yP.buffer; val ub = uP.buffer; val vb = vP.buffer
        val yRow = yP.rowStride; val yPix = yP.pixelStride
        val uRow = uP.rowStride; val uPix = uP.pixelStride; val vRow = vP.rowStride; val vPix = vP.pixelStride
        for (y in 0 until h) {
            val base = y * w
            for (x in 0 until w) {
                val c = px[base + x]
                val r = (c shr 16) and 0xFF; val g = (c shr 8) and 0xFF; val b = c and 0xFF
                yb.put(y * yRow + x * yPix, (((66 * r + 129 * g + 25 * b + 128) shr 8) + 16).toByte())
                if ((y and 1) == 0 && (x and 1) == 0) {
                    val cx = x shr 1; val cy = y shr 1
                    ub.put(cy * uRow + cx * uPix, (((-38 * r - 74 * g + 112 * b + 128) shr 8) + 128).toByte())
                    vb.put(cy * vRow + cx * vPix, (((112 * r - 94 * g - 18 * b + 128) shr 8) + 128).toByte())
                }
            }
        }
    }

    private fun encodeAudio(project: Project, assets: File, scenes: List<Scene>, out: File) {
        val mixer = AudioMixer(assets, project)
        val fmt = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, SR, 1).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, 128_000); setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
        }
        val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE); enc.start()
        val mux = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var track = -1; var started = false
        val info = MediaCodec.BufferInfo()
        fun drain(end: Boolean) {
            while (true) {
                val idx = enc.dequeueOutputBuffer(info, if (end) 10_000 else 0)
                if (idx == MediaCodec.INFO_TRY_AGAIN_LATER) { if (!end) return else continue }
                if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) { track = mux.addTrack(enc.outputFormat); mux.start(); started = true; continue }
                if (idx < 0) continue
                val buf = enc.getOutputBuffer(idx)!!
                if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                if (info.size > 0 && started) { buf.position(info.offset); buf.limit(info.offset + info.size); mux.writeSampleData(track, buf, info) }
                enc.releaseOutputBuffer(idx, false)
                if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
            }
        }
        val chunk = 2048; val f = FloatArray(chunk)
        var global = 0L
        for (sc in scenes) {
            val total = (sc.duration * SR).toLong()
            var pos = 0L
            while (pos < total) {
                val n = min(chunk.toLong(), total - pos).toInt()
                mixer.mix(sc, pos, f, n)
                var ii: Int
                while (true) { ii = enc.dequeueInputBuffer(10_000); if (ii >= 0) break; drain(false) }
                val bb = enc.getInputBuffer(ii)!!; bb.clear()
                for (i in 0 until n) bb.putShort((f[i] * 32767f).toInt().coerceIn(-32767, 32767).toShort())
                enc.queueInputBuffer(ii, 0, n * 2, global * 1_000_000L / SR, 0)
                drain(false)
                pos += n; global += n
            }
        }
        val last = enc.dequeueInputBuffer(-1)
        enc.queueInputBuffer(last, 0, 0, global * 1_000_000L / SR, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
        drain(true)
        enc.stop(); enc.release(); mux.stop(); mux.release()
    }

    private fun mux(video: File, audio: File, out: File) {
        out.delete()
        val m = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val ev = MediaExtractor().apply { setDataSource(video.absolutePath) }
        val ea = MediaExtractor().apply { setDataSource(audio.absolutePath) }
        ev.selectTrack(0); ea.selectTrack(0)
        val tv = m.addTrack(ev.getTrackFormat(0)); val ta = m.addTrack(ea.getTrackFormat(0))
        m.start()
        val buf = ByteBuffer.allocate(4 * 1024 * 1024); val info = MediaCodec.BufferInfo()
        for ((ex, tr) in listOf(ev to tv, ea to ta)) {
            while (true) {
                buf.clear()
                val sz = ex.readSampleData(buf, 0)
                if (sz < 0) break
                info.offset = 0; info.size = sz; info.presentationTimeUs = ex.sampleTime
                info.flags = if (ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                m.writeSampleData(tr, buf, info); ex.advance()
            }
            ex.release()
        }
        m.stop(); m.release()
    }
}
