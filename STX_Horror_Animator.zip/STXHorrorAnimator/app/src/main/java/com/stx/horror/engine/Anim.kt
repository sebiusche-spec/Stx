package com.stx.horror.engine

import com.stx.horror.model.*
import kotlin.math.*

object Anim {
    fun clamp01(v: Float) = if (v < 0f) 0f else if (v > 1f) 1f else v
    fun lerp(a: Float, b: Float, u: Float) = a + (b - a) * u
    fun smooth(u: Float): Float { val c = clamp01(u); return c * c * (3f - 2f * c) }

    /** Solve cubic bezier easing (CSS style) for progress u. */
    fun bezier(u: Float, x1: Float, y1: Float, x2: Float, y2: Float): Float {
        if (u <= 0f) return 0f
        if (u >= 1f) return 1f
        var lo = 0f; var hi = 1f; var t = u
        for (i in 0 until 18) {
            val x = 3f * (1 - t) * (1 - t) * t * x1 + 3f * (1 - t) * t * t * x2 + t * t * t
            if (abs(x - u) < 1e-4f) break
            if (x < u) lo = t else hi = t
            t = (lo + hi) * 0.5f
        }
        return 3f * (1 - t) * (1 - t) * t * y1 + 3f * (1 - t) * t * t * y2 + t * t * t
    }

    fun easeValue(k: Key, u: Float): Float = when (k.ease) {
        Ease.LINEAR -> u
        Ease.EASE_IN -> u * u * u
        Ease.EASE_OUT -> 1f - (1f - u) * (1f - u) * (1f - u)
        Ease.EASE_IN_OUT -> smooth(u)
        Ease.BEZIER -> bezier(u, k.x1, k.y1, k.x2, k.y2)
        Ease.BOUNCE -> {
            var x = u
            if (x < 1f / 2.75f) 7.5625f * x * x
            else if (x < 2f / 2.75f) { x -= 1.5f / 2.75f; 7.5625f * x * x + 0.75f }
            else if (x < 2.5f / 2.75f) { x -= 2.25f / 2.75f; 7.5625f * x * x + 0.9375f }
            else { x -= 2.625f / 2.75f; 7.5625f * x * x + 0.984375f }
        }
        Ease.ELASTIC -> if (u <= 0f) 0f else if (u >= 1f) 1f
        else (2.0.pow(-10.0 * u) * sin((u * 10.0 - 0.75) * (2.0 * PI / 3.0)) + 1.0).toFloat()
        Ease.HOLD -> 0f
    }

    fun eval(tr: Track?, t: Float): Float? {
        if (tr == null) return null
        val ks = tr.keys
        val n = ks.size
        if (n == 0) return null
        if (t <= ks[0].t) return ks[0].v
        if (t >= ks[n - 1].t) return ks[n - 1].v
        var lo = 0; var hi = n - 1
        while (hi - lo > 1) { val mid = (lo + hi) ushr 1; if (ks[mid].t <= t) lo = mid else hi = mid }
        val a = ks[lo]; val b = ks[hi]
        val span = b.t - a.t
        if (span <= 1e-6f) return b.v
        val u = (t - a.t) / span
        return a.v + (b.v - a.v) * easeValue(a, u)
    }

    // ---- deterministic noise (for shake / handheld / random timing)
    fun hash(n: Int): Float {
        var x = n * 374761393 + 668265263
        x = (x xor (x ushr 13)) * 1274126177
        x = x xor (x ushr 16)
        return (x and 0xFFFFFF) / 16777215f
    }
    fun hash2(a: Int, b: Int) = hash(a * 73856093 xor b * 19349663)
    /** smooth value noise in [-1,1] */
    fun noise(x: Float, seed: Int = 0): Float {
        val i = floor(x).toInt(); val f = x - i
        val a = hash2(i, seed) * 2f - 1f; val b = hash2(i + 1, seed) * 2f - 1f
        return a + (b - a) * smooth(f)
    }

    // ---- keyframe editing helpers
    fun setKey(tr: Track, t: Float, v: Float, ease: Ease? = null) {
        val e = tr.keys.firstOrNull { abs(it.t - t) < 0.0005f }
        if (e != null) { e.v = v; if (ease != null) e.ease = ease }
        else { tr.keys.add(Key(t, v, ease ?: tr.keys.lastOrNull()?.ease ?: Ease.EASE_IN_OUT)); tr.sort() }
    }
    fun keyAt(tr: Track?, t: Float): Key? = tr?.keys?.firstOrNull { abs(it.t - t) < 0.001f }

    /** Duplicate every key in [t0,t1] to start at dest. */
    fun duplicateRange(tr: Track, t0: Float, t1: Float, dest: Float) {
        val src = tr.keys.filter { it.t >= t0 - 1e-4f && it.t <= t1 + 1e-4f }.map { it.copyKey() }
        src.forEach { k -> k.t = k.t - t0 + dest; tr.keys.removeAll { o -> abs(o.t - k.t) < 0.0005f }; tr.keys.add(k) }
        tr.sort()
    }
    /** Reverse keys inside [t0,t1] in time. */
    fun reverseRange(tr: Track, t0: Float, t1: Float) {
        val inside = tr.keys.filter { it.t >= t0 - 1e-4f && it.t <= t1 + 1e-4f }
        inside.forEach { it.t = t0 + t1 - it.t }
        tr.sort()
    }
    /** Scale time inside [t0,t1] by factor (speed 2 = twice as fast = factor 0.5), anchored at t0. */
    fun speedRange(tr: Track, t0: Float, t1: Float, speed: Float) {
        if (speed <= 0.01f) return
        val inside = tr.keys.filter { it.t >= t0 - 1e-4f && it.t <= t1 + 1e-4f }
        val shift = (t1 - t0) * (1f / speed - 1f)
        val after = tr.keys.filter { it.t > t1 + 1e-4f }
        inside.forEach { it.t = t0 + (it.t - t0) / speed }
        after.forEach { it.t += shift }
        tr.sort()
    }
    /** Repeat the range [t0,t1] `times` extra times after t1. */
    fun loopRange(tr: Track, t0: Float, t1: Float, times: Int) {
        val span = t1 - t0
        if (span <= 0.01f) return
        for (n in 1..times) duplicateRange(tr, t0, t1, t0 + span * n)
    }
}
