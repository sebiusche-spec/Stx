package com.stx.horror.engine

import android.graphics.*
import com.stx.horror.model.*
import kotlin.math.*

object FxDefs {
    fun params(t: FxType): List<ParamDef> = when (t) {
        FxType.RAIN -> listOf(ParamDef("density", "Density", 0.05f, 4f, 1f), ParamDef("speed", "Speed (px/s)", 300f, 3200f, 1500f),
            ParamDef("angle", "Direction (deg)", -50f, 50f, 12f), ParamDef("size", "Streak size", 8f, 90f, 36f),
            ParamDef("thick", "Thickness", 1f, 6f, 2f), ParamDef("opacity", "Opacity", 0.05f, 1f, 0.5f), ParamDef("wind", "Wind", -1f, 1f, 0.2f))
        FxType.SNOW -> listOf(ParamDef("density", "Density", 0.1f, 4f, 1f), ParamDef("speed", "Fall speed", 30f, 500f, 120f),
            ParamDef("size", "Flake size", 1.5f, 14f, 4f), ParamDef("sway", "Sway", 0f, 3f, 1f),
            ParamDef("opacity", "Opacity", 0.1f, 1f, 0.85f), ParamDef("wind", "Wind", -1f, 1f, 0.2f))
        FxType.FOG -> listOf(ParamDef("density", "Density", 0.1f, 2f, 0.8f), ParamDef("speed", "Drift (px/s)", 0f, 200f, 28f),
            ParamDef("height", "Coverage (0 ground .. 1 full)", 0f, 1f, 0.55f), ParamDef("opacity", "Opacity", 0.05f, 1f, 0.5f),
            ParamDef("warm", "Tint (cold .. warm)", -1f, 1f, -0.3f))
        FxType.SMOKE -> listOf(ParamDef("x", "Source X", 0f, 1920f, 960f), ParamDef("y", "Source Y", 0f, 1080f, 900f),
            ParamDef("rate", "Rate", 0.1f, 3f, 0.6f), ParamDef("size", "Puff size", 40f, 500f, 160f), ParamDef("rise", "Rise (px)", 100f, 900f, 450f),
            ParamDef("opacity", "Opacity", 0.05f, 1f, 0.5f), ParamDef("wind", "Wind", -1f, 1f, 0.3f))
        FxType.DUST -> listOf(ParamDef("density", "Density", 0.1f, 4f, 1f), ParamDef("size", "Size", 1f, 8f, 2.5f),
            ParamDef("speed", "Speed", 5f, 150f, 28f), ParamDef("opacity", "Opacity", 0.05f, 1f, 0.55f))
        FxType.WIND -> listOf(ParamDef("strength", "Strength (-1 .. 1)", -1f, 1f, 0.6f))
        FxType.LIGHTNING -> listOf(ParamDef("auto", "Auto flashes (1) / keyframed (0)", 0f, 1f, 1f), ParamDef("interval", "Avg. interval (s)", 1.5f, 20f, 6f),
            ParamDef("bolt", "Draw bolt", 0f, 1f, 1f), ParamDef("seed", "Seed", 0f, 99f, 4f))
        FxType.VIGNETTE -> listOf(ParamDef("size", "Clear area", 0.1f, 0.95f, 0.5f))
        FxType.GRAIN -> listOf(ParamDef("size", "Grain size", 1f, 4f, 1.6f))
        FxType.CHROMATIC -> listOf(ParamDef("shift", "Shift (px)", 0f, 30f, 7f), ParamDef("pulse", "Pulse", 0f, 1f, 0.3f))
        FxType.GLITCH -> listOf(ParamDef("rate", "Bursts / s", 0.3f, 8f, 2f), ParamDef("slice", "Max slice shift (px)", 10f, 220f, 70f), ParamDef("duty", "Burst length", 0.05f, 0.9f, 0.25f))
        FxType.MOTION_BLUR -> listOf(ParamDef("shutter", "Shutter", 0.1f, 1f, 0.5f), ParamDef("samples", "Samples", 2f, 6f, 4f))
        FxType.GLOW -> listOf(ParamDef("threshold", "Threshold", 0f, 0.9f, 0.45f), ParamDef("radius", "Spread", 0.2f, 1f, 0.6f))
        FxType.SHADOW -> listOf(ParamDef("groundY", "Ground Y", 300f, 1080f, 880f), ParamDef("width", "Width", 0.3f, 3f, 1f))
        FxType.GRADE -> listOf(ParamDef("contrast", "Contrast", 0.5f, 2f, 1.2f), ParamDef("saturation", "Saturation", 0f, 2f, 0.55f),
            ParamDef("brightness", "Brightness", -0.4f, 0.4f, -0.06f), ParamDef("r", "Red tint", -0.3f, 0.3f, -0.03f),
            ParamDef("g", "Green tint", -0.3f, 0.3f, 0.02f), ParamDef("b", "Blue tint", -0.3f, 0.3f, 0.07f))
        FxType.DARKNESS -> emptyList()
        FxType.RED_FLASH -> listOf(ParamDef("auto", "Auto pulse (1) / keyframed (0)", 0f, 1f, 0f), ParamDef("rate", "Pulse rate (Hz)", 0.2f, 6f, 1.5f))
        FxType.FLICKER -> listOf(ParamDef("rate", "Rate (Hz)", 2f, 40f, 14f), ParamDef("depth", "Depth", 0.05f, 1f, 0.5f))
        FxType.BLOOD -> listOf(ParamDef("bpm", "Pulse (bpm)", 30f, 160f, 72f), ParamDef("size", "Clear area", 0.2f, 0.95f, 0.45f))
        FxType.GHOST -> listOf(ParamDef("minA", "Min opacity", 0f, 1f, 0.2f), ParamDef("maxA", "Max opacity", 0f, 1f, 0.7f), ParamDef("speed", "Speed", 0.1f, 4f, 0.7f))
        FxType.GHOST_DISTORT -> listOf(ParamDef("amp", "Amplitude (px)", 0f, 80f, 16f), ParamDef("freq", "Frequency", 0.2f, 6f, 1.4f))
        FxType.SHADOW_MOVE -> listOf(ParamDef("count", "Count", 1f, 6f, 2f), ParamDef("speed", "Speed (px/s)", 5f, 200f, 36f), ParamDef("size", "Size", 0.4f, 2.5f, 1f))
    }

    fun create(type: FxType): Effect {
        val e = Effect(newId(), type)
        params(type).forEach { e.params[it.key] = it.def }
        e.intensity = when (type) {
            FxType.VIGNETTE -> 0.75f; FxType.GRAIN -> 0.55f; FxType.GLITCH -> 0.8f; FxType.CHROMATIC -> 1f
            FxType.DARKNESS -> 0.55f; FxType.RED_FLASH -> 0f; FxType.GLOW -> 0.6f; FxType.SHADOW -> 0.45f
            FxType.BLOOD -> 0.5f; FxType.FLICKER -> 0.6f; FxType.FOG -> 1f; FxType.GRADE -> 1f
            else -> 1f
        }
        return e
    }
    fun weatherPreset(name: String): Effect = create(FxType.RAIN).also { e ->
        when (name) {
            "Light rain" -> { e.params["density"] = 0.35f; e.params["speed"] = 1000f; e.params["opacity"] = 0.35f; e.params["size"] = 24f }
            "Heavy rain" -> { e.params["density"] = 2.6f; e.params["speed"] = 2300f; e.params["opacity"] = 0.6f; e.params["size"] = 52f; e.params["angle"] = 18f; e.params["wind"] = 0.5f }
        }
    }
}

/** Evaluated effect state at one instant. */
class FxState(val effect: Effect, val k: Float) {
    fun p(key: String, def: Float) = effect.params[key] ?: def
}

class FxFrame(val sc: Scene, val t: Float) {
    val active = HashMap<FxType, MutableList<FxState>>()
    init {
        for (e in sc.effects) {
            if (!e.enabled) continue
            if (t < e.start - 1e-4f) continue
            if (e.end >= 0f && t > e.end) continue
            val k = Anim.eval(sc.track(e.id, "intensity"), t) ?: e.intensity
            active.getOrPut(e.type) { ArrayList() }.add(FxState(e, k))
        }
    }
    fun has(t: FxType) = active[t]?.any { it.k > 0.001f || it.effect.type == FxType.LIGHTNING || it.effect.type == FxType.RED_FLASH } == true
    fun list(t: FxType): List<FxState> = active[t] ?: emptyList()
    fun windValue(): Float {
        var w = sc.wind
        list(FxType.WIND).forEach { w += it.p("strength", .6f) * it.k }
        return w.coerceIn(-2f, 2f)
    }
}

object Fx {
    private val tau = (2.0 * PI).toFloat()
    private fun fmod(v: Float, m: Float): Float { val r = v % m; return if (r < 0f) r + m else r }

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND; style = Paint.Style.STROKE }
    private val pointPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND; style = Paint.Style.STROKE }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var puff: Bitmap? = null
    private var noise: Bitmap? = null

    fun puffBitmap(): Bitmap {
        puff?.let { return it }
        val s = 160
        val b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        // lumpy soft puff made of a few overlapping radial blobs
        for ((cx, cy, r) in listOf(Triple(80f, 80f, 78f), Triple(58f, 70f, 52f), Triple(104f, 86f, 50f), Triple(84f, 52f, 44f))) {
            p.shader = RadialGradient(cx, cy, r, intArrayOf(0x66FFFFFF, 0x33FFFFFF, 0x00FFFFFF), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, r, p)
        }
        puff = b; return b
    }
    fun noiseBitmap(): Bitmap {
        noise?.let { return it }
        val s = 256
        val px = IntArray(s * s)
        var seed = 12345
        for (i in px.indices) {
            seed = seed * 1103515245 + 12345
            val v = (seed ushr 16) and 0xFF
            val a = ((seed ushr 8) and 0xFF)
            px[i] = (a shl 24) or (v shl 16) or (v shl 8) or v
        }
        val b = Bitmap.createBitmap(px, s, s, Bitmap.Config.ARGB_8888)
        noise = b; return b
    }

    // ------------------------------------------------------------------ weather (scene space, W x H scene units)
    fun rain(c: Canvas, w: Float, h: Float, t: Float, e: FxState, wind: Float, qual: Int) {
        val density = e.p("density", 1f); val speed = e.p("speed", 1500f)
        val ang = Math.toRadians((e.p("angle", 12f) + (e.p("wind", .2f) + wind) * 18f).toDouble())
        val len = e.p("size", 36f); val thick = e.p("thick", 2f); val op = e.p("opacity", .5f) * e.k.coerceAtMost(1.5f)
        val total = (260f * density * (if (qual == 0) 0.55f else 1f)).toInt().coerceIn(8, 1800)
        val sinA = sin(ang).toFloat(); val cosA = cos(ang).toFloat()
        val layers = 3
        for (ly in 0 until layers) {
            val sp = speed * (0.65f + ly * 0.35f); val l = len * (0.6f + ly * 0.4f)
            val cnt = total / layers
            val pts = FloatArray(cnt * 4)
            val margin = h * kotlin.math.abs(sinA / cosA).coerceAtMost(1.2f) + 80f
            val span = w + margin * 2
            for (i in 0 until cnt) {
                val seed = i * 7 + ly * 131071
                val x0 = Anim.hash(seed) * span - margin
                val y0 = Anim.hash(seed + 1) * (h + l * 2)
                val fall = sp * t
                val y = fmod(y0 + fall, h + l * 2) - l
                val travelled = (y - (y0 - l)) // slant offset relative to the start of the loop
                val x = fmod(x0 + sinA / cosA * (y), span) - margin
                pts[i * 4] = x; pts[i * 4 + 1] = y; pts[i * 4 + 2] = x - sinA * l; pts[i * 4 + 3] = y - cosA * l
                if (travelled.isNaN()) pts[i * 4] = x
            }
            linePaint.strokeWidth = thick * (0.6f + ly * 0.35f)
            linePaint.color = Color.argb((255f * op * (0.45f + ly * 0.3f)).toInt().coerceIn(0, 255), 190, 205, 230)
            c.drawLines(pts, linePaint)
        }
    }

    fun snow(c: Canvas, w: Float, h: Float, t: Float, e: FxState, wind: Float, qual: Int) {
        val density = e.p("density", 1f); val speed = e.p("speed", 120f); val size = e.p("size", 4f)
        val sway = e.p("sway", 1f); val op = e.p("opacity", .85f) * e.k.coerceAtMost(1.5f)
        val wv = e.p("wind", .2f) + wind
        val total = (160f * density * (if (qual == 0) 0.55f else 1f)).toInt().coerceIn(8, 900)
        for (ly in 0 until 3) {
            val cnt = total / 3
            val pts = FloatArray(cnt * 2)
            val sp = speed * (0.5f + ly * 0.4f)
            for (i in 0 until cnt) {
                val seed = i * 11 + ly * 99991
                val y = fmod(Anim.hash(seed + 1) * h + sp * t, h + 20f) - 10f
                val x = fmod(Anim.hash(seed) * w + wv * 60f * t * (0.5f + ly * .4f) + sin(t * (0.6f + Anim.hash(seed + 2)) + seed) * 30f * sway, w + 20f) - 10f
                pts[i * 2] = x; pts[i * 2 + 1] = y
            }
            pointPaint.strokeWidth = size * (0.55f + ly * 0.35f)
            pointPaint.color = Color.argb((255f * op * (0.5f + ly * 0.25f)).toInt().coerceIn(0, 255), 240, 245, 255)
            c.drawPoints(pts, pointPaint)
        }
    }

    fun dust(c: Canvas, w: Float, h: Float, t: Float, e: FxState, qual: Int) {
        val density = e.p("density", 1f); val size = e.p("size", 2.5f); val speed = e.p("speed", 28f)
        val op = e.p("opacity", .55f) * e.k.coerceAtMost(1.5f)
        val cnt = (90f * density * (if (qual == 0) 0.5f else 1f)).toInt().coerceIn(6, 500)
        val pts = FloatArray(cnt * 2)
        for (i in 0 until cnt) {
            val x = fmod(Anim.hash(i * 3) * w + sin(t * 0.4f + i) * 40f + speed * t * 0.6f, w)
            val y = fmod(Anim.hash(i * 3 + 1) * h + cos(t * 0.33f + i * 1.7f) * 34f - speed * t * 0.25f, h)
            pts[i * 2] = x; pts[i * 2 + 1] = y
        }
        pointPaint.strokeWidth = size
        pointPaint.color = Color.argb((255f * op * 0.7f).toInt().coerceIn(0, 255), 215, 205, 185)
        c.drawPoints(pts, pointPaint)
        pointPaint.strokeWidth = size * 0.55f
        pointPaint.color = Color.argb((255f * op * 0.9f).toInt().coerceIn(0, 255), 235, 225, 205)
        c.drawPoints(pts.copyOfRange(0, (cnt / 2) * 2), pointPaint)
    }

    fun fog(c: Canvas, w: Float, h: Float, t: Float, e: FxState) {
        val dens = e.p("density", .8f); val sp = e.p("speed", 28f); val cover = e.p("height", .55f)
        val op = e.p("opacity", .5f) * e.k.coerceAtMost(1.5f); val warm = e.p("warm", -.3f)
        val bmp = puffBitmap()
        val r = (150 + 90 * warm.coerceAtLeast(0f)).toInt(); val g = (165 + 30 * warm).toInt().coerceIn(0, 255); val b = (190 - 80 * warm).toInt().coerceIn(0, 255)
        fillPaint.colorFilter = PorterDuffColorFilter(Color.rgb(r.coerceIn(0, 255), g, b), PorterDuff.Mode.SRC_IN)
        val n = (14 * dens).toInt().coerceIn(4, 40)
        for (i in 0 until n) {
            val sz = 520f + Anim.hash(i * 5) * 700f
            val dir = if (i % 2 == 0) 1f else -0.6f
            val x = fmod(Anim.hash(i * 5 + 1) * (w + sz) + sp * t * dir * (0.5f + Anim.hash(i * 5 + 3)), w + sz) - sz * 0.5f
            val baseY = h * (1f - cover * 0.9f) + Anim.hash(i * 5 + 2) * h * (cover * 0.9f + 0.1f)
            val y = baseY + sin(t * 0.2f + i) * 25f
            fillPaint.alpha = (255f * op * 0.55f * (0.6f + 0.4f * Anim.hash(i * 5 + 4))).toInt().coerceIn(0, 255)
            c.drawBitmap(bmp, null, RectF(x - sz / 2, y - sz * 0.36f, x + sz / 2, y + sz * 0.36f), fillPaint)
        }
        fillPaint.colorFilter = null; fillPaint.alpha = 255
    }

    fun smoke(c: Canvas, w: Float, h: Float, t: Float, e: FxState, wind: Float) {
        val sx = e.p("x", 960f); val sy = e.p("y", 900f); val rate = e.p("rate", .6f); val size = e.p("size", 160f)
        val rise = e.p("rise", 450f); val op = e.p("opacity", .5f) * e.k.coerceAtMost(1.5f); val wv = e.p("wind", .3f) + wind
        val bmp = puffBitmap()
        fillPaint.colorFilter = PorterDuffColorFilter(Color.rgb(120, 120, 130), PorterDuff.Mode.SRC_IN)
        val n = 18
        for (i in 0 until n) {
            val age = fmod(t * rate * 0.5f + i.toFloat() / n, 1f)
            val sd = Anim.hash(i * 13)
            val x = sx + wv * 220f * age * age + sin(age * 5f + i) * 28f * age + (sd - .5f) * 30f
            val y = sy - age * rise
            val s = size * (0.35f + 1.9f * age)
            fillPaint.alpha = (255f * op * (1f - age) * Anim.smooth(age * 6f)).toInt().coerceIn(0, 255)
            c.drawBitmap(bmp, null, RectF(x - s / 2, y - s / 2, x + s / 2, y + s / 2), fillPaint)
        }
        fillPaint.colorFilter = null; fillPaint.alpha = 255
    }

    // ------------------------------------------------------------------ lightning
    class Strike(val on: Boolean, val flash: Float, val boltAlpha: Float, val seed: Int, val x: Float)
    fun lightning(sc: Scene, e: FxState, t: Float): Strike {
        val auto = e.p("auto", 1f) > 0.5f
        if (!auto) {
            val f = (Anim.eval(sc.track(e.effect.id, "intensity"), t) ?: 0f).coerceIn(0f, 1.5f)
            return Strike(f > 0.01f, f, if (f > .35f) f else 0f, (t * 10).toInt(), Anim.hash((t * 3).toInt()))
        }
        val interval = e.p("interval", 6f); val seed = e.p("seed", 4f).toInt()
        val k = floor(t / interval).toInt()
        val te = k * interval + Anim.hash2(k, seed) * interval * 0.75f + 0.5f
        val dt = t - te
        var f = 0f
        if (dt >= 0f && dt < 0.7f) {
            f = if (dt < 0.07f) dt / 0.07f else exp(-(dt - 0.07f) * 11f)
            val d2 = dt - 0.2f
            if (d2 > 0f) f = max(f, 0.75f * (if (d2 < 0.05f) d2 / 0.05f else exp(-(d2 - 0.05f) * 9f)))
        }
        f *= e.k
        return Strike(f > 0.01f, f, if (dt in 0f..0.28f) f else 0f, k * 31 + seed, 0.15f + 0.7f * Anim.hash2(k, seed + 9))
    }

    fun bolt(c: Canvas, w: Float, h: Float, s: Strike) {
        if (s.boltAlpha < 0.05f) return
        var seed = s.seed * 977 + 13
        fun rnd(): Float { seed = seed * 1103515245 + 12345; return ((seed ushr 8) and 0xFFFF) / 65535f }
        val path = Path()
        var x = s.x * w; var y = -10f
        path.moveTo(x, y)
        val branches = ArrayList<FloatArray>()
        while (y < h * 0.62f) {
            val ny = y + 35f + rnd() * 55f; val nx = x + (rnd() - .5f) * 90f
            path.lineTo(nx, ny)
            if (rnd() < 0.18f) branches.add(floatArrayOf(nx, ny))
            x = nx; y = ny
        }
        linePaint.strokeJoin = Paint.Join.ROUND
        linePaint.color = Color.argb((120 * s.boltAlpha).toInt().coerceIn(0, 255), 170, 190, 255); linePaint.strokeWidth = 14f
        c.drawPath(path, linePaint)
        linePaint.color = Color.argb((255 * s.boltAlpha).toInt().coerceIn(0, 255), 245, 248, 255); linePaint.strokeWidth = 4f
        c.drawPath(path, linePaint)
        for (b in branches) {
            val bp = Path(); bp.moveTo(b[0], b[1]); var bx = b[0]; var by = b[1]; val dir = if (rnd() < .5f) -1f else 1f
            for (i in 0 until 4) { bx += dir * (20f + rnd() * 40f); by += 25f + rnd() * 35f; bp.lineTo(bx, by) }
            linePaint.strokeWidth = 2f; c.drawPath(bp, linePaint)
        }
    }

    // ------------------------------------------------------------------ shadows
    fun groundShadow(c: Canvas, cx: Float, gy: Float, width: Float, alpha: Float) {
        fillPaint.shader = RadialGradient(cx, gy, width, intArrayOf(Color.argb((255 * alpha).toInt().coerceIn(0, 255), 0, 0, 0), 0x00000000), floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
        c.save(); c.translate(0f, gy); c.scale(1f, 0.16f); c.translate(0f, -gy)
        c.drawCircle(cx, gy, width, fillPaint); c.restore(); fillPaint.shader = null
    }

    fun movingShadows(c: Canvas, w: Float, h: Float, t: Float, e: FxState) {
        val n = e.p("count", 2f).toInt(); val sp = e.p("speed", 36f); val size = e.p("size", 1f)
        for (i in 0 until n) {
            val x = fmod(Anim.hash(i * 17) * (w + 600f) + sp * t * (if (i % 2 == 0) 1f else -1f), w + 600f) - 300f
            val gy = h * (0.78f + 0.08f * Anim.hash(i * 17 + 1))
            val bh = 560f * size * (0.8f + 0.4f * Anim.hash(i * 17 + 2))
            val a = (255f * 0.55f * e.k.coerceAtMost(1.2f) * (0.6f + 0.4f * sin(t * 0.7f + i))).toInt().coerceIn(0, 255)
            val p = Path()
            val bw = bh * 0.2f
            p.moveTo(x - bw, gy); p.cubicTo(x - bw * 1.1f, gy - bh * 0.5f, x - bw * 0.6f, gy - bh * 0.78f, x, gy - bh * 0.82f)
            p.cubicTo(x + bw * 0.6f, gy - bh * 0.78f, x + bw * 1.1f, gy - bh * 0.5f, x + bw, gy); p.close()
            fillPaint.color = Color.argb(a, 0, 0, 0)
            c.drawPath(p, fillPaint)
            c.drawOval(RectF(x - bw * 0.42f, gy - bh, x + bw * 0.42f, gy - bh * 0.78f), fillPaint)
        }
    }

    // ------------------------------------------------------------------ screen-space overlays (px)
    fun vignette(c: Canvas, w: Float, h: Float, k: Float, size: Float) {
        val r = hypot(w, h) * 0.5f
        fillPaint.shader = RadialGradient(w / 2, h / 2, r, intArrayOf(0x00000000, 0x00000000, Color.argb((255 * k.coerceIn(0f, 1f)).toInt(), 0, 0, 0)),
            floatArrayOf(0f, size.coerceIn(0.05f, 0.95f), 1f), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, fillPaint); fillPaint.shader = null
    }
    fun blood(c: Canvas, w: Float, h: Float, t: Float, k: Float, bpm: Float, size: Float) {
        val beat = (t * bpm / 60f) % 1f
        val pulse = max(exp(-beat * 14f), 0.7f * exp(-abs(beat - 0.28f) * 16f)) * 0.55f + 0.45f
        val r = hypot(w, h) * 0.5f
        fillPaint.shader = RadialGradient(w / 2, h / 2, r, intArrayOf(0x00000000, 0x00000000, Color.argb((235 * k * pulse).toInt().coerceIn(0, 255), 150, 0, 8)),
            floatArrayOf(0f, size, 1f), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, fillPaint); fillPaint.shader = null
    }
    fun grain(c: Canvas, w: Float, h: Float, frame: Int, k: Float, size: Float) {
        val nb = noiseBitmap()
        val sh = BitmapShader(nb, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
        val m = Matrix(); m.postScale(size, size); m.postTranslate(Anim.hash(frame * 3) * 256f, Anim.hash(frame * 3 + 1) * 256f)
        sh.setLocalMatrix(m)
        fillPaint.shader = sh; fillPaint.alpha = (255f * 0.22f * k).toInt().coerceIn(0, 255)
        c.drawRect(0f, 0f, w, h, fillPaint); fillPaint.shader = null; fillPaint.alpha = 255
    }

    fun gradeMatrix(sat: Float, contrast: Float, bright: Float, r: Float, g: Float, b: Float, k: Float): ColorMatrix {
        val kk = k.coerceIn(0f, 1f)
        val s = 1f + (sat - 1f) * kk; val ct = 1f + (contrast - 1f) * kk
        val cm = ColorMatrix(); cm.setSaturation(s)
        val off = 128f * (1f - ct) + bright * 255f * kk
        val cc = ColorMatrix(floatArrayOf(ct, 0f, 0f, 0f, off + r * 255f * kk, 0f, ct, 0f, 0f, off + g * 255f * kk, 0f, 0f, ct, 0f, off + b * 255f * kk, 0f, 0f, 0f, 1f, 0f))
        cm.postConcat(cc)
        return cm
    }
}
