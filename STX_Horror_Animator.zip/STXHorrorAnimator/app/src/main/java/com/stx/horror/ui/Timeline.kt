package com.stx.horror.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.stx.horror.model.*
import kotlin.math.*

class TlRow(val label: String, val color: Color, val target: String = "", val prop: String = "", val kind: String = "track", val id: String = "")

private fun propName(p: String) = when (p) {
    "x" -> "Position X"; "y" -> "Position Y"; "rot" -> "Rotation"; "sx" -> "Scale X"; "sy" -> "Scale Y"; "opacity" -> "Opacity"
    "px" -> "Pivot X"; "py" -> "Pivot Y"; "skx" -> "Skew X"; "sky" -> "Skew Y"; "eye" -> "Eyes"; "brow" -> "Eyebrows"; "mouth" -> "Mouth"
    "lookx" -> "Look X"; "looky" -> "Look Y"; "zoom" -> "Zoom"; "shake" -> "Shake"; "hand" -> "Handheld"; "focus" -> "Focus"
    "intensity" -> "Intensity"; "ikx" -> "IK X"; "iky" -> "IK Y"; "ikw" -> "IK weight"; "radius" -> "Radius"; "angle" -> "Angle"; else -> p
}

fun buildRows(st: EditorState): List<TlRow> {
    val sc = st.scene; val rows = ArrayList<TlRow>()
    st.version  // read for recomposition
    val camTracks = sc.tracksOf("cam")
    camTracks.forEach { rows.add(TlRow("Camera · " + propName(it.prop), C.Violet, "cam", it.prop)) }
    val ch = st.character()
    if (ch != null) {
        sc.clips.filter { it.charId == ch.id }.forEach { rows.add(TlRow("Preset · " + it.preset, C.Green, kind = "clip", id = it.id)) }
        sc.tracksOf(ch.id).forEach { t -> val c = if (t.prop in listOf("eye", "brow", "mouth", "lookx", "looky")) C.Amber else C.Neon
            rows.add(TlRow((if (c == C.Amber) "Face · " else ch.name + " · ") + propName(t.prop), c, ch.id, t.prop)) }
    }
    val l = st.layer()
    if (l != null) sc.tracksOf(l.id).forEach { rows.add(TlRow(l.name.take(10) + " · " + propName(it.prop), C.Neon, l.id, it.prop)) }
    val b = st.bone()
    if (b != null) sc.tracksOf(b.id).forEach { rows.add(TlRow("Bone " + b.name.take(10) + " · " + propName(it.prop), C.Red, b.id, it.prop)) }
    // other bones with keys of selected character
    if (ch != null) sc.bonesOf(ch.id).filter { it.id != st.selBone && sc.tracksOf(it.id).isNotEmpty() }.take(6).forEach { bb ->
        sc.tracksOf(bb.id).take(1).forEach { rows.add(TlRow("Rig · " + bb.name.take(12) + " · " + propName(it.prop), C.Red.copy(alpha = 0.7f), bb.id, it.prop)) } }
    sc.effects.filter { sc.track(it.id, "intensity") != null }.forEach { rows.add(TlRow("FX · " + it.type.label.take(14), C.Violet, it.id, "intensity")) }
    sc.lights.forEach { li -> sc.tracksOf(li.id).forEach { rows.add(TlRow("Light · " + li.name.take(8) + " · " + propName(it.prop), C.Amber, li.id, it.prop)) } }
    sc.audio.forEach { rows.add(TlRow("Audio · " + it.name.take(14), C.Green, kind = "audio", id = it.id)) }
    if (rows.isEmpty()) rows.add(TlRow("No keyframes yet – use ◇ next to any property", C.Muted, kind = "empty"))
    return rows
}

@Composable
fun TimelinePanel(st: EditorState, modifier: Modifier = Modifier) {
    val sc = st.scene
    val rows = remember(st.version, st.sceneIdx, st.selLayer, st.selChar, st.selBone) { buildRows(st) }
    var pps by remember { mutableFloatStateOf(90f) }            // pixels per second
    var scroll by remember { mutableFloatStateOf(0f) }
    val dens = LocalDensity.current
    val rowH = with(dens) { 26.dp.toPx() }; val rulerH = with(dens) { 22.dp.toPx() }
    val labelW = with(dens) { 104.dp.toPx() }
    val vScroll = rememberScrollState()
    val kDrag = remember { mutableStateOf<KeyRef?>(null) }

    Row(modifier.background(C.Panel)) {
        // fixed label column
        Column(Modifier.width(104.dp).verticalScroll(vScroll)) {
            Spacer(Modifier.height(22.dp))
            rows.forEach { r -> Box(Modifier.height(26.dp).fillMaxWidth().padding(start = 4.dp), contentAlignment = Alignment.CenterStart) {
                androidx.compose.material3.Text(r.label, color = r.color, fontSize = 9.sp, maxLines = 1) } }
        }
        Box(Modifier.weight(1f).fillMaxHeight()) {
            Canvas(Modifier.fillMaxSize().pointerInput(rows) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val x0 = down.position.x; val y0 = down.position.y
                    val vOff = vScroll.value.toFloat()
                    fun tAt(x: Float) = ((x + scroll) / pps).coerceIn(0f, st.scene.duration)
                    // hit-test keyframes / clips
                    var hitKey: KeyRef? = null; var hitClip: String? = null; var hitAudio: String? = null
                    if (y0 > rulerH) {
                        val ri = ((y0 - rulerH + vOff) / rowH).toInt()
                        val r = rows.getOrNull(ri)
                        if (r != null) {
                            if (r.kind == "track") {
                                st.scene.track(r.target, r.prop)?.keys?.forEach { k -> if (abs(k.t * pps - scroll - x0) < 20f) hitKey = KeyRef(r.target, r.prop, k.t) }
                            } else if (r.kind == "clip") {
                                st.scene.clips.firstOrNull { it.id == r.id }?.let { c -> if (x0 >= c.start * pps - scroll && x0 <= (c.start + c.duration) * pps - scroll) hitClip = c.id }
                            } else if (r.kind == "audio") {
                                st.scene.audio.firstOrNull { it.id == r.id }?.let { c -> if (x0 >= c.start * pps - scroll && x0 <= (c.start + c.length) * pps - scroll) hitAudio = c.id }
                            }
                        }
                    }
                    val hk = hitKey; val hc = hitClip; val ha = hitAudio
                    if (hk != null) st.selKey = hk
                    if (hc != null) { st.selClip = hc; st.selKey = null }
                    if (ha != null) { st.selAudio = ha; st.selKey = null }
                    var cur: KeyRef? = hk
                    var lastX = x0; var multi = false; var moved = false
                    val scrub = y0 <= rulerH || (hk == null && hc == null && ha == null)
                    if (y0 <= rulerH) st.seek(tAt(x0))
                    var pinch = 0f
                    while (true) {
                        val ev = awaitPointerEvent(PointerEventPass.Main)
                        val ptrs = ev.changes.filter { it.pressed }
                        if (ptrs.isEmpty()) { if (!moved && hk == null && hc == null && ha == null && y0 > rulerH) st.seek(tAt(x0)); break }
                        if (ptrs.size >= 2) {
                            multi = true
                            val d = abs(ptrs[0].position.x - ptrs[1].position.x)
                            if (pinch > 20f && d > 20f) { val mid = (ptrs[0].position.x + ptrs[1].position.x) / 2f; val tm = (mid + scroll) / pps; pps = (pps * d / pinch).coerceIn(20f, 600f); scroll = (tm * pps - mid).coerceAtLeast(0f) }
                            pinch = d; ev.changes.forEach { it.consume() }; continue
                        }
                        if (multi) { ev.changes.forEach { it.consume() }; continue }
                        val p = ptrs[0]; val dx = p.position.x - lastX
                        if (abs(p.position.x - x0) > 8f) moved = true
                        if (moved) {
                            if (hk != null && cur != null) { cur = st.moveKey(cur, tAt(p.position.x)); st.selKey = cur }
                            else if (hc != null) { st.scene.clips.firstOrNull { it.id == hc }?.let { c -> st.edit("clipmove") { c.start = (c.start + dx / pps).coerceIn(0f, st.scene.duration - 0.1f) } } }
                            else if (ha != null) { st.scene.audio.firstOrNull { it.id == ha }?.let { c -> st.edit("audiomove") { c.start = (c.start + dx / pps).coerceIn(0f, st.scene.duration - 0.1f) } } }
                            else if (y0 <= rulerH) st.seek(tAt(p.position.x))
                            else scroll = (scroll - dx).coerceIn(0f, max(0f, st.scene.duration * pps - 100f))
                            p.consume()
                        }
                        lastX = p.position.x
                    }
                }
            }) {
                drawTimeline(st, rows, pps, scroll, rowH, rulerH, vScroll.value.toFloat())
            }
        }
    }
}

private fun DrawScope.drawTimeline(st: EditorState, rows: List<TlRow>, pps: Float, scroll: Float, rowH: Float, rulerH: Float, vOff: Float) {
    val sc = st.scene
    val w = size.width; val h = size.height
    drawRect(C.Panel2, Offset.Zero, Size(w, rulerH))
    // ruler ticks
    val step = when { pps > 300 -> 0.1f; pps > 120 -> 0.25f; pps > 50 -> 0.5f; else -> 1f }
    var t = 0f
    val paint = android.graphics.Paint().apply { color = 0xFF8D93A8.toInt(); textSize = 20f; isAntiAlias = true }
    while (t <= sc.duration + 0.001f) {
        val x = t * pps - scroll
        if (x in -2f..w) {
            val major = abs(t - t.roundToInt()) < 0.001f
            drawLine(C.Line, Offset(x, if (major) 4f else rulerH * 0.55f), Offset(x, h), strokeWidth = if (major) 1.5f else 0.5f)
            if (major) drawContext.canvas.nativeCanvas.drawText("${t.roundToInt()}s", x + 4f, rulerH - 6f, paint)
        }
        t += step
    }
    // end marker
    val ex = sc.duration * pps - scroll
    drawRect(Color(0x33FF2E4D), Offset(ex, 0f), Size(max(0f, w - ex), h))
    // rows
    rows.forEachIndexed { i, r ->
        val y = rulerH + i * rowH - vOff
        if (y + rowH < rulerH || y > h) return@forEachIndexed
        drawLine(Color(0xFF1E2130), Offset(0f, y + rowH), Offset(w, y + rowH), 1f)
        when (r.kind) {
            "track" -> sc.track(r.target, r.prop)?.let { tr ->
                // segment bars between keys
                for (k in 0 until tr.keys.size - 1) { val a = tr.keys[k].t * pps - scroll; val b = tr.keys[k + 1].t * pps - scroll
                    drawRect(r.color.copy(alpha = 0.16f), Offset(a, y + rowH * 0.38f), Size(b - a, rowH * 0.24f)) }
                tr.keys.forEach { k ->
                    val x = k.t * pps - scroll; if (x < -10f || x > w + 10f) return@forEach
                    val sel = st.selKey?.let { s -> s.target == r.target && s.prop == r.prop && abs(s.t - k.t) < 0.001f } == true
                    val cy = y + rowH / 2f; val s = if (sel) 10f else 7.5f
                    val p = Path().apply { moveTo(x, cy - s); lineTo(x + s, cy); lineTo(x, cy + s); lineTo(x - s, cy); close() }
                    drawPath(p, if (sel) C.Amber else r.color)
                    if (k.ease == Ease.HOLD) drawRect(Color.Black.copy(alpha = 0.5f), Offset(x - 2f, cy - 2f), Size(4f, 4f))
                }
            }
            "clip" -> sc.clips.firstOrNull { it.id == r.id }?.let { c ->
                val a = c.start * pps - scroll; val b = (c.start + c.duration) * pps - scroll
                drawRect(C.Green.copy(alpha = if (st.selClip == c.id) 0.55f else 0.3f), Offset(a, y + 3f), Size(b - a, rowH - 6f))
                drawRect(C.Green, Offset(a, y + 3f), Size(b - a, rowH - 6f), style = Stroke(1.5f))
            }
            "audio" -> sc.audio.firstOrNull { it.id == r.id }?.let { c ->
                val a = c.start * pps - scroll; val b = (c.start + c.length) * pps - scroll
                drawRect(C.Green.copy(alpha = if (st.selAudio == c.id) 0.4f else 0.2f), Offset(a, y + 3f), Size(b - a, rowH - 6f))
                val pk = remember2(c.id + c.file) { st.peaks(c, 256) }
                if (pk != null) {
                    val cols = ((b - a) / 3f).toInt().coerceIn(1, 600)
                    for (cI in 0 until cols) {
                        val tt = c.trimIn + (cI.toFloat() / cols) * c.length
                        val idx = (tt / max(0.01f, c.sourceLen) * pk.size).toInt().coerceIn(0, pk.size - 1)
                        val amp = pk[idx] * (rowH - 8f) / 2f
                        val cx = a + cI * 3f
                        drawLine(C.Green, Offset(cx, y + rowH / 2 - amp), Offset(cx, y + rowH / 2 + amp), 1.5f)
                    }
                }
            }
        }
    }
    // playhead
    val px = st.time * pps - scroll
    drawLine(C.Red, Offset(px, 0f), Offset(px, h), 2.5f)
    val tri = Path().apply { moveTo(px - 9f, 0f); lineTo(px + 9f, 0f); lineTo(px, 14f); close() }
    drawPath(tri, C.Red)
}

private val peakCache = HashMap<String, FloatArray?>()
private fun remember2(key: String, f: () -> FloatArray?): FloatArray? {
    if (peakCache.containsKey(key)) return peakCache[key]
    val v = f(); peakCache[key] = v; return v
}
