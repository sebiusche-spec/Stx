package com.stx.horror.ui

import android.content.ContentValues
import android.content.Context
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.compose.runtime.*
import com.stx.horror.audio.*
import com.stx.horror.data.*
import com.stx.horror.engine.*
import com.stx.horror.export.ExportSettings
import com.stx.horror.export.Exporter
import com.stx.horror.model.*
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.*

class KeyRef(val target: String, val prop: String, val t: Float)

/** Everything the editor UI reads and mutates. Project data is plain mutable objects; `version` is bumped after every change. */
class EditorState(val ctx: Context, val repo: ProjectRepo, var project: Project) {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    val cache = BitmapCache().also { it.assetDir = repo.assetsDir(project.id) }
    val renderer = SceneRenderer(cache)
    private val audio = AudioPreview(repo.assetsDir(project.id))

    var sceneIdx by mutableIntStateOf(0)
    var time by mutableFloatStateOf(0f)
    var playing by mutableStateOf(false)
    var version by mutableIntStateOf(0)
    var tick by mutableIntStateOf(0)
    var autoKey by mutableStateOf(false)
    var rigMode by mutableStateOf(false)
    var tool by mutableStateOf("move")           // move, pivot, bone, ik, rotate, scale
    var lowPreview by mutableStateOf(true)
    var loopPlay by mutableStateOf(true)
    var showBones by mutableStateOf(true)
    var showGrid by mutableStateOf(false)
    var selLayer by mutableStateOf("")
    var selChar by mutableStateOf("")
    var selBone by mutableStateOf("")
    var selFx by mutableStateOf("")
    var selLight by mutableStateOf("")
    var selClip by mutableStateOf("")
    var selAudio by mutableStateOf("")
    var selKey by mutableStateOf<KeyRef?>(null)
    var message by mutableStateOf("")
    var exportProgress by mutableFloatStateOf(-1f)
    var exportText by mutableStateOf("")
    private var exportCancel = false
    var dirty = false
    var saved by mutableStateOf(true)

    val scene: Scene get() = project.scenes[sceneIdx.coerceIn(0, project.scenes.size - 1)]
    val assetsDir: File get() = repo.assetsDir(project.id)

    init {
        RigSolver.restMode = false
        scope.launch { while (isActive) { delay(8000); if (dirty) autosaveNow() } }
        prefetch()
    }

    fun toast(s: String) { message = s }

    // ------------------------------------------------------------------ undo / redo / save
    private val undoStack = ArrayDeque<String>(); private val redoStack = ArrayDeque<String>()
    private var lastKey = ""; private var lastAt = 0L
    val canUndo get() = undoStack.isNotEmpty()
    val canRedo get() = redoStack.isNotEmpty()

    fun touch() { scene.invalidateIndex(); version++; tick++; dirty = true; saved = false }

    fun edit(coalesce: String = "", block: () -> Unit) {
        val now = System.currentTimeMillis()
        if (coalesce.isEmpty() || coalesce != lastKey || now - lastAt > 900) {
            undoStack.addLast(project.toJson().toString()); if (undoStack.size > 60) undoStack.removeFirst(); redoStack.clear()
        }
        lastKey = coalesce; lastAt = now
        block(); touch()
    }
    fun undo() {
        if (undoStack.isEmpty()) return
        redoStack.addLast(project.toJson().toString()); restore(undoStack.removeLast()); lastKey = ""
    }
    fun redo() {
        if (redoStack.isEmpty()) return
        undoStack.addLast(project.toJson().toString()); restore(redoStack.removeLast()); lastKey = ""
    }
    private fun restore(json: String) {
        project = Project.fromJson(JSONObject(json)); sceneIdx = sceneIdx.coerceIn(0, project.scenes.size - 1); touch()
    }
    fun autosaveNow() {
        val json = project.toJson().toString(); dirty = false
        val id = project.id
        scope.launch(Dispatchers.IO) { runCatching { repo.autosaveText(id, json) } }
    }
    fun save() { repo.save(project); dirty = false; saved = true; toast("Saved") }

    fun dispose() {
        pause(); if (dirty) runCatching { repo.autosave(project) }
        scope.cancel(); cache.clear(); RigSolver.restMode = false
    }

    fun prefetch() {
        scope.launch(Dispatchers.IO) {
            project.scenes.flatMap { it.layers }.forEach { l -> (listOf(l.image) + l.states).filter { it.isNotEmpty() }.forEach { cache.get(it, 1100) } }
            withContext(Dispatchers.Main) { tick++ }
        }
    }

    // ------------------------------------------------------------------ playback
    private var playJob: Job? = null
    fun play() {
        if (playing) return
        if (time >= scene.duration - 0.02f) time = 0f
        playing = true
        var startT = time
        var t0 = -1L
        audio.start(project, scene, startT)
        playJob = scope.launch {
            while (playing) {
                withFrameNanos { n ->
                    if (t0 < 0) t0 = n
                    val t = startT + (n - t0) / 1e9f
                    if (t >= scene.duration) {
                        if (loopPlay) { startT = 0f; t0 = n; time = 0f; audio.start(project, scene, 0f) } else { time = scene.duration; pause() }
                    } else time = t
                    tick++
                }
            }
        }
    }
    fun pause() { playing = false; playJob?.cancel(); audio.stop() }
    fun seek(t: Float) { val was = playing; if (was) pause(); time = t.coerceIn(0f, scene.duration); tick++; if (was) play() }

    // ------------------------------------------------------------------ selection helpers
    fun layer(id: String = selLayer) = scene.layer(id)
    fun character(id: String = selChar) = scene.character(id)
    fun bone(id: String = selBone) = scene.bone(id)

    fun pickLayerAt(x: Float, y: Float): String? {
        for (d in renderer.drawn.asReversed()) {
            val l = scene.layer(d.id) ?: continue
            if (l.locked || !l.visible) continue
            val inv = Matrix(); if (!d.toCanvas.invert(inv)) continue
            val p = floatArrayOf(x, y); inv.mapPoints(p)
            if (p[0] >= d.l && p[0] <= d.r && p[1] >= d.t && p[1] <= d.b) return d.id
        }
        return null
    }

    fun selectLayer(id: String) {
        selLayer = id
        scene.layer(id)?.let { l -> if (l.charId.isNotEmpty()) selChar = l.charId; if (l.boneId.isNotEmpty()) selBone = l.boneId }
    }

    // ------------------------------------------------------------------ properties (base value or keyframe)
    private fun camDefault(prop: String) = when (prop) {
        "x" -> project.width / 2f; "y" -> project.height / 2f; "zoom" -> 1f; "rot" -> 0f
        "shake" -> scene.camera.shake; "hand" -> scene.camera.handheld; "focus" -> scene.camera.focusDepth; else -> 0f
    }
    fun getProp(target: String, prop: String): Float {
        Anim.eval(scene.track(target, prop), time)?.let { return it }
        if (target == "cam") return camDefault(prop)
        scene.layer(target)?.let { l -> return when (prop) {
            "x" -> l.x; "y" -> l.y; "rot" -> l.rot; "sx" -> l.sx; "sy" -> l.sy; "opacity" -> l.opacity
            "px" -> l.px; "py" -> l.py; "skx" -> l.skx; "sky" -> l.sky; else -> 0f } }
        scene.character(target)?.let { c -> return when (prop) {
            "x" -> c.x; "y" -> c.y; "rot" -> c.rot; "sx" -> c.sx; "sy" -> c.sy; "opacity" -> c.opacity; else -> 0f } }
        scene.bone(target)?.let { b -> if (rigMode) return when (prop) { "rot" -> b.rot; "x" -> b.x; "y" -> b.y; else -> 0f } }
        scene.effects.firstOrNull { it.id == target }?.let { if (prop == "intensity") return it.intensity }
        scene.lights.firstOrNull { it.id == target }?.let { l -> return when (prop) {
            "x" -> l.x; "y" -> l.y; "intensity" -> l.intensity; "radius" -> l.radius; "angle" -> l.angle; else -> 0f } }
        if (prop == "ikw") return 1f
        return 0f
    }
    fun hasTrack(target: String, prop: String) = scene.track(target, prop)?.keys?.isNotEmpty() == true
    fun hasKeyAt(target: String, prop: String) = Anim.keyAt(scene.track(target, prop), time) != null

    private fun defaultEase(prop: String) = if (prop == "eye" || prop == "brow" || prop == "mouth") Ease.HOLD else Ease.EASE_IN_OUT

    fun setProp(target: String, prop: String, v: Float, coalesce: String = "$target.$prop") {
        edit(coalesce) {
            val sc = scene
            val bone = sc.bone(target)
            val isCam = target == "cam"
            val faceProp = prop in listOf("eye", "brow", "mouth", "lookx", "looky")
            val keyed = sc.track(target, prop)?.keys?.isNotEmpty() == true
            val animate = isCam || faceProp || keyed || autoKey || (bone != null && !rigMode) || prop.startsWith("ik")
            if (animate) Anim.setKey(sc.trackOrCreate(target, prop), time, v, defaultEase(prop))
            else setBase(target, prop, v)
        }
    }
    private fun setBase(target: String, prop: String, v: Float) {
        scene.layer(target)?.let { l -> when (prop) {
            "x" -> l.x = v; "y" -> l.y = v; "rot" -> l.rot = v; "sx" -> l.sx = v; "sy" -> l.sy = v; "opacity" -> l.opacity = v
            "px" -> RigTools.setPivot(l, v, l.py); "py" -> RigTools.setPivot(l, l.px, v); "skx" -> l.skx = v; "sky" -> l.sky = v }; return }
        scene.character(target)?.let { c -> when (prop) {
            "x" -> c.x = v; "y" -> c.y = v; "rot" -> c.rot = v; "sx" -> c.sx = v; "sy" -> c.sy = v; "opacity" -> c.opacity = v }; return }
        scene.bone(target)?.let { b -> when (prop) { "rot" -> b.rot = v; "x" -> b.x = v; "y" -> b.y = v }; return }
        scene.effects.firstOrNull { it.id == target }?.let { if (prop == "intensity") it.intensity = v; return }
        scene.lights.firstOrNull { it.id == target }?.let { l -> when (prop) { "x" -> l.x = v; "y" -> l.y = v; "intensity" -> l.intensity = v; "radius" -> l.radius = v; "angle" -> l.angle = v } }
    }
    fun keyNow(target: String, prop: String) = edit { Anim.setKey(scene.trackOrCreate(target, prop), time, getProp(target, prop), defaultEase(prop)) }
    fun toggleKey(target: String, prop: String) {
        if (hasKeyAt(target, prop)) edit { scene.track(target, prop)?.let { tr -> tr.keys.removeAll { abs(it.t - time) < 0.001f }; if (tr.keys.isEmpty()) scene.removeTrack(tr) } }
        else keyNow(target, prop)
    }

    fun deleteKey(r: KeyRef) = edit {
        scene.track(r.target, r.prop)?.let { tr -> tr.keys.removeAll { abs(it.t - r.t) < 0.001f }; if (tr.keys.isEmpty()) scene.removeTrack(tr) }
        selKey = null
    }
    fun moveKey(r: KeyRef, nt: Float): KeyRef {
        val t = nt.coerceIn(0f, scene.duration)
        edit("movekey") {
            val tr = scene.track(r.target, r.prop)
            val k = tr?.keys?.firstOrNull { abs(it.t - r.t) < 0.001f }
            if (tr != null && k != null) { tr.keys.removeAll { it !== k && abs(it.t - t) < 0.001f }; k.t = t; tr.sort() }
        }
        return KeyRef(r.target, r.prop, t)
    }
    fun keyOf(r: KeyRef?): Key? = if (r == null) null else Anim.keyAt(scene.track(r.target, r.prop), r.t)
    fun setKeyEase(r: KeyRef, e: Ease) = edit { Anim.keyAt(scene.track(r.target, r.prop), r.t)?.ease = e }
    fun setKeyValue(r: KeyRef, v: Float) = edit("keyval") { Anim.keyAt(scene.track(r.target, r.prop), r.t)?.v = v }
    fun setKeyBezier(r: KeyRef, x1: Float, y1: Float, x2: Float, y2: Float) = edit("keybez") {
        Anim.keyAt(scene.track(r.target, r.prop), r.t)?.let { it.ease = Ease.BEZIER; it.x1 = x1; it.y1 = y1; it.x2 = x2; it.y2 = y2 }
    }

    // clipboard
    private class Clip(val target: String, val prop: String, val key: Key)
    private var clipboard: List<Clip> = emptyList(); private var clipT0 = 0f
    fun targetsOfSelection(): Set<String> {
        val s = HashSet<String>()
        if (selLayer.isNotEmpty()) s.add(selLayer)
        if (selChar.isNotEmpty()) { s.add(selChar); scene.bonesOf(selChar).forEach { s.add(it.id) }; scene.layers.filter { it.charId == selChar }.forEach { s.add(it.id) } }
        if (selBone.isNotEmpty()) s.add(selBone)
        return s
    }
    fun copyKeysAtTime(): Int {
        val ts = targetsOfSelection() + "cam"
        val items = ArrayList<Clip>()
        for (tr in scene.tracks) if (tr.target in ts) tr.keys.firstOrNull { abs(it.t - time) < 0.002f }?.let { items.add(Clip(tr.target, tr.prop, it.copyKey())) }
        clipboard = items; clipT0 = time; return items.size
    }
    fun copySelectedKey(): Boolean { val r = selKey ?: return false; val k = keyOf(r) ?: return false; clipboard = listOf(Clip(r.target, r.prop, k.copyKey())); return true }
    fun pasteKeys(): Int {
        if (clipboard.isEmpty()) return 0
        edit { for (c in clipboard) { val k = c.key.copyKey(); Anim.setKey(scene.trackOrCreate(c.target, c.prop), time, k.v, k.ease) } }
        return clipboard.size
    }
    fun rangeOp(op: String, t0: Float, t1: Float, arg: Float) {
        val ts = targetsOfSelection()
        edit {
            for (tr in scene.tracks.toList()) {
                if (tr.target !in ts) continue
                when (op) {
                    "duplicate" -> Anim.duplicateRange(tr, t0, t1, arg)
                    "reverse" -> Anim.reverseRange(tr, t0, t1)
                    "speed" -> Anim.speedRange(tr, t0, t1, arg)
                    "loop" -> Anim.loopRange(tr, t0, t1, arg.toInt())
                }
            }
        }
    }

    // ------------------------------------------------------------------ assets & layers
    fun importImages(uris: List<Uri>, asBackground: Boolean = false) {
        scope.launch {
            var n = 0
            for (u in uris) {
                val r = withContext(Dispatchers.IO) { repo.importImage(project.id, u) } ?: continue
                edit { addImageLayer(r.first, r.second, r.third, asBackground); if (!project.assets.contains(r.first)) project.assets.add(r.first) }
                n++
            }
            toast(if (n == 0) "Could not read that image" else "Imported $n image(s)")
        }
    }
    fun addImageLayer(file: String, w: Int, h: Int, background: Boolean): Layer {
        val l = Layer(newId(), file.substringBeforeLast('.'))
        l.image = file; l.imgW = w; l.imgH = h
        val cw = project.width.toFloat(); val ch = project.height.toFloat()
        val sc = if (background) max(cw / w, ch / h) else min(0.55f * cw / w, 0.7f * ch / h).coerceAtMost(1f).let { if (it <= 0f) 1f else it }
        l.sx = sc; l.sy = sc; l.x = cw / 2f; l.y = ch / 2f
        if (background) { l.depth = 100f; l.locked = false; l.name = "BG " + l.name }
        scene.layers.add(if (background) 0 else scene.layers.size, l)
        selLayer = l.id
        return l
    }
    fun addAssetAgain(file: String, background: Boolean = false) {
        val sz = cache.sizeOf(file) ?: return
        edit { addImageLayer(file, sz[0], sz[1], background) }
    }
    fun duplicateLayer() { val l = layer() ?: return; edit { val n = l.copyOf(); n.name = l.name + " copy"; n.x += 30f; n.y += 30f; scene.layers.add(scene.layers.indexOf(l) + 1, n); selLayer = n.id } }
    fun deleteLayer() { val l = layer() ?: return; edit { scene.layers.remove(l); scene.tracksOf(l.id).forEach { scene.removeTrack(it) }; selLayer = "" } }
    fun moveLayerOrder(delta: Int) {
        val l = layer() ?: return
        edit { val i = scene.layers.indexOf(l); val j = (i + delta).coerceIn(0, scene.layers.size - 1); scene.layers.removeAt(i); scene.layers.add(j, l) }
    }
    fun addStateImage(layer: Layer, file: String) = edit { layer.states.add(file) }
    fun attachSelectedToBone(boneId: String) {
        val l = layer() ?: return
        edit { RigTools.attachLayer(scene, l, scene.bone(boneId)); if (boneId.isEmpty()) l.charId = "" }
    }
    fun snapPivotToBone() {
        val l = layer() ?: return; val b = scene.bone(l.boneId) ?: return
        edit {
            // joint position (bone origin) is the layer's local origin after attaching; move the pivot to the joint
            val world = RigTools.layerWorldMatrix(scene, l); val inv = Matrix()
            val bm = RigTools.boneRestMatrix(scene, b); val o = floatArrayOf(0f, 0f); bm.mapPoints(o)
            if (world.invert(inv)) { inv.mapPoints(o); val npx = (o[0] / l.imgW + l.px).coerceIn(-1f, 2f); val npy = (o[1] / l.imgH + l.py).coerceIn(-1f, 2f); RigTools.setPivot(l, npx, npy) }
            RigTools.attachLayer(scene, l, b)
        }
    }

    // ------------------------------------------------------------------ characters & rigs
    fun createCharacter(name: String) = edit {
        val c = Character(newId(), name.ifBlank { "Character ${scene.characters.size + 1}" })
        c.x = project.width / 2f; c.y = project.height * 0.62f
        scene.characters.add(c); selChar = c.id
    }
    fun deleteCharacter() { val c = character() ?: return; edit {
        scene.bonesOf(c.id).forEach { b -> scene.tracksOf(b.id).forEach { scene.removeTrack(it) } }
        scene.bones.removeAll { it.charId == c.id }; scene.clips.removeAll { it.charId == c.id }
        scene.layers.filter { it.charId == c.id }.forEach { it.charId = ""; it.boneId = "" }
        scene.tracksOf(c.id).forEach { scene.removeTrack(it) }; scene.characters.remove(c); selChar = ""; selBone = "" } }
    fun assignLayerToCharacter() { val l = layer() ?: return; val c = character() ?: return; edit { l.charId = c.id } }
    fun addHumanoidRig(sideView: Boolean) { val c = character() ?: return; edit {
        scene.bones.removeAll { it.charId == c.id }; RigTools.createHumanoid(scene, c, sideView); selBone = scene.boneByRole(c.id, "hip")?.id ?: "" }; toast("Humanoid rig created – attach your parts to the bones") }
    fun autoRig(sideView: Boolean) { val c = character() ?: return
        var n = 0
        edit { n = RigTools.autoRigFromParts(scene, c, scene.layers.filter { it.charId == c.id }, sideView) }
        toast(if (n == 0) "Name parts like 'head', 'left arm', 'right thigh', 'torso' and assign them to the character first" else "Auto-rigged $n parts") }
    fun mirrorRig(from: String, layers: Boolean) { val c = character() ?: return; var n = 0; edit { n = RigTools.mirrorRig(scene, c.id, from, layers) }; toast("Mirrored $n bones") }
    fun addBone() { val c = character() ?: return; edit {
        val p = bone(); val b = Bone(newId(), "Bone ${scene.bones.size + 1}", p?.id ?: "", c.id)
        if (p != null) { b.x = p.length; b.rot = 0f } ; scene.bones.add(b); selBone = b.id } }
    fun deleteBone() { val b = bone() ?: return; edit {
        val kids = scene.bones.filter { it.parent == b.id }; kids.forEach { it.parent = b.parent }
        scene.layers.filter { it.boneId == b.id }.forEach { it.boneId = "" }
        scene.tracksOf(b.id).forEach { scene.removeTrack(it) }; scene.bones.remove(b); selBone = "" } }
    fun reparentBone(newParent: String) { val b = bone() ?: return
        // forbid cycles
        var cur = scene.bone(newParent); while (cur != null) { if (cur.id == b.id) return; cur = scene.bone(cur.parent) }
        edit { b.parent = newParent } }

    // ------------------------------------------------------------------ procedural clips
    fun addClip(preset: String) {
        val c = character() ?: run { toast("Create or select a character first"); return }
        edit {
            val cl = ProcClip(newId(), c.id, preset); cl.start = time; cl.duration = min(Presets.defaultDuration(preset), max(0.5f, scene.duration - time))
            cl.params = Presets.defaultParams(preset); cl.loop = true
            if (preset == "Walking" || preset == "Running" || preset == "Slow Walking" || preset == "Fast Walking") { cl.fade = 0.3f }
            scene.clips.add(cl); selClip = cl.id
        }
    }
    fun bakeSelectedChar() { val c = character() ?: return; var n = 0
        edit { n = RigTools.bakeProcedural(scene, c, 0f, scene.duration, 12) }; toast("Baked $n keyframes (editable on the timeline)") }

    // ------------------------------------------------------------------ face
    fun setFace(prop: String, v: Float) { val c = character() ?: return; setProp(c.id, prop, v, "face.$prop") }
    fun applyExpression(name: String) {
        val c = character() ?: return
        val e = when (name) {
            "Neutral" -> floatArrayOf(0f, 0f, 0f); "Angry" -> floatArrayOf(1f, 1f, 2f); "Sad" -> floatArrayOf(1f, 2f, 0f)
            "Fear" -> floatArrayOf(0f, 3f, 5f); "Surprised" -> floatArrayOf(0f, 4f, 3f); "Smile" -> floatArrayOf(0f, 0f, 4f)
            else -> return
        }
        edit { Anim.setKey(scene.trackOrCreate(c.id, "eye"), time, e[0], Ease.HOLD); Anim.setKey(scene.trackOrCreate(c.id, "brow"), time, e[1], Ease.HOLD); Anim.setKey(scene.trackOrCreate(c.id, "mouth"), time, e[2], Ease.HOLD) }
    }
    fun lookKey(x: Float, y: Float) { val c = character() ?: return; edit {
        Anim.setKey(scene.trackOrCreate(c.id, "lookx"), time, x, Ease.EASE_IN_OUT); Anim.setKey(scene.trackOrCreate(c.id, "looky"), time, y, Ease.EASE_IN_OUT) } }
    fun blinkKeys() { val c = character() ?: return; edit {
        val tr = scene.trackOrCreate(c.id, "eye")
        Anim.setKey(tr, time, 0f, Ease.LINEAR); Anim.setKey(tr, time + 0.06f, 1f, Ease.LINEAR); Anim.setKey(tr, time + 0.12f, 2f, Ease.LINEAR)
        Anim.setKey(tr, time + 0.2f, 1f, Ease.LINEAR); Anim.setKey(tr, time + 0.26f, 0f, Ease.LINEAR) } }

    // ------------------------------------------------------------------ audio
    fun importAudio(uri: Uri, kind: AudioKind) {
        scope.launch {
            val r = withContext(Dispatchers.IO) { repo.importAudio(project.id, uri) } ?: run { toast("Could not import audio"); return@launch }
            val dur = withContext(Dispatchers.IO) { AudioDecoder.durationSeconds(File(assetsDir, r.first)) }
            if (dur <= 0f) { toast("This audio format is not supported on this device"); return@launch }
            edit { addAudioClip(r.first, r.second, dur, kind); if (!project.assets.contains(r.first)) project.assets.add(r.first) }
        }
    }
    fun addAudioClip(file: String, name: String, dur: Float, kind: AudioKind) {
        val c = AudioClip(newId(), file, name); c.kind = kind; c.start = time; c.sourceLen = dur; c.length = dur
        if (kind == AudioKind.MUSIC || kind == AudioKind.AMBIENT) { c.loop = true; c.length = max(0.5f, scene.duration - time) }
        if (kind == AudioKind.VOICE || kind == AudioKind.DIALOGUE) c.charId = selChar
        scene.audio.add(c); selAudio = c.id
    }
    fun addSfx(name: String) {
        scope.launch {
            val file = withContext(Dispatchers.IO) { Sfx.generate(name, assetsDir) }
            val dur = withContext(Dispatchers.IO) { AudioDecoder.durationSeconds(File(assetsDir, file)) }
            val kind = if (name.contains("loop") || name == "Horror drone") AudioKind.AMBIENT else AudioKind.SFX
            edit { addAudioClip(file, name, dur, kind); if (!project.assets.contains(file)) project.assets.add(file) }
        }
    }
    fun lipSync(clipId: String) {
        val c = scene.audio.firstOrNull { it.id == clipId } ?: return
        val cid = c.charId.ifEmpty { selChar }
        if (cid.isEmpty() || scene.character(cid) == null) { toast("Pick a speaking character for this clip first"); return }
        scope.launch {
            val pcm = withContext(Dispatchers.IO) { AudioDecoder.get(File(assetsDir, c.file)) } ?: run { toast("Cannot read audio"); return@launch }
            var n = 0
            edit { n = LipSync.generate(scene, c, cid, pcm); c.charId = cid }
            toast("Generated $n mouth keyframes – edit them on the timeline")
        }
    }
    fun peaks(c: AudioClip, buckets: Int): FloatArray? {
        val pcm = AudioDecoder.get(File(assetsDir, c.file)) ?: return null
        return LipSync.peaks(pcm, buckets)
    }

    // ------------------------------------------------------------------ camera presets
    fun cameraPreset(name: String, dur: Float) {
        val sc = scene; val t0 = time; val w = project.width / 2f; val h = project.height / 2f
        edit {
            fun k(prop: String, t: Float, v: Float, e: Ease = Ease.EASE_IN_OUT) = Anim.setKey(sc.trackOrCreate("cam", prop), t, v, e)
            when (name) {
                "Horror Zoom" -> { k("zoom", t0, 1f); k("zoom", t0 + dur, 1.45f, Ease.EASE_IN); k("hand", t0, 0.4f); k("hand", t0 + dur, 1.4f) }
                "Slow Push In" -> { k("zoom", t0, 1f, Ease.LINEAR); k("zoom", t0 + dur, 1.2f, Ease.LINEAR) }
                "Fast Zoom" -> { k("zoom", t0, 1f, Ease.EASE_IN); k("zoom", t0 + min(dur, 0.45f), 1.7f, Ease.EASE_OUT) }
                "Shake" -> { k("shake", t0, 0f, Ease.LINEAR); k("shake", t0 + 0.05f, 1f, Ease.LINEAR); k("shake", t0 + dur, 1f, Ease.LINEAR); k("shake", t0 + dur + 0.25f, 0f, Ease.LINEAR) }
                "Heartbeat Camera" -> { var t = t0; var i = 0; while (t < t0 + dur) { k("zoom", t, 1f, Ease.EASE_OUT); k("zoom", t + 0.12f, 1.035f, Ease.EASE_OUT); k("zoom", t + 0.26f, 1.005f, Ease.EASE_OUT); k("zoom", t + 0.38f, 1.05f, Ease.EASE_OUT); k("zoom", t + 0.65f, 1f, Ease.EASE_IN_OUT); t += 1.0f; i++ } }
                "Reveal" -> { k("zoom", t0, 1.6f, Ease.EASE_OUT); k("zoom", t0 + dur, 1f, Ease.EASE_OUT); k("x", t0, w * 0.8f, Ease.EASE_OUT); k("y", t0, h * 0.55f, Ease.EASE_OUT); k("x", t0 + dur, w, Ease.EASE_OUT); k("y", t0 + dur, h, Ease.EASE_OUT) }
                "Dramatic Pull Back" -> { k("zoom", t0, 1.8f); k("zoom", t0 + dur, 0.95f); k("y", t0, h * 0.8f); k("y", t0 + dur, h) }
            }
        }
    }
    fun cameraFollow(char: String, amt: Float) = edit { scene.camera.followChar = char; scene.camera.followAmt = amt }

    // ------------------------------------------------------------------ effects & lights
    fun addEffect(type: FxType): Effect { val e = FxDefs.create(type); edit { scene.effects.add(e); selFx = e.id }; return e }
    fun addEffectObj(e: Effect) = edit { scene.effects.add(e); selFx = e.id }
    fun deleteEffect(id: String) = edit { scene.effects.removeAll { it.id == id }; scene.tracksOf(id).forEach { scene.removeTrack(it) }; selFx = "" }
    fun addLight(type: LightType) = edit {
        val l = Light(newId(), type); l.name = type.label; l.x = project.width / 2f; l.y = project.height / 2f
        when (type) {
            LightType.FLASHLIGHT -> { l.color = 0xFFFFF2CC.toInt(); l.radius = 650f; l.cone = 22f; l.falloff = 1.0f; l.flicker = 0.08f }
            LightType.HEADLIGHTS -> { l.color = 0xFFFFFFE0.toInt(); l.radius = 900f; l.cone = 16f; l.falloff = 0.9f; l.flicker = 0f }
            LightType.CANDLE -> { l.color = 0xFFFFA24A.toInt(); l.radius = 260f; l.flicker = 0.5f }
            LightType.BULB -> { l.color = 0xFFFFE9B0.toInt(); l.radius = 520f; l.flicker = 0.7f }
            LightType.SPOT -> { l.color = 0xFFCFE0FF.toInt(); l.radius = 700f; l.cone = 30f }
            else -> { l.color = 0xFFFFC878.toInt(); l.radius = 420f; l.flicker = 0.25f }
        }
        if (scene.ambient < 0.3f) scene.ambient = 0.75f
        scene.lights.add(l); selLight = l.id
    }
    fun deleteLight(id: String) = edit { scene.lights.removeAll { it.id == id }; scene.tracksOf(id).forEach { scene.removeTrack(it) }; selLight = "" }

    // ------------------------------------------------------------------ scenes
    fun addScene() = edit { val s = Scene(newId(), "Scene ${project.scenes.size + 1}"); project.scenes.add(s); sceneIdx = project.scenes.lastIndex; time = 0f }
    fun duplicateScene() = edit { val s = Scene.fromJson(JSONObject(scene.toJson().toString())); s.id = newId(); s.name += " copy"; project.scenes.add(sceneIdx + 1, s); sceneIdx++ }
    fun deleteScene() { if (project.scenes.size <= 1) { toast("A project needs at least one scene"); return }; edit { project.scenes.removeAt(sceneIdx); sceneIdx = sceneIdx.coerceIn(0, project.scenes.size - 1) }; time = 0f }
    fun gotoScene(i: Int) { pause(); sceneIdx = i.coerceIn(0, project.scenes.size - 1); time = 0f; selLayer = ""; selChar = scene.characters.firstOrNull()?.id ?: ""; selBone = ""; selKey = null; tick++; version++ }

    // ------------------------------------------------------------------ library
    fun libSave(type: String, name: String): Boolean {
        val sc = scene
        val c = character()
        val payload = JSONObject(); val assets = HashSet<String>()
        when (type) {
            "character", "rig" -> {
                c ?: return false
                payload.put("char", c.toJson()); payload.put("bones", JSONArray().also { a -> sc.bonesOf(c.id).forEach { a.put(it.toJson()) } })
                if (type == "character") {
                    val ls = sc.layers.filter { it.charId == c.id }
                    payload.put("layers", JSONArray().also { a -> ls.forEach { a.put(it.toJson()); assets.add(it.image); assets.addAll(it.states) } })
                }
            }
            "pose" -> { c ?: return false; payload.put("pose", RigTools.capturePose(sc, c, time, name).toJson()) }
            "expression" -> { c ?: return false
                val cp = RigSolver.solve(sc, c, time, sc.wind)
                payload.put("eye", cp.eye.toDouble()).put("brow", cp.brow.toDouble()).put("mouth", cp.mouth.toDouble()).put("lookx", cp.lookx.toDouble()).put("looky", cp.looky.toDouble()) }
            "animation" -> { c ?: return false
                payload.put("clips", JSONArray().also { a -> sc.clips.filter { it.charId == c.id }.forEach { a.put(it.toJson()) } })
                val roleOf = sc.bonesOf(c.id).associate { it.id to RigTools.boneKey(it) }
                payload.put("tracks", JSONArray().also { a -> sc.tracks.filter { it.target == c.id || it.target in roleOf }.forEach {
                    a.put(JSONObject().put("target", if (it.target == c.id) "char" else "bone:" + roleOf[it.target]).put("prop", it.prop).put("keys", it.toJson().getJSONArray("keys"))) } }) }
            "prop", "background" -> { val l = layer() ?: return false; payload.put("layer", l.toJson()); assets.add(l.image) }
            "effect" -> { val e = scene.effects.firstOrNull { it.id == selFx } ?: return false; payload.put("effect", e.toJson()) }
            else -> return false
        }
        repo.libraryPut(type, name.ifBlank { type }, payload, project.id, assets.filter { it.isNotEmpty() })
        return true
    }
    fun libLoad(item: ProjectRepo.LibItem) {
        val data = repo.libraryData(item); val sc = scene
        val map = repo.libraryCopyAssets(item, project.id)
        fun m(s: String) = map[s] ?: s
        edit {
            when (item.type) {
                "character" -> {
                    val old = Character.fromJson(data.getJSONObject("char")); val nid = newId(); val c = Character.fromJson(data.getJSONObject("char")); c.id = nid
                    c.x = project.width / 2f; sc.characters.add(c)
                    val idMap = HashMap<String, String>()
                    data.getJSONArray("bones").objects().forEach { o -> val b = Bone.fromJson(o); val n = newId(); idMap[b.id] = n; b.id = n; b.charId = nid; sc.bones.add(b) }
                    sc.bones.filter { it.charId == nid }.forEach { b -> b.parent = idMap[b.parent] ?: "" }
                    data.optJSONArray("layers")?.objects()?.forEach { o -> val l = Layer.fromJson(o); l.id = newId(); l.charId = nid; l.boneId = idMap[l.boneId] ?: ""; l.image = m(l.image); l.states = l.states.map { m(it) }.toMutableList()
                        if (!project.assets.contains(l.image) && l.image.isNotEmpty()) project.assets.add(l.image); sc.layers.add(l) }
                    selChar = nid; if (old.id.isEmpty()) selChar = nid
                }
                "rig" -> { val c = character() ?: return@edit
                    sc.bones.removeAll { it.charId == c.id }
                    val idMap = HashMap<String, String>()
                    data.getJSONArray("bones").objects().forEach { o -> val b = Bone.fromJson(o); val n = newId(); idMap[b.id] = n; b.id = n; b.charId = c.id; sc.bones.add(b) }
                    sc.bones.filter { it.charId == c.id }.forEach { b -> b.parent = idMap[b.parent] ?: "" } }
                "pose" -> { val c = character() ?: return@edit; RigTools.applyPose(sc, c, JSONObjectHelper.poseFrom(data.getJSONObject("pose")), time, false) }
                "expression" -> { val c = character() ?: return@edit
                    for (p in listOf("eye", "brow", "mouth", "lookx", "looky")) Anim.setKey(sc.trackOrCreate(c.id, p), time, data.f(p), if (p == "lookx" || p == "looky") Ease.EASE_IN_OUT else Ease.HOLD) }
                "animation" -> { val c = character() ?: return@edit
                    data.optJSONArray("clips")?.objects()?.forEach { o -> val cl = ProcClip.fromJson(o); cl.id = newId(); cl.charId = c.id; cl.start += time; sc.clips.add(cl) }
                    data.optJSONArray("tracks")?.objects()?.forEach { o ->
                        val t = o.s("target")
                        val target = if (t == "char") c.id else sc.bonesOf(c.id).firstOrNull { RigTools.boneKey(it) == t.removePrefix("bone:") }?.id
                        if (target != null) { val tr = sc.trackOrCreate(target, o.s("prop")); o.getJSONArray("keys").objects().forEach { ko -> val k = Key.fromJson(ko); k.t += time; tr.keys.removeAll { x -> abs(x.t - k.t) < 0.001f }; tr.keys.add(k) }; tr.sort() } } }
                "prop", "background" -> { val l = Layer.fromJson(data.getJSONObject("layer")); l.id = newId(); l.image = m(l.image); l.charId = ""; l.boneId = ""
                    if (!project.assets.contains(l.image)) project.assets.add(l.image)
                    if (item.type == "background") sc.layers.add(0, l) else sc.layers.add(l); selLayer = l.id }
                "effect" -> { val e = Effect.fromJson(data.getJSONObject("effect")); e.id = newId(); sc.effects.add(e); selFx = e.id }
            }
        }
        cache.assetDir = assetsDir; prefetch()
    }

    // ------------------------------------------------------------------ export
    fun export(heightPx: Int, fps: Int, bpp: Float, allScenes: Boolean) {
        if (exportProgress >= 0f) return
        pause(); exportCancel = false; exportProgress = 0f; exportText = "Preparing…"
        val scenes = if (allScenes) project.scenes.toList() else listOf(scene)
        val st = ExportSettings(heightPx, fps, bpp, allScenes)
        val proj = Project.fromJson(JSONObject(project.toJson().toString()))   // render from a snapshot
        val sceneSnap = if (allScenes) proj.scenes else listOf(proj.scenes[sceneIdx])
        scope.launch {
            val tmp = File(ctx.cacheDir, "stx_out.mp4")
            val r = withContext(Dispatchers.Default) {
                Exporter.export(proj, assetsDir, sceneSnap, st, tmp, ctx.cacheDir, { p, s -> exportProgress = p; exportText = s }, { exportCancel })
            }
            if (r.ok) {
                val where = withContext(Dispatchers.IO) { publish(tmp) }
                exportText = "Saved: $where"; toast("Exported to $where")
            } else { exportText = r.message; toast(r.message) }
            delay(50); exportProgress = -1f
        }
    }
    fun cancelExport() { exportCancel = true }
    private fun publish(f: File): String {
        val name = "${project.name.replace(Regex("[^A-Za-z0-9_-]"), "_")}_${System.currentTimeMillis() / 1000}.mp4"
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                val cv = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, name); put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/STXHorrorAnimator")
                }
                val uri = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)!!
                ctx.contentResolver.openOutputStream(uri)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
                "Movies/STXHorrorAnimator/$name"
            } else {
                val d = ctx.getExternalFilesDir(Environment.DIRECTORY_MOVIES)!!.also { it.mkdirs() }
                f.copyTo(File(d, name), true); File(d, name).absolutePath
            }
        } catch (e: Exception) {
            val d = ctx.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: ctx.filesDir
            d.mkdirs(); f.copyTo(File(d, name), true); File(d, name).absolutePath
        }
    }
}
