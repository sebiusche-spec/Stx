package com.stx.horror.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import com.stx.horror.model.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

class ProjectInfo(val id: String, val name: String, val modified: Long, val scenes: Int, val hasRecovery: Boolean)

/** Projects live in filesDir/projects/<id>/{project.json, autosave.json, assets/}. */
class ProjectRepo(private val ctx: Context) {
    val root = File(ctx.filesDir, "projects").also { it.mkdirs() }
    val libraryRoot = File(ctx.filesDir, "library").also { it.mkdirs() }

    fun dir(id: String) = File(root, id).also { it.mkdirs() }
    fun assetsDir(id: String) = File(dir(id), "assets").also { it.mkdirs() }

    fun list(): List<ProjectInfo> = (root.listFiles() ?: emptyArray()).filter { it.isDirectory }.mapNotNull { d ->
        val f = File(d, "project.json"); val a = File(d, "autosave.json")
        val src = if (f.exists()) f else if (a.exists()) a else return@mapNotNull null
        try {
            val o = JSONObject(src.readText())
            ProjectInfo(d.name, o.s("name", "Untitled"), maxOf(src.lastModified(), o.optLong("modified")), o.optJSONArray("scenes")?.length() ?: 0,
                a.exists() && (!f.exists() || a.lastModified() > f.lastModified()))
        } catch (e: Exception) { null }
    }.sortedByDescending { it.modified }

    fun create(name: String, width: Int, height: Int, fps: Int): Project {
        val p = Project(newId(), name.ifBlank { "Untitled" }); p.width = width; p.height = height; p.fps = fps
        p.scenes.add(Scene(newId(), "Scene 1"))
        save(p); return p
    }

    fun load(id: String, preferAutosave: Boolean): Project? {
        val d = dir(id)
        val f = if (preferAutosave && File(d, "autosave.json").exists()) File(d, "autosave.json") else File(d, "project.json")
        if (!f.exists()) return null
        return try { Project.fromJson(JSONObject(f.readText())) } catch (e: Exception) {
            // corrupt file -> try the other one
            val alt = if (f.name == "project.json") File(d, "autosave.json") else File(d, "project.json")
            try { if (alt.exists()) Project.fromJson(JSONObject(alt.readText())) else null } catch (e2: Exception) { null }
        }
    }

    /** Atomic write: temp file + rename so a crash can never leave a half written project. */
    private fun atomicWrite(target: File, text: String) {
        val tmp = File(target.parentFile, target.name + ".tmp")
        FileOutputStream(tmp).use { it.write(text.toByteArray(Charsets.UTF_8)); it.fd.sync() }
        if (!tmp.renameTo(target)) { target.delete(); tmp.renameTo(target) }
    }

    fun save(p: Project) {
        p.modified = System.currentTimeMillis()
        atomicWrite(File(dir(p.id), "project.json"), p.toJson().toString())
        File(dir(p.id), "autosave.json").delete()
    }
    fun autosave(p: Project) { atomicWrite(File(dir(p.id), "autosave.json"), p.toJson().toString()) }
    fun autosaveText(id: String, json: String) { atomicWrite(File(dir(id), "autosave.json"), json) }
    fun discardAutosave(id: String) { File(dir(id), "autosave.json").delete() }
    fun hasRecovery(id: String): Boolean {
        val a = File(dir(id), "autosave.json"); val f = File(dir(id), "project.json")
        return a.exists() && (!f.exists() || a.lastModified() > f.lastModified())
    }
    fun delete(id: String) { dir(id).deleteRecursively() }

    fun rename(id: String, name: String) { load(id, false)?.let { it.name = name; save(it) } }
    fun duplicate(id: String): String? {
        val p = load(id, false) ?: return null
        val nid = newId()
        File(dir(id), "assets").copyRecursively(File(dir(nid), "assets"), true)
        p.id = nid; p.name = p.name + " copy"; save(p); return nid
    }

    // ------------------------------------------------------------ asset import
    fun displayName(uri: Uri): String {
        var name = "asset"
        runCatching {
            ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && c.moveToFirst()) name = c.getString(i)
            }
        }
        return name
    }

    private fun uniqueName(dir: File, base: String): String {
        val clean = base.replace(Regex("[^A-Za-z0-9._-]"), "_")
        var n = clean; var i = 1
        val dot = clean.lastIndexOf('.')
        val stem = if (dot > 0) clean.substring(0, dot) else clean; val ext = if (dot > 0) clean.substring(dot) else ""
        while (File(dir, n).exists()) { n = "${stem}_$i$ext"; i++ }
        return n
    }

    /** Copies an image into the project (kept as PNG when it has transparency, otherwise the original bytes). Returns file name + size. */
    fun importImage(projectId: String, uri: Uri): Triple<String, Int, Int>? {
        return try {
            val dest = assetsDir(projectId)
            val orig = displayName(uri)
            val lower = orig.lowercase()
            val ext = when { lower.endsWith(".png") -> ".png"; lower.endsWith(".webp") -> ".webp"; lower.endsWith(".jpg") || lower.endsWith(".jpeg") -> ".jpg"; else -> ".png" }
            val stem = orig.substringBeforeLast('.', orig)
            val name = uniqueName(dest, stem + ext)
            val f = File(dest, name)
            ctx.contentResolver.openInputStream(uri)?.use { ins -> FileOutputStream(f).use { out -> ins.copyTo(out) } } ?: return null
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.absolutePath, o)
            if (o.outWidth <= 0) { f.delete(); return null }
            Triple(name, o.outWidth, o.outHeight)
        } catch (e: Exception) { null }
    }

    fun importAudio(projectId: String, uri: Uri): Pair<String, String>? {
        return try {
            val dest = assetsDir(projectId)
            val orig = displayName(uri)
            val name = uniqueName(dest, orig)
            val input = ctx.contentResolver.openInputStream(uri) ?: return null
            input.use { ins -> FileOutputStream(File(dest, name)).use { out -> ins.copyTo(out) } }
            name to orig.substringBeforeLast('.', orig)
        } catch (e: Exception) { null }
    }

    fun saveBitmap(projectId: String, bmp: Bitmap, baseName: String): String {
        val dest = assetsDir(projectId)
        val name = uniqueName(dest, baseName.removeSuffix(".png") + ".png")
        FileOutputStream(File(dest, name)).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        return name
    }

    // ------------------------------------------------------------ library (characters, rigs, poses, ... reusable across projects)
    class LibItem(val file: File, val type: String, val name: String)

    fun libraryList(type: String? = null): List<LibItem> =
        (libraryRoot.listFiles() ?: emptyArray()).filter { it.isDirectory }.mapNotNull { d ->
            val m = File(d, "item.json"); if (!m.exists()) return@mapNotNull null
            runCatching { val o = JSONObject(m.readText()); LibItem(d, o.s("type"), o.s("name")) }.getOrNull()
        }.filter { type == null || it.type == type }.sortedBy { it.name.lowercase() }

    fun libraryPut(type: String, name: String, payload: JSONObject, assetSourceProject: String?, assetFiles: Collection<String>): File {
        val d = File(libraryRoot, "${type}_${newId()}").also { it.mkdirs() }
        File(d, "item.json").writeText(JSONObject().put("type", type).put("name", name).put("data", payload)
            .put("assets", assetFiles.toList().toJsonArray()).toString())
        if (assetSourceProject != null && assetFiles.isNotEmpty()) {
            val ad = File(d, "assets").also { it.mkdirs() }
            for (a in assetFiles) { val s = File(assetsDir(assetSourceProject), a); if (s.exists()) s.copyTo(File(ad, a), true) }
        }
        return d
    }
    fun libraryData(item: LibItem): JSONObject = JSONObject(File(item.file, "item.json").readText()).getJSONObject("data")
    fun libraryAssets(item: LibItem): List<String> = JSONObject(File(item.file, "item.json").readText()).optJSONArray("assets")?.strings() ?: emptyList()
    /** Copies the library item's asset files into the project, returning old-name -> new-name mapping. */
    fun libraryCopyAssets(item: LibItem, projectId: String): Map<String, String> {
        val map = HashMap<String, String>()
        val ad = File(item.file, "assets"); val dest = assetsDir(projectId)
        for (a in libraryAssets(item)) {
            val s = File(ad, a); if (!s.exists()) continue
            val same = File(dest, a)
            if (same.exists() && same.length() == s.length()) { map[a] = a; continue }
            val n = uniqueName(dest, a); s.copyTo(File(dest, n), true); map[a] = n
        }
        return map
    }
    fun libraryDelete(item: LibItem) { item.file.deleteRecursively() }
}
