package com.stx.horror.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.ui.draw.scale
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.roundToInt

object C {
    val Bg = Color(0xFF0A0B10); val Panel = Color(0xFF12141D); val Panel2 = Color(0xFF191C28); val Line = Color(0xFF2A2E40)
    val Neon = Color(0xFF00E5FF); val Red = Color(0xFFFF2E4D); val Violet = Color(0xFFB388FF); val Amber = Color(0xFFFFD60A)
    val Text = Color(0xFFE8EAF2); val Muted = Color(0xFF8D93A8); val Green = Color(0xFF39FF8A)
}

@Composable
fun StxTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(primary = C.Neon, secondary = C.Red, tertiary = C.Violet, background = C.Bg, surface = C.Panel,
            onPrimary = Color.Black, onSurface = C.Text, onBackground = C.Text, surfaceVariant = C.Panel2, outline = C.Line),
        content = content
    )
}

@Composable
fun Glass(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.background(Brush.verticalGradient(listOf(Color(0xEE171A26), Color(0xEE0F1119))), RoundedCornerShape(14.dp))
            .border(BorderStroke(1.dp, Brush.linearGradient(listOf(Color(0x5500E5FF), Color(0x33FF2E4D)))), RoundedCornerShape(14.dp)).padding(10.dp),
        content = content
    )
}

@Composable
fun Neon(text: String, modifier: Modifier = Modifier, color: Color = C.Neon, enabled: Boolean = true, onClick: () -> Unit) {
    OutlinedButton(onClick, modifier, enabled = enabled, shape = RoundedCornerShape(10.dp), border = BorderStroke(1.dp, if (enabled) color else C.Line),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = color), contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)) {
        Text(text, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun Tag(text: String, selected: Boolean, color: Color = C.Neon, onClick: () -> Unit) {
    Box(Modifier.padding(2.dp).background(if (selected) color.copy(alpha = 0.22f) else C.Panel2, RoundedCornerShape(8.dp))
        .border(BorderStroke(1.dp, if (selected) color else C.Line), RoundedCornerShape(8.dp)).clickable { onClick() }.padding(horizontal = 9.dp, vertical = 6.dp)) {
        Text(text, fontSize = 12.sp, color = if (selected) color else C.Text, maxLines = 1)
    }
}

@Composable fun Label(text: String, color: Color = C.Muted) { Text(text, color = color, fontSize = 11.sp, fontWeight = FontWeight.Medium) }
@Composable fun Title(text: String) { Text(text.uppercase(), color = C.Neon, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp, modifier = Modifier.padding(vertical = 4.dp)) }

@Composable
fun Sl(label: String, value: Float, min: Float, max: Float, keyed: Boolean? = null, onKey: (() -> Unit)? = null, fmt: String = "%.2f", onChange: (Float) -> Unit) {
    Row(Modifier.fillMaxWidth().height(34.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = C.Muted, fontSize = 11.sp, modifier = Modifier.width(78.dp), maxLines = 1, overflow = TextOverflow.Ellipsis)
        Slider(value = value.coerceIn(min, max), onValueChange = onChange, valueRange = min..max, modifier = Modifier.weight(1f),
            colors = SliderDefaults.colors(thumbColor = C.Neon, activeTrackColor = C.Neon, inactiveTrackColor = C.Line))
        Text(String.format(fmt, value), color = C.Text, fontSize = 11.sp, modifier = Modifier.width(48.dp))
        if (onKey != null) {
            Box(Modifier.size(26.dp).clickable { onKey() }, contentAlignment = Alignment.Center) {
                Text(if (keyed == true) "◆" else "◇", color = if (keyed == true) C.Amber else C.Muted, fontSize = 16.sp)
            }
        }
    }
}

@Composable
fun <T> Pick(label: String, options: List<T>, selected: T?, name: (T) -> String, onSelect: (T) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        Neon(label + ": " + (selected?.let(name) ?: "—"), color = C.Violet) { open = true }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { o -> DropdownMenuItem(text = { Text(name(o), fontSize = 13.sp) }, onClick = { open = false; onSelect(o) }) }
        }
    }
}

@Composable
fun Toggle(label: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Switch(value, onChange, modifier = Modifier.scale(0.75f), colors = SwitchDefaults.colors(checkedTrackColor = C.Neon, checkedThumbColor = Color.Black))
        Text(label, color = C.Text, fontSize = 12.sp)
    }
}

@Composable
fun NumberInput(label: String, value: String, onValue: (String) -> Unit) {
    OutlinedTextField(value, onValue, label = { Text(label, fontSize = 11.sp) }, singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp, color = C.Text),
        modifier = Modifier.fillMaxWidth())
}

fun fmtTime(t: Float): String { val m = (t / 60).toInt(); val s = t - m * 60; return String.format("%d:%05.2f", m, s) }
