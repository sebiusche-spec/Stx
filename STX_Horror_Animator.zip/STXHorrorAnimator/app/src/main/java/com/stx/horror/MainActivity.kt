package com.stx.horror

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.stx.horror.data.ProjectRepo
import com.stx.horror.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StxTheme { Surface0 { App() } } }
    }
}

@Composable
fun Surface0(content: @Composable () -> Unit) { Box(Modifier.fillMaxSize().background(C.Bg)) { content() } }

@Composable
fun App() {
    val ctx = LocalContext.current
    val repo = remember { ProjectRepo(ctx) }
    var editor by remember { mutableStateOf<EditorState?>(null) }
    var settings by remember { mutableStateOf(false) }

    when {
        settings -> { BackHandler { settings = false }; SettingsScreen(onBack = { settings = false }) }
        editor != null -> {
            val st = editor!!
            BackHandler { st.save(); st.dispose(); editor = null }
            EditorScreen(st, onExit = { st.save(); st.dispose(); editor = null })
        }
        else -> HomeScreen(repo, onOpen = { editor = it }, onSettings = { settings = true })
    }
}
