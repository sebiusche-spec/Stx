package com.stx.horror.ui

import android.content.Context
import android.graphics.*
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import com.stx.horror.engine.RigSolver
import com.stx.horror.engine.RigTools
import com.stx.horror.model.*
import kotlin.math.*

/**
 * The animation canvas. Draws the real renderer output plus editing overlays (selection, pivot, bones, IK handles)
 * and handles touch: 1 finger select/move, 2 fingers pinch-zoom + pan (+ twist to rotate in the rotate tool), long press = menu.
 */
class StageView(ctx: Context) : View(ctx) {
    var state: EditorState? = null
    var onLongPress: ((String?, Float, Float) -> Unit)? = null
    var onSelection: (() -> Unit)? = null

    private var vs = 1f; private var tx = 0f; private var ty = 0f
    private var fitted = false
    private var renderScale = 1f
    private val vm = Matrix(); private val vinv = Matrix()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val neon = 0xFF00E5FF.toInt(); private val red = 0xFFFF2E4D.toInt()

    private fun frameW() = state?.project?.width?.toFloat() ?: 1920f
    private fun frameH() = state?.project?.height?.toFloat() ?: 1080f

    private fun fit() {
        val st = state ?: return
        val s = min(width / frameW(), height / frameH()) * 0.94f
        vs = s; tx = (width - frameW() * s) / 2f; ty = (height - frameH() * s) / 2f; fitted = true
    }
    fun resetView() { fitted = false; invalidate() }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { super.onSizeChanged(w, h, ow, oh); fitted = false }

    override fun onDraw(c: Canvas) {
        val st = state ?: return
        c.drawColor(0xFF0B0C12.toInt())
        if (!fitted) fit()
        val fw = frameW(); val fh = frameH()
        val dispW = fw * vs
        val q = if (st.lowPreview) 0 else 1
        renderScale = if (st.playing || st.lowPreview) min(1f, 960f / dispW).coerceIn(0.35f, 1f) * (if (st.lowPreview) 0.75f else 1f) else min(1f, 1600f / dispW).coerceAtLeast(0.4f)
        val outW = max(32, (dispW * renderScale).toInt()); val outH = max(18, (fh * vs * renderScale).toInt())
        RigSolver.restMode = st.rigMode && !st.playing
        c.save()
        c.translate(tx, ty); c.scale(1f / renderScale, 1f / renderScale)
        c.clipRect(0f, 0f, outW.toFloat(), outH.toFloat())
        try { st.renderer.render(c, outW, outH, st.project, st.scene, st.time, q) } catch (e: Exception) { }
        c.restore()
        // view matrix: render px -> view px
        vm.reset(); vm.postScale(1f / renderScale, 1f / renderScale); vm.postTranslate(tx, ty); vm.invert(vinv)
        // frame border
        p.reset(); p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = 0x66FFFFFF
        c.drawRect(tx, ty, tx + fw * vs, ty + fh * vs, p)
        if (st.showGrid) drawGrid(c, fw, fh)
        if (!st.playing) drawOverlays(c, st)
    }

    private fun drawGrid(c: Canvas, fw: Float, fh: Float) {
        p.reset(); p.style = Paint.Style.STROKE; p.strokeWidth = 1f; p.color = 0x33FFFFFF
        for (i in 1..2) { c.drawLine(tx + fw * vs * i / 3f, ty, tx + fw * vs * i / 3f, ty + fh * vs, p); c.drawLine(tx, ty + fh * vs * i / 3f, tx + fw * vs, ty + fh * vs * i / 3f, p) }
        p.color = 0x22FF2E4D; c.drawRect(tx + fw * vs * 0.05f, ty + fh * vs * 0.05f, tx + fw * vs * 0.95f, ty + fh * vs * 0.95f, p)
    }

    private fun toView(m: Matrix, x: Float, y: Float): FloatArray { val a = floatArrayOf(x, y); m.mapPoints(a); vm.mapPoints(a); return a }

    private fun drawOverlays(c: Canvas, st: EditorState) {
        val sc = st.scene
        // selected layer box + pivot
        val l = st.layer()
        if (l != null) {
            val d = st.renderer.drawn.lastOrNull { it.id == l.id }
            if (d != null) {
                val pts = arrayOf(toView(d.toCanvas, 0f, 0f), toView(d.toCanvas, d.r, 0f), toView(d.toCanvas, d.r, d.b), toView(d.toCanvas, 0f, d.b))
                p.reset(); p.isAntiAlias = true; p.style = Paint.Style.STROKE; p.strokeWidth = 2.5f; p.color = neon
                val path = Path(); path.moveTo(pts[0][0], pts[0][1]); for (i in 1..3) path.lineTo(pts[i][0], pts[i][1]); path.close(); c.drawPath(path, p)
                val pv = toView(d.toCanvas, l.px * d.r, l.py * d.b)
                p.color = red; p.strokeWidth = 3f; c.drawCircle(pv[0], pv[1], 14f, p); c.drawLine(pv[0] - 22f, pv[1], pv[0] + 22f, pv[1], p); c.drawLine(pv[0], pv[1] - 22f, pv[0], pv[1] + 22f, p)
            }
        }
        // bones
        if (st.showBones || st.tool == "bone" || st.tool == "ik") {
            for (ch in sc.characters) {
                val cp = st.renderer.lastPoses[ch.id] ?: continue
                val toCanvas = Matrix(st.renderer.lastCam); toCanvas.preConcat(cp.matrix)
                for (b in sc.bonesOf(ch.id)) {
                    val bp = cp.bones[b.id] ?: continue
                    val o = toView(toCanvas, bp.x, bp.y)
                    val rad = Math.toRadians(bp.rot.toDouble())
                    val e = toView(toCanvas, bp.x + cos(rad).toFloat() * b.length, bp.y + sin(rad).toFloat() * b.length)
                    val sel = b.id == st.selBone
                    p.reset(); p.isAntiAlias = true; p.style = Paint.Style.STROKE; p.strokeWidth = if (sel) 5f else 2.5f
                    p.color = if (sel) 0xFFFFD60A.toInt() else if (b.ikLen > 0) 0xFFB388FF.toInt() else 0xCC00E5FF.toInt()
                    c.drawLine(o[0], o[1], e[0], e[1], p)
                    p.style = Paint.Style.FILL; c.drawCircle(o[0], o[1], if (sel) 14f else 9f, p)
                    if (b.ikLen > 0 || sel) { p.style = Paint.Style.STROKE; c.drawCircle(e[0], e[1], 12f, p) }
                }
            }
        }
        // lights
        for (li in sc.lights) {
            val v = toView(st.renderer.lastCam, li.x, li.y)
            p.reset(); p.isAntiAlias = true; p.style = Paint.Style.STROKE; p.strokeWidth = if (li.id == st.selLight) 4f else 2f; p.color = li.color or 0xFF000000.toInt()
            c.drawCircle(v[0], v[1], 16f, p)
        }
    }

    // ------------------------------------------------------------------ touch
    private var lastX = 0f; private var lastY = 0f
    private var mode = 0                // 0 none, 1 drag layer, 2 view gesture, 3 rotate bone, 4 move joint, 5 ik, 6 pivot
    private var downX = 0f; private var downY = 0f; private var moved = false
    private var pinchDist = 0f; private var pinchAng = 0f; private var pinchMidX = 0f; private var pinchMidY = 0f
    private var parentInv = Matrix()
    private var dragBoneId = ""

    private val gd = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onLongPress(e: MotionEvent) {
            if (mode == 2 || moved) return
            val st = state ?: return
            val id = pick(e.x, e.y); if (id != null) st.selectLayer(id)
            onLongPress?.invoke(id, e.x, e.y); onSelection?.invoke()
        }
        override fun onDoubleTap(e: MotionEvent): Boolean { fitted = false; invalidate(); return true }
    })

    private fun pick(x: Float, y: Float): String? {
        val st = state ?: return null
        val a = floatArrayOf(x, y); vinv.mapPoints(a)
        return st.pickLayerAt(a[0], a[1])
    }

    /** Find a bone handle near the touch (origin or tip). Returns id and whether the tip was hit. */
    private fun pickBone(x: Float, y: Float): Pair<String, Boolean>? {
        val st = state ?: return null
        var best: Pair<String, Boolean>? = null; var bd = 46f
        for (ch in st.scene.characters) {
            val cp = st.renderer.lastPoses[ch.id] ?: continue
            val toCanvas = Matrix(st.renderer.lastCam); toCanvas.preConcat(cp.matrix)
            for (b in st.scene.bonesOf(ch.id)) {
                val bp = cp.bones[b.id] ?: continue
                val o = toView(toCanvas, bp.x, bp.y)
                val rad = Math.toRadians(bp.rot.toDouble())
                val e = toView(toCanvas, bp.x + cos(rad).toFloat() * b.length, bp.y + sin(rad).toFloat() * b.length)
                val d0 = hypot(o[0] - x, o[1] - y); val d1 = hypot(e[0] - x, e[1] - y)
                if (d0 < bd) { bd = d0; best = b.id to false }
                if (d1 < bd - 6f) { bd = d1 - 6f; best = b.id to true }
            }
        }
        return best
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        val st = state ?: return false
        gd.onTouchEvent(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.x; downY = ev.y; lastX = ev.x; lastY = ev.y; moved = false; mode = 0
                if (st.tool == "bone" || st.tool == "ik") {
                    val hit = pickBone(ev.x, ev.y)
                    if (hit != null) {
                        st.selBone = hit.first; st.bone()?.let { st.selChar = it.charId }
                        dragBoneId = hit.first
                        mode = if (st.tool == "ik") 5 else if (st.rigMode && !hit.second) 4 else 3
                        if (mode == 5) st.bone()?.let { b -> if (b.ikLen == 0) st.edit { b.ikLen = 2 } }
                        if (mode == 3 || mode == 4 || mode == 5) { st.edit("bonedrag-start") { } }
                        onSelection?.invoke(); invalidate(); return true
                    }
                }
                val id = pick(ev.x, ev.y)
                if (id != null) { if (id != st.selLayer) st.selectLayer(id); onSelection?.invoke(); mode = if (st.tool == "pivot") 6 else 1; prepareLayerDrag(st) }
                else if (st.tool != "bone" && st.tool != "ik") { st.selLayer = ""; onSelection?.invoke(); mode = 2 }
                else mode = 2
                invalidate()
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (ev.pointerCount == 2) { mode = 2; pinchDist = dist(ev); pinchAng = ang(ev); pinchMidX = (ev.getX(0) + ev.getX(1)) / 2f; pinchMidY = (ev.getY(0) + ev.getY(1)) / 2f }
            }
            MotionEvent.ACTION_MOVE -> {
                if (ev.pointerCount >= 2) {
                    val d = dist(ev); val a = ang(ev); val mx = (ev.getX(0) + ev.getX(1)) / 2f; val my = (ev.getY(0) + ev.getY(1)) / 2f
                    val l = st.layer()
                    if (st.tool == "rotate" && l != null) { var da = a - pinchAng; while (da > 180f) da -= 360f; while (da < -180f) da += 360f; st.setProp(l.id, "rot", st.getProp(l.id, "rot") + da, "rot-gesture") }
                    else if (st.tool == "scale" && l != null && pinchDist > 1f) { val f = d / pinchDist; st.setProp(l.id, "sx", st.getProp(l.id, "sx") * f, "sx-g"); st.setProp(l.id, "sy", st.getProp(l.id, "sy") * f, "sy-g") }
                    else {
                        if (pinchDist > 1f) { val f = d / pinchDist; val ns = (vs * f).coerceIn(0.05f, 8f); tx = mx - (pinchMidX - tx) * (ns / vs); ty = my - (pinchMidY - ty) * (ns / vs); vs = ns }
                        tx += mx - pinchMidX; ty += my - pinchMidY
                    }
                    pinchDist = d; pinchAng = a; pinchMidX = mx; pinchMidY = my; moved = true; invalidate(); return true
                }
                val dx = ev.x - lastX; val dy = ev.y - lastY
                if (!moved && hypot(ev.x - downX, ev.y - downY) < 10f) return true
                moved = true
                when (mode) {
                    1 -> dragLayer(st, ev.x, ev.y)
                    2 -> { tx += dx; ty += dy }
                    3 -> rotateBone(st, ev.x, ev.y)
                    4 -> moveJoint(st, ev.x, ev.y)
                    5 -> ikDrag(st, ev.x, ev.y)
                    6 -> dragPivot(st, ev.x, ev.y)
                }
                lastX = ev.x; lastY = ev.y; invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { mode = 0; st.tick++; invalidate() }
        }
        return true
    }

    private fun dist(e: MotionEvent) = hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1))
    private fun ang(e: MotionEvent) = Math.toDegrees(atan2((e.getY(1) - e.getY(0)).toDouble(), (e.getX(1) - e.getX(0)).toDouble())).toFloat()

    // ---- layer drag: convert the touch movement into the layer's parent space
    private fun prepareLayerDrag(st: EditorState) {
        val l = st.layer() ?: return
        val d = st.renderer.drawn.lastOrNull { it.id == l.id } ?: return
        // parent -> view px = vm * toCanvas * T(pivot) * inverse(local)
        val loc = RigTools.layerLocalMatrix(l)
        val locInv = Matrix(); loc.invert(locInv)
        val m = Matrix(d.toCanvas); m.preTranslate(l.px * l.imgW, l.py * l.imgH); m.preConcat(locInv)
        val full = Matrix(vm); full.preConcat(m)
        parentInv = Matrix(); full.invert(parentInv)
    }
    private fun dragLayer(st: EditorState, x: Float, y: Float) {
        val l = st.layer() ?: return; if (l.locked) return
        val a = floatArrayOf(lastX, lastY); val b = floatArrayOf(x, y)
        parentInv.mapPoints(a); parentInv.mapPoints(b)
        st.setProp(l.id, "x", st.getProp(l.id, "x") + (b[0] - a[0]), "drag-${l.id}")
        st.setProp(l.id, "y", st.getProp(l.id, "y") + (b[1] - a[1]), "drag-${l.id}")
    }
    private fun dragPivot(st: EditorState, x: Float, y: Float) {
        val l = st.layer() ?: return
        val d = st.renderer.drawn.lastOrNull { it.id == l.id } ?: return
        val inv = Matrix(); if (!d.toCanvas.invert(inv)) return
        val a = floatArrayOf(x, y); vinv.mapPoints(a); inv.mapPoints(a)
        st.edit("pivot-${l.id}") { RigTools.setPivot(l, (a[0] / l.imgW).coerceIn(-0.5f, 1.5f), (a[1] / l.imgH).coerceIn(-0.5f, 1.5f)) }
    }

    // ---- bones
    private fun boneOriginView(st: EditorState, b: Bone): FloatArray? {
        val cp = st.renderer.lastPoses[b.charId] ?: return null
        val bp = cp.bones[b.id] ?: return null
        val m = Matrix(st.renderer.lastCam); m.preConcat(cp.matrix)
        return toView(m, bp.x, bp.y)
    }
    private fun rotateBone(st: EditorState, x: Float, y: Float) {
        val b = st.bone(dragBoneId) ?: return
        val o = boneOriginView(st, b) ?: return
        val cp = st.renderer.lastPoses[b.charId]
        val a0 = atan2(lastY - o[1], lastX - o[0]); val a1 = atan2(y - o[1], x - o[0])
        var da = Math.toDegrees((a1 - a0).toDouble()).toFloat(); while (da > 180f) da -= 360f; while (da < -180f) da += 360f
        // character mirroring flips the visual rotation direction
        val flip = (cp?.sx ?: 1f) * (cp?.sy ?: 1f) < 0f
        if (flip) da = -da
        st.setProp(b.id, "rot", st.getProp(b.id, "rot") + da, "bonerot-${b.id}")
    }
    private fun moveJoint(st: EditorState, x: Float, y: Float) {
        val b = st.bone(dragBoneId) ?: return
        val cp = st.renderer.lastPoses[b.charId] ?: return
        val toCanvas = Matrix(st.renderer.lastCam); toCanvas.preConcat(cp.matrix)
        val full = Matrix(vm); full.preConcat(toCanvas)
        val inv = Matrix(); if (!full.invert(inv)) return
        val p0 = floatArrayOf(lastX, lastY); val p1 = floatArrayOf(x, y); inv.mapPoints(p0); inv.mapPoints(p1)
        val par = cp.bones[b.parent]
        var dx = p1[0] - p0[0]; var dy = p1[1] - p0[1]
        if (par != null) { val r = Math.toRadians(par.rot.toDouble()); val c = cos(r).toFloat(); val s = sin(r).toFloat(); val ndx = dx * c + dy * s; val ndy = -dx * s + dy * c; dx = ndx; dy = ndy }
        st.edit("joint-${b.id}") { b.x += dx; b.y += dy }
    }
    private fun ikDrag(st: EditorState, x: Float, y: Float) {
        val b = st.bone(dragBoneId) ?: return
        val cp = st.renderer.lastPoses[b.charId] ?: return
        val toCanvas = Matrix(st.renderer.lastCam); toCanvas.preConcat(cp.matrix)
        val full = Matrix(vm); full.preConcat(toCanvas)
        val inv = Matrix(); if (!full.invert(inv)) return
        val p1 = floatArrayOf(x, y); inv.mapPoints(p1)
        st.setProp(b.id, "ikx", p1[0], "ikx-${b.id}"); st.setProp(b.id, "iky", p1[1], "iky-${b.id}")
        if (!st.hasTrack(b.id, "ikw")) st.setProp(b.id, "ikw", 1f, "ikw-${b.id}")
    }
}
