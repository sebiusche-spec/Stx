package com.stx.horror.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.graphics.Color
import kotlin.math.roundToInt

private val TABS = listOf("Assets", "Rig", "Animate", "Face", "Camera", "Effects", "Audio", "Scenes", "Export")

@Composable
fun EditorScreen(st: EditorState, onExit: () -> Unit) {
    var tab by remember { mutableStateOf(2) }
    var panelOpen by remember { mutableStateOf(true) }
    var ctxMenu by remember { mutableStateOf<String?>(null) }
    var cutter by remember { mutableStateOf(false) }
    val landscape = LocalConfiguration.current.screenWidthDp > LocalConfiguration.current.screenHeightDp
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(st.message) { if (st.message.isNotEmpty()) { snack.showSnackbar(st.message); st.message = "" } }
    var stageRef by remember { mutableStateOf<StageView?>(null) }
    LaunchedEffect(tab) { st.rigMode = tab == 1; st.tick++ }

    Box(Modifier.fillMaxSize().background(C.Bg)) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
            TopBar(st, onExit, stageRef)
            val stage: @Composable (Modifier) -> Unit = { m ->
                Box(m) {
                    AndroidView(factory = { c -> StageView(c).also { v -> v.state = st; v.onLongPress = { id, _, _ -> ctxMenu = id ?: "-" }; stageRef = v } },
                        modifier = Modifier.fillMaxSize(), update = { v -> v.state = st; st.tick; st.version; v.invalidate() })
                    ToolStrip(st, Modifier.align(Alignment.TopStart))
                    Transport(st, Modifier.align(Alignment.BottomCenter))
                    DropdownMenu(expanded = ctxMenu != null, onDismissRequest = { ctxMenu = null }) {
                        val hasLayer = ctxMenu != null && ctxMenu != "-"
                        if (hasLayer) {
                            DropdownMenuItem(text = { Text("Duplicate") }, onClick = { st.duplicateLayer(); ctxMenu = null })
                            DropdownMenuItem(text = { Text("Bring forward") }, onClick = { st.moveLayerOrder(1); ctxMenu = null })
                            DropdownMenuItem(text = { Text("Send backward") }, onClick = { st.moveLayerOrder(-1); ctxMenu = null })
                            DropdownMenuItem(text = { Text("Add keyframe (position/rotation)") }, onClick = { st.layer()?.let { l -> listOf("x", "y", "rot").forEach { st.keyNow(l.id, it) } }; ctxMenu = null })
                            DropdownMenuItem(text = { Text("Cut into parts…") }, onClick = { cutter = true; ctxMenu = null })
                            DropdownMenuItem(text = { Text("Delete") }, onClick = { st.deleteLayer(); ctxMenu = null })
                        } else {
                            DropdownMenuItem(text = { Text("Reset view") }, onClick = { stageRef?.resetView(); ctxMenu = null })
                            DropdownMenuItem(text = { Text("Paste keyframes here") }, onClick = { st.pasteKeys(); ctxMenu = null })
                        }
                    }
                }
            }
            if (landscape) {
                Row(Modifier.weight(1f)) {
                    Column(Modifier.weight(1.25f)) { stage(Modifier.weight(1f).fillMaxWidth()); TimelinePanel(st, Modifier.fillMaxWidth().height(130.dp)) }
                    Column(Modifier.weight(1f)) { StxTabs(tab, { tab = it }); Box(Modifier.weight(1f)) { Panel(st, tab) { cutter = true } } }
                }
            } else {
                stage(Modifier.weight(if (panelOpen) 1.05f else 2f).fillMaxWidth())
                TimelinePanel(st, Modifier.fillMaxWidth().height(if (panelOpen) 118.dp else 190.dp))
                StxTabs(tab, { if (it == tab) panelOpen = !panelOpen else { tab = it; panelOpen = true } })
                if (panelOpen) Box(Modifier.weight(1.1f).fillMaxWidth()) { Panel(st, tab) { cutter = true } }
            }
        }
        SnackbarHost(snack, Modifier.align(Alignment.BottomCenter).padding(bottom = 90.dp))
        if (st.exportProgress >= 0f) ExportOverlay(st)
        if (cutter) CutterDialog(st) { cutter = false }
    }
}

@Composable
private fun StxTabs(sel: Int, onSel: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().background(C.Panel).horizontalScroll(rememberScrollState()).padding(horizontal = 4.dp, vertical = 2.dp)) {
        TABS.forEachIndexed { i, t -> Tag(t, i == sel, if (i == sel) C.Red else C.Neon) { onSel(i) } }
    }
}

@Composable
private fun TopBar(st: EditorState, onExit: () -> Unit, stage: StageView?) {
    Row(Modifier.fillMaxWidth().background(C.Panel).padding(horizontal = 6.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Neon("←") { onExit() }
        Spacer(Modifier.width(6.dp))
        Column(Modifier.weight(1f)) {
            Text(st.project.name, color = C.Text, fontSize = 13.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, maxLines = 1)
            Text(st.scene.name + (if (!st.saved) "  ● unsaved" else "  ✓ saved") + "  ·  ${st.project.width}×${st.project.height}@${st.project.fps}", color = if (st.saved) C.Muted else C.Amber, fontSize = 10.sp, maxLines = 1)
        }
        Neon("↶", enabled = st.canUndo) { st.undo() }; Spacer(Modifier.width(3.dp))
        Neon("↷", enabled = st.canRedo) { st.redo() }; Spacer(Modifier.width(3.dp))
        Neon("Save", color = C.Green) { st.save() }
    }
}

@Composable
private fun ToolStrip(st: EditorState, modifier: Modifier) {
    Column(modifier.padding(6.dp).background(Color(0xAA0A0B10), RoundedCornerShape(10.dp)).padding(3.dp)) {
        val tools = listOf("move" to "✥", "rotate" to "⟳", "scale" to "⤢", "pivot" to "⊕", "bone" to "🦴", "ik" to "⌖")
        tools.forEach { (k, ic) -> Box(Modifier.size(36.dp).padding(2.dp).background(if (st.tool == k) C.Neon.copy(alpha = .25f) else Color.Transparent, RoundedCornerShape(8.dp)).clickable { st.tool = k }, contentAlignment = Alignment.Center) {
            Text(ic, color = if (st.tool == k) C.Neon else C.Text, fontSize = 17.sp) } }
        Box(Modifier.size(36.dp).clickable { st.showBones = !st.showBones }, contentAlignment = Alignment.Center) { Text("☰", color = if (st.showBones) C.Neon else C.Muted, fontSize = 17.sp) }
        Box(Modifier.size(36.dp).clickable { st.showGrid = !st.showGrid }, contentAlignment = Alignment.Center) { Text("▦", color = if (st.showGrid) C.Neon else C.Muted, fontSize = 17.sp) }
    }
}

@Composable
private fun Transport(st: EditorState, modifier: Modifier) {
    Row(modifier.padding(6.dp).background(Color(0xCC0A0B10), RoundedCornerShape(12.dp)).padding(horizontal = 6.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        TBtn("⏮") { st.seek(0f) }
        TBtn("◀") { st.seek(st.time - 1f / st.project.fps) }
        TBtn(if (st.playing) "⏸" else "▶", C.Red) { if (st.playing) st.pause() else st.play() }
        TBtn("▶|") { st.seek(st.time + 1f / st.project.fps) }
        TBtn("⏭") { st.seek(st.scene.duration) }
        Text(fmtTime(st.time) + " / " + fmtTime(st.scene.duration), color = C.Text, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 6.dp))
        TBtn("⟲", if (st.loopPlay) C.Neon else C.Muted) { st.loopPlay = !st.loopPlay }
        TBtn(if (st.autoKey) "●" else "○", if (st.autoKey) C.Red else C.Muted) { st.autoKey = !st.autoKey; st.toast(if (st.autoKey) "Auto-key ON: edits create keyframes" else "Auto-key off") }
        TBtn(if (st.lowPreview) "LQ" else "HQ", C.Violet) { st.lowPreview = !st.lowPreview }
    }
}
@Composable private fun TBtn(t: String, c: Color = C.Text, onClick: () -> Unit) {
    Box(Modifier.size(34.dp).clickable { onClick() }, contentAlignment = Alignment.Center) { Text(t, color = c, fontSize = 15.sp) }
}

@Composable
private fun ExportOverlay(st: EditorState) {
    Box(Modifier.fillMaxSize().background(Color(0xDD000000)).clickable { }, contentAlignment = Alignment.Center) {
        Glass(Modifier.padding(24.dp).fillMaxWidth()) {
            Title("Rendering MP4"); Text(st.exportText, color = C.Text, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(progress = { st.exportProgress.coerceIn(0f, 1f) }, Modifier.fillMaxWidth(), color = C.Red, trackColor = C.Line)
            Text("${(st.exportProgress * 100).roundToInt()}%", color = C.Muted, fontSize = 11.sp)
            Spacer(Modifier.height(8.dp)); Neon("Cancel", color = C.Red) { st.cancelExport() }
        }
    }
}

@Composable
private fun Panel(st: EditorState, tab: Int, openCutter: () -> Unit) {
    Column(Modifier.fillMaxSize().background(C.Bg).verticalScroll(rememberScrollState()).padding(8.dp)) {
        st.version
        when (tab) {
            0 -> AssetsPanel(st, openCutter)
            1 -> RigPanel(st)
            2 -> AnimatePanel(st)
            3 -> FacePanel(st)
            4 -> CameraPanel(st)
            5 -> EffectsPanel(st)
            6 -> AudioPanel(st)
            7 -> ScenePanel(st)
            8 -> ExportPanel(st)
        }
        Spacer(Modifier.height(30.dp))
    }
}
