package com.stx.horror

import android.app.Application
import android.content.Context
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

class StxApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Crash log: the project itself is protected by autosave; this keeps the stack trace for bug reports.
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            runCatching {
                val sw = StringWriter(); e.printStackTrace(PrintWriter(sw))
                File(filesDir, "last_crash.txt").writeText(sw.toString())
            }
            old?.uncaughtException(t, e)
        }
    }
}

fun Context.prefs() = getSharedPreferences("stx", Context.MODE_PRIVATE)
