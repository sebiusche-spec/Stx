package com.stx.horror.engine

import android.graphics.*
import com.stx.horror.data.BitmapCache
import com.stx.horror.model.*
import kotlin.math.*

class DrawnLayer(val id: String, val toCanvas: Matrix, val l: Float, val t: Float, val r: Float, val b: Float)

/**
 * The one and only frame renderer. It is used for the live preview, the thumbnails and the MP4 export,
 * so what you see while editing is exactly what is exported (just at a different resolution / quality).
 * quality: 0 = fast editing preview, 1 = normal preview, 2 = export.
 */
class SceneRenderer(val cache: BitmapCache) {
    val drawn = ArrayList<DrawnLayer>()
    var lastPoses: Map<String, CharPose> = emptyMap()
    val lastCam = Matrix()               // scene -> canvas px for the character plane
    var lastScale = 1f

    private class Cam(var x: Float, var y: Float, var zoom: Float, var rot: Float, var shx: Float, var shy: Float)

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val vpaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var off: Bitmap? = null
    private var glow: Bitmap? = null
    private var recording = true
    private var frameIdx = 0
    private val tmp = Matrix()

    private fun ev(sc: Scene, target: String, prop: String, t: Float) = Anim.eval(sc.track(target, prop), t)

    // ------------------------------------------------------------------ camera
    private fun camAt(project: Project, sc: Scene, t: Float): Cam {
        val w = project.width.toFloat(); val h = project.height.toFloat(); val cfg = sc.camera
        var cx = ev(sc, "cam", "x", t) ?: (w / 2f); var cy = ev(sc, "cam", "y", t) ?: (h / 2f)
        if (cfg.followChar.isNotEmpty() && cfg.followAmt > 0f) {
            val ch = sc.character(cfg.followChar)
            if (ch != null) {
                var sx = 0f; var sy = 0f
                for (i in 0..2) {
                    val tt = max(0f, t - cfg.followLag * i / 2f)
                    sx += RigSolver.charRootX(sc, ch, tt); sy += ev(sc, ch.id, "y", tt) ?: ch.y
                }
                sx /= 3f; sy /= 3f
                cx = Anim.lerp(cx, sx + cfg.followOffX, cfg.followAmt); cy = Anim.lerp(cy, sy + cfg.followOffY, cfg.followAmt)
            }
        }
        val zoom = max(0.05f, ev(sc, "cam", "zoom", t) ?: 1f)
        var rot = ev(sc, "cam", "rot", t) ?: 0f
        val shake = (ev(sc, "cam", "shake", t) ?: cfg.shake).coerceIn(0f, 3f)
        val hand = (ev(sc, "cam", "hand", t) ?: cfg.handheld).coerceIn(0f, 3f)
        var shx = 0f; var shy = 0f
        if (shake > 0.001f) {
            shx += 30f * shake * Anim.noise(t * 19f, 1); shy += 30f * shake * Anim.noise(t * 19f, 2); rot += 1.6f * shake * Anim.noise(t * 15f, 3)
        }
        if (hand > 0.001f) {
            shx += 9f * hand * (Anim.noise(t * 1.7f, 4) + 0.5f * Anim.noise(t * 3.9f, 5)); shy += 9f * hand * (Anim.noise(t * 1.5f, 6) + 0.5f * Anim.noise(t * 4.3f, 7))
            rot += 0.55f * hand * Anim.noise(t * 1.1f, 8)
        }
        return Cam(cx, cy, zoom, rot, shx, shy)
    }

    private fun plane(cam: Cam, w: Float, h: Float, depth: Float, parallax: Float): Matrix {
        val raw = 50f / depth.coerceIn(5f, 500f)
        val f = 1f + (raw - 1f) * parallax
        val cx = w / 2f + (cam.x - w / 2f) * f; val cy = h / 2f + (cam.y - h / 2f) * f
        val z = max(0.02f, 1f + (cam.zoom - 1f) * f)
        val m = Matrix()
        m.postTranslate(-cx, -cy); m.postScale(z, z); m.postRotate(cam.rot)
        m.postTranslate(w / 2f + cam.shx * (0.6f + 0.4f * f), h / 2f + cam.shy * (0.6f + 0.4f * f))
        return m
    }

    // ------------------------------------------------------------------ main entry
    fun render(c: Canvas, outW: Int, outH: Int, project: Project, sc: Scene, t: Float, quality: Int) {
        val W = outW.toFloat(); val H = outH.toFloat()
        val s = W / project.width
        lastScale = s
        frameIdx = (t * project.fps).roundToInt()
        val fx = FxFrame(sc, t)
        val needCap = fx.has(FxType.CHROMATIC) || fx.has(FxType.GLITCH) || fx.has(FxType.GLOW)
        var target = c
        var offBmp: Bitmap? = null
        if (needCap) {
            offBmp = ensureOff(outW, outH); offBmp.eraseColor(0); target = Canvas(offBmp)
        }
        val mb = fx.list(FxType.MOTION_BLUR).firstOrNull()
        if (mb != null && mb.k > 0.01f && quality >= 1) {
            val n = mb.p("samples", 4f).toInt().coerceIn(2, if (quality == 1) 3 else 6)
            val shutter = mb.p("shutter", .5f) * mb.k.coerceAtMost(1f) / project.fps
            drawn.clear()
            for (k in 0 until n) {
                val tk = max(0f, t - shutter * k / n)
                recording = k == 0
                target.saveLayerAlpha(0f, 0f, W, H, (255f / (k + 1)).toInt())
                drawWorld(target, outW, outH, s, project, sc, tk, FxFrame(sc, tk), quality)
                target.restore()
            }
        } else {
            drawn.clear(); recording = true
            drawWorld(target, outW, outH, s, project, sc, t, fx, quality)
        }
        if (needCap && offBmp != null) composite(c, offBmp, outW, outH, s, fx, t)
        overlays(c, W, H, fx, t)
    }

    private fun ensureOff(w: Int, h: Int): Bitmap {
        val o = off
        if (o != null && o.width == w && o.height == h && !o.isRecycled) return o
        o?.recycle()
        return Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).also { off = it }
    }

    // ------------------------------------------------------------------ world
    private fun drawWorld(c: Canvas, outW: Int, outH: Int, s: Float, project: Project, sc: Scene, t: Float, fx: FxFrame, quality: Int) {
        val w = project.width.toFloat(); val h = project.height.toFloat()
        val cam = camAt(project, sc, t)
        val wind = fx.windValue()
        val poses = HashMap<String, CharPose>()
        for (ch in sc.characters) poses[ch.id] = RigSolver.solve(sc, ch, t, wind)
        if (recording) {
            lastPoses = poses
            lastCam.reset(); lastCam.postConcat(plane(cam, w, h, 50f, sc.camera.parallax)); lastCam.postScale(s, s)
        }
        // colour grade / flicker applied to everything below through a single layer
        var cm: ColorMatrix? = null
        for (g in fx.list(FxType.GRADE)) {
            val m = Fx.gradeMatrix(g.p("saturation", .55f), g.p("contrast", 1.2f), g.p("brightness", -.06f), g.p("r", 0f), g.p("g", 0f), g.p("b", .07f), g.k)
            if (cm == null) cm = m else cm.postConcat(m)
        }
        for (fl in fx.list(FxType.FLICKER)) {
            val rate = fl.p("rate", 14f); val depth = fl.p("depth", .5f) * fl.k
            val n = Anim.noise(t * rate, 21); val n2 = Anim.noise(t * rate * 2.3f, 22)
            val v = (1f - depth * (0.5f + 0.5f * (0.7f * n + 0.3f * n2)).coerceIn(0f, 1f) * 0.9f).coerceIn(0.05f, 1.2f)
            val m = ColorMatrix(floatArrayOf(v, 0f, 0f, 0f, 0f, 0f, v, 0f, 0f, 0f, 0f, 0f, v, 0f, 0f, 0f, 0f, 0f, 1f, 0f))
            if (cm == null) cm = m else cm.postConcat(m)
        }
        c.save()
        c.scale(s, s)
        val layerPaint = Paint()
        if (cm != null) { layerPaint.colorFilter = ColorMatrixColorFilter(cm); c.saveLayer(0f, 0f, w, h, layerPaint) }
        else c.clipRect(0f, 0f, w, h)
        c.drawColor(sc.bgColor)

        val ghostA = ghostAlpha(fx, t); val ghostD = fx.list(FxType.GHOST_DISTORT).firstOrNull()
        var envDone = false
        for (l in sc.layers) {
            if (!l.visible) continue
            if (!envDone && l.charId.isNotEmpty()) {
                envDone = true
                for (e in fx.list(FxType.SHADOW_MOVE)) Fx.movingShadows(c, w, h, t, e)
                for (e in fx.list(FxType.SHADOW)) groundShadows(c, sc, poses, e, t)
            }
            drawLayer(c, s, project, sc, l, t, poses, cam, wind, ghostA, ghostD, quality)
        }
        if (!envDone) for (e in fx.list(FxType.SHADOW_MOVE)) Fx.movingShadows(c, w, h, t, e)

        // weather (continuous procedural particles, deterministic in t)
        for (e in fx.list(FxType.FOG)) Fx.fog(c, w, h, t, e)
        for (e in fx.list(FxType.SMOKE)) Fx.smoke(c, w, h, t, e, wind)
        for (e in fx.list(FxType.DUST)) Fx.dust(c, w, h, t, e, quality)
        for (e in fx.list(FxType.RAIN)) Fx.rain(c, w, h, t, e, wind, quality)
        for (e in fx.list(FxType.SNOW)) Fx.snow(c, w, h, t, e, wind, quality)
        for (e in fx.list(FxType.LIGHTNING)) {
            val st = Fx.lightning(sc, e, t)
            if (st.on && e.p("bolt", 1f) > 0.5f) { c.save(); c.concat(plane(cam, w, h, 100f, sc.camera.parallax)); Fx.bolt(c, w, h, st); c.restore() }
        }
        drawLights(c, project, sc, t, fx, poses, cam)
        if (cm != null) c.restore()
        c.restore()
    }

    private fun ghostAlpha(fx: FxFrame, t: Float): Float? {
        val g = fx.list(FxType.GHOST).firstOrNull() ?: return null
        val mn = g.p("minA", .2f); val mx = g.p("maxA", .7f); val sp = g.p("speed", .7f)
        val u = 0.5f + 0.5f * sin(t * sp * 2f * PI.toFloat()) * (0.7f + 0.3f * Anim.noise(t * 2f, 3))
        return Anim.lerp(1f, Anim.lerp(mn, mx, u.coerceIn(0f, 1f)), g.k.coerceIn(0f, 1f))
    }

    private fun groundShadows(c: Canvas, sc: Scene, poses: Map<String, CharPose>, e: FxState, t: Float) {
        val gy = e.p("groundY", 880f); val wf = e.p("width", 1f)
        for (ch in sc.characters) {
            val cp = poses[ch.id] ?: continue
            val pts = floatArrayOf(0f, 0f); cp.matrix.mapPoints(pts)
            val lift = ((gy - pts[1]) / 600f).let { 1f - it.coerceIn(0f, 1f) * 0.4f }
            Fx.groundShadow(c, pts[0], gy, 150f * wf * abs(ch.sx), e.k.coerceIn(0f, 1f) * lift * (cp.opacity))
        }
    }

    // ------------------------------------------------------------------ layers
    private fun drawLayer(c: Canvas, s: Float, project: Project, sc: Scene, l: Layer, t: Float, poses: Map<String, CharPose>, cam: Cam,
                          wind: Float, ghostA: Float?, ghostD: FxState?, quality: Int) {
        val w = project.width.toFloat(); val h = project.height.toFloat()
        val cp = poses[l.charId]
        val ch = sc.character(l.charId)
        val bone = if (l.boneId.isNotEmpty()) sc.bone(l.boneId) else null
        var x = ev(sc, l.id, "x", t) ?: l.x; var y = ev(sc, l.id, "y", t) ?: l.y
        var rot = ev(sc, l.id, "rot", t) ?: l.rot
        var sxv = ev(sc, l.id, "sx", t) ?: l.sx; var syv = ev(sc, l.id, "sy", t) ?: l.sy
        var opacity = (ev(sc, l.id, "opacity", t) ?: l.opacity) * (cp?.opacity ?: 1f)
        val px = ev(sc, l.id, "px", t) ?: l.px; val py = ev(sc, l.id, "py", t) ?: l.py
        val skx = ev(sc, l.id, "skx", t) ?: l.skx; val sky = ev(sc, l.id, "sky", t) ?: l.sky
        if (l.ghost && ghostA != null) opacity *= ghostA
        if (opacity <= 0.003f) return
        if (bone != null && cp != null) cp.syRole[bone.role]?.let { syv *= it }

        var img = l.image
        var vectorKind = 0
        if (cp != null && ch != null) {
            val headFrame = bone?.role == "head"
            fun shift(dxRight: Float, dyUp: Float) { if (headFrame) { x += dyUp; y += dxRight } else { x += dxRight; y -= dyUp } }
            val lr = ch.lookRange
            when (l.role) {
                "eye" -> {
                    val e = cp.eye
                    if (l.states.size >= 3) img = l.states[e.roundToInt().coerceIn(0, 2).coerceAtMost(l.states.size - 1)]
                    else if (ch.blinkSquash) syv *= if (e <= 1f) Anim.lerp(1f, .42f, e) else Anim.lerp(.42f, .04f, (e - 1f).coerceAtMost(1f))
                    shift(cp.lookx * lr, cp.looky * lr * 0.6f)
                    if (l.image.isEmpty() && l.states.isEmpty()) vectorKind = -1
                }
                "brow" -> {
                    val b = cp.brow.roundToInt().coerceIn(0, 4)
                    if (l.states.size >= 5) img = l.states[b]
                    else {
                        val sg = if (l.side == "R") -1f else 1f
                        when (b) {
                            1 -> { rot += 13f * sg; shift(0f, -3f) }
                            2 -> { rot -= 11f * sg; shift(0f, 2f) }
                            3 -> { rot -= 8f * sg; shift(0f, 9f) }
                            4 -> shift(0f, 13f)
                        }
                    }
                    shift(cp.lookx * lr * 0.85f, cp.looky * lr * 0.5f)
                }
                "mouth" -> {
                    val m = cp.mouth.roundToInt().coerceAtLeast(0)
                    if (l.states.isNotEmpty()) img = l.states[min(m, l.states.size - 1)]
                    else if (l.image.isEmpty()) vectorKind = m + 1
                    else syv *= when (m) { 0 -> .3f; 1 -> .6f; 2 -> .9f; 3 -> 1.15f; 4 -> .8f; else -> 1.1f }
                    shift(cp.lookx * lr * 0.9f, cp.looky * lr * 0.5f)
                }
            }
        }
        // transform chain: camera plane * character * bone * layer
        val full = plane(cam, w, h, l.depth, sc.camera.parallax)
        if (cp != null) {
            full.preConcat(cp.matrix)
            if (bone != null && cp.boneMatrix(bone.id, tmp)) full.preConcat(tmp)
        }
        val loc = Matrix()
        loc.postScale(sxv, syv)
        if (skx != 0f || sky != 0f) loc.postSkew(tan(Math.toRadians(skx.toDouble())).toFloat(), tan(Math.toRadians(sky.toDouble())).toFloat())
        loc.postRotate(rot); loc.postTranslate(x, y)
        full.preConcat(loc)

        val iw = l.imgW.toFloat(); val ih = l.imgH.toFloat()
        if (recording) {
            val rec = Matrix(); rec.postScale(s, s); rec.preConcat(full); rec.preTranslate(-px * iw, -py * ih)
            drawn.add(DrawnLayer(l.id, rec, 0f, 0f, iw, ih))
        }
        c.save()
        c.concat(full)
        c.translate(-px * iw, -py * ih)

        paint.reset(); paint.isAntiAlias = true; paint.isFilterBitmap = true
        paint.alpha = (255f * opacity.coerceIn(0f, 1f)).toInt()
        when (l.blend) {
            Blend.NORMAL -> {}
            Blend.ADD -> paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.ADD)
            Blend.MULTIPLY -> paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.MULTIPLY)
            Blend.SCREEN -> paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SCREEN)
            Blend.OVERLAY -> paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.OVERLAY)
            Blend.DARKEN -> paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.DARKEN)
            Blend.LIGHTEN -> paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.LIGHTEN)
        }
        if (l.tint != 0) paint.colorFilter = PorterDuffColorFilter(l.tint, PorterDuff.Mode.MULTIPLY)

        l.mask?.let { m ->
            if (m.size >= 6) { val p = Path(); p.moveTo(m[0], m[1]); var i = 2; while (i + 1 < m.size) { p.lineTo(m[i], m[i + 1]); i += 2 }; p.close(); c.clipPath(p) }
        }
        if (vectorKind != 0) drawVectorFace(c, vectorKind, iw, ih, opacity)
        else if (img.isNotEmpty()) {
            val dim = when (quality) { 0 -> 640; 1 -> 1100; else -> 2048 }
            var level = 0
            val dof = sc.camera.dof
            if (dof > 0.01f) {
                val focus = ev(sc, "cam", "focus", t) ?: sc.camera.focusDepth
                val dd = abs(l.depth - focus) / 50f * dof
                level = if (dd > 1.2f) 3 else if (dd > 0.7f) 2 else if (dd > 0.3f) 1 else 0
                if (quality == 0 && level > 1) level = 1
            }
            val bmp = if (level > 0) cache.blurred(img, dim, level) else cache.get(img, dim)
            if (bmp == null) {
                vpaint.style = Paint.Style.STROKE; vpaint.color = 0xFFFF2E4D.toInt(); vpaint.strokeWidth = 3f / max(0.05f, abs(sxv))
                c.drawRect(0f, 0f, iw, ih, vpaint); c.drawLine(0f, 0f, iw, ih, vpaint); c.drawLine(iw, 0f, 0f, ih, vpaint)
            } else {
                val distort = if (l.ghost && ghostD != null) ghostD else null
                if (l.swayAmt > 0.01f || distort != null) drawMesh(c, bmp, iw, ih, l, t, wind, distort, ch, sc)
                else {
                    val src = Rect((l.cropL * bmp.width).toInt(), (l.cropT * bmp.height).toInt(), (l.cropR * bmp.width).toInt().coerceAtLeast(1), (l.cropB * bmp.height).toInt().coerceAtLeast(1))
                    val dst = RectF(l.cropL * iw, l.cropT * ih, l.cropR * iw, l.cropB * ih)
                    c.drawBitmap(bmp, src, dst, paint)
                }
            }
        }
        c.restore()
        paint.xfermode = null
    }

    private val meshCols = 4; private val meshRows = 10
    private val verts = FloatArray((meshCols + 1) * (meshRows + 1) * 2)

    private fun drawMesh(c: Canvas, bmp: Bitmap, iw: Float, ih: Float, l: Layer, t: Float, wind: Float, distort: FxState?, ch: Character?, sc: Scene) {
        val tau = (2.0 * PI).toFloat()
        val f = l.swaySpeed * 0.7f; val ph = Anim.hash(l.id.hashCode()) * 6f
        val osc = 0.65f * sin(tau * f * t + ph) + 0.35f * Anim.noise(t * f * 1.7f + ph, 5)
        var vel = 0f
        if (ch != null) vel = (RigSolver.charRootX(sc, ch, t) - RigSolver.charRootX(sc, ch, max(0f, t - 0.1f))) / 0.1f
        val bias = -wind * 1.3f
        val deg = l.swayAmt * (osc + bias) + (-vel * 0.012f * l.swayAmt / 6f)
        var k = 0
        for (r in 0..meshRows) {
            val v = r / meshRows.toFloat()
            val dx = tan(Math.toRadians(deg.toDouble())).toFloat() * v.pow(1.35f) * ih * 0.9f
            for (cc in 0..meshCols) {
                val u = cc / meshCols.toFloat()
                var vx = u * iw + dx; var vy = v * ih
                if (distort != null) {
                    val amp = distort.p("amp", 16f) * distort.k; val fq = distort.p("freq", 1.4f)
                    vx += amp * sin(tau * fq * t + v * 7f) * (0.4f + 0.6f * v)
                    vy += amp * 0.35f * sin(tau * fq * 0.8f * t + u * 5f)
                }
                verts[k++] = vx; verts[k++] = vy
            }
        }
        c.drawBitmapMesh(bmp, meshCols, meshRows, verts, 0, null, 0, paint)
    }

    private val facePath = Path()
    private fun drawVectorFace(c: Canvas, kind: Int, w: Float, h: Float, opacity: Float) {
        vpaint.reset(); vpaint.isAntiAlias = true
        val cx = w / 2f; val cy = h / 2f
        val a = (255 * opacity).toInt().coerceIn(0, 255)
        if (kind < 0) {   // generic eye
            vpaint.color = Color.argb(a, 235, 235, 235); c.drawOval(RectF(0f, 0f, w, h), vpaint)
            vpaint.color = Color.argb(a, 10, 10, 12); c.drawCircle(cx, cy, min(w, h) * 0.3f, vpaint); return
        }
        vpaint.color = Color.argb(a, 22, 6, 10)
        vpaint.style = Paint.Style.FILL
        when (kind - 1) {
            0 -> { vpaint.style = Paint.Style.STROKE; vpaint.strokeWidth = h * 0.12f; vpaint.strokeCap = Paint.Cap.ROUND; c.drawLine(w * 0.2f, cy, w * 0.8f, cy, vpaint) }
            1 -> c.drawOval(RectF(w * 0.28f, cy - h * 0.12f, w * 0.72f, cy + h * 0.12f), vpaint)
            2 -> c.drawOval(RectF(w * 0.24f, cy - h * 0.24f, w * 0.76f, cy + h * 0.24f), vpaint)
            3 -> c.drawOval(RectF(w * 0.18f, cy - h * 0.4f, w * 0.82f, cy + h * 0.4f), vpaint)
            4 -> { vpaint.style = Paint.Style.STROKE; vpaint.strokeWidth = h * 0.11f; vpaint.strokeCap = Paint.Cap.ROUND
                facePath.reset(); facePath.moveTo(w * 0.15f, cy - h * 0.1f); facePath.quadTo(cx, cy + h * 0.6f, w * 0.85f, cy - h * 0.1f); c.drawPath(facePath, vpaint) }
            else -> c.drawOval(RectF(w * 0.2f, cy - h * 0.46f, w * 0.8f, cy + h * 0.46f), vpaint)
        }
    }

    // ------------------------------------------------------------------ lights
    private fun drawLights(c: Canvas, project: Project, sc: Scene, t: Float, fx: FxFrame, poses: Map<String, CharPose>, cam: Cam) {
        var ambient = sc.ambient
        for (d in fx.list(FxType.DARKNESS)) ambient += d.k
        ambient = ambient.coerceIn(0f, 0.97f)
        val lights = sc.lights.filter { it.enabled }
        if (lights.isEmpty() && ambient <= 0.001f) return
        val w = project.width.toFloat(); val h = project.height.toFloat()
        val plane = plane(cam, w, h, 50f, sc.camera.parallax)
        class L(val light: Light, val x: Float, val y: Float, val ang: Float, val inten: Float, val rad: Float)
        val ls = ArrayList<L>()
        for (li in lights) {
            var x = ev(sc, li.id, "x", t) ?: li.x; var y = ev(sc, li.id, "y", t) ?: li.y
            var ang = ev(sc, li.id, "angle", t) ?: li.angle
            var inten = ev(sc, li.id, "intensity", t) ?: li.intensity
            var rad = ev(sc, li.id, "radius", t) ?: li.radius
            val cp = poses[li.followChar]
            if (cp != null) {
                val bp = cp.bones[li.followBone]
                if (bp != null) {
                    val pt = floatArrayOf(bp.x, bp.y); cp.matrix.mapPoints(pt)
                    val dv = floatArrayOf(cos(Math.toRadians(bp.rot.toDouble())).toFloat(), sin(Math.toRadians(bp.rot.toDouble())).toFloat()); cp.matrix.mapVectors(dv)
                    x = pt[0] + x; y = pt[1] + y   // x/y act as offset when following
                    ang += Math.toDegrees(atan2(dv[1].toDouble(), dv[0].toDouble())).toFloat()
                }
            }
            // flicker per type
            val fl = li.flicker
            when (li.type) {
                LightType.BULB -> { val gate = if (Anim.hash((t * 14f).toInt() + li.id.hashCode()) < fl * 0.35f) 0.12f else 1f; inten *= gate * (1f - fl * 0.25f * abs(Anim.noise(t * 31f, 3))) }
                LightType.CANDLE -> { inten *= 1f - fl * (0.35f * abs(Anim.noise(t * 9f, 4)) + 0.2f * abs(Anim.noise(t * 23f, 5))); rad *= 1f + 0.05f * Anim.noise(t * 7f, 6) }
                else -> inten *= 1f - fl * 0.5f * abs(Anim.noise(t * 17f, li.id.hashCode()))
            }
            ls.add(L(li, x, y, ang, inten.coerceIn(0f, 2f), rad))
        }
        c.save(); c.concat(plane)
        if (ambient > 0.001f) {
            c.saveLayer(null, null)
            c.drawColor(Color.argb((255 * ambient).toInt(), 2, 3, 8))
            val p = Paint(Paint.ANTI_ALIAS_FLAG); p.xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
            for (l in ls) lightShape(c, l.light, l.x, l.y, l.ang, l.rad, l.inten, p, false)
            c.restore()
        }
        val ap = Paint(Paint.ANTI_ALIAS_FLAG); ap.xfermode = PorterDuffXfermode(PorterDuff.Mode.ADD)
        for (l in ls) lightShape(c, l.light, l.x, l.y, l.ang, l.rad, l.inten * 0.55f, ap, true)
        c.restore()
    }

    private fun lightShape(c: Canvas, li: Light, x: Float, y: Float, ang: Float, rad: Float, inten: Float, p: Paint, colored: Boolean) {
        val base = if (colored) li.color else Color.BLACK
        val n = 6
        val cols = IntArray(n); val pos = FloatArray(n)
        for (i in 0 until n) {
            val u = i / (n - 1f)
            val a = (inten * (1f - u).pow(li.falloff)).coerceIn(0f, 1f)
            cols[i] = Color.argb((255 * a).toInt(), Color.red(base), Color.green(base), Color.blue(base)); pos[i] = u
        }
        cols[n - 1] = Color.argb(0, Color.red(base), Color.green(base), Color.blue(base))
        val sh = RadialGradient(x, y, max(5f, rad), cols, pos, Shader.TileMode.CLAMP)
        p.shader = sh
        val cone = li.type == LightType.FLASHLIGHT || li.type == LightType.HEADLIGHTS || li.type == LightType.SPOT
        if (!cone) { c.drawCircle(x, y, rad, p); p.shader = null; return }
        val halfs = if (li.type == LightType.HEADLIGHTS) listOf(-12f, 12f) else listOf(0f)
        for (off in halfs) {
            var ox = x; var oy = y
            if (off != 0f) { val r = Math.toRadians((ang + 90).toDouble()); ox += cos(r).toFloat() * off * 3f; oy += sin(r).toFloat() * off * 3f }
            val ps = RadialGradient(ox, oy, max(5f, rad), cols, pos, Shader.TileMode.CLAMP); p.shader = ps
            for (k in 0..1) {   // soft edge: wide dim cone + narrow cone
                val half = li.cone * (if (k == 0) 1f else 0.62f)
                val path = Path(); path.moveTo(ox, oy)
                path.arcTo(RectF(ox - rad, oy - rad, ox + rad, oy + rad), ang - half, half * 2f); path.close()
                p.alpha = if (k == 0) 150 else 255
                c.drawPath(path, p)
            }
        }
        p.shader = null; p.alpha = 255
    }

    // ------------------------------------------------------------------ capture-based post effects
    private val rgbFilters = arrayOf(
        ColorMatrixColorFilter(ColorMatrix(floatArrayOf(1f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 1f, 0f))),
        ColorMatrixColorFilter(ColorMatrix(floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 1f, 0f))),
        ColorMatrixColorFilter(ColorMatrix(floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 0f, 1f, 0f)))
    )

    private fun composite(c: Canvas, frame: Bitmap, outW: Int, outH: Int, s: Float, fx: FxFrame, t: Float) {
        val W = outW.toFloat(); val H = outH.toFloat()
        val p = Paint(Paint.FILTER_BITMAP_FLAG)
        val ca = fx.list(FxType.CHROMATIC).firstOrNull()
        if (ca != null && ca.k > 0.01f) {
            val shift = ca.p("shift", 7f) * ca.k * (1f + ca.p("pulse", .3f) * sin(t * 9f)) * (W / 1920f)
            c.drawColor(Color.BLACK)
            p.xfermode = PorterDuffXfermode(PorterDuff.Mode.ADD)
            for (i in 0..2) { p.colorFilter = rgbFilters[i]; c.drawBitmap(frame, (i - 1) * shift, 0f, p) }
            p.colorFilter = null; p.xfermode = null
        } else c.drawBitmap(frame, 0f, 0f, p)

        val gl = fx.list(FxType.GLITCH).firstOrNull()
        if (gl != null && gl.k > 0.01f) {
            val bt = t * gl.p("rate", 2f); val bk = floor(bt).toInt()
            val inBurst = (bt - bk) < gl.p("duty", .25f) && Anim.hash(bk * 7 + 1) < 0.92f
            if (inBurst) {
                val fi = frameIdx
                val n = 4 + (Anim.hash(fi) * 6).toInt()
                val maxShift = gl.p("slice", 70f) * (W / 1920f) * gl.k
                for (i in 0 until n) {
                    val y = Anim.hash2(fi, i * 3) * H; val hh = (0.015f + 0.1f * Anim.hash2(fi, i * 3 + 1)) * H
                    val dx = (Anim.hash2(fi, i * 3 + 2) * 2f - 1f) * maxShift
                    val y2 = min(H, y + hh)
                    val src = Rect(0, y.toInt(), outW, y2.toInt()); val dst = RectF(dx, y, W + dx, y2)
                    p.colorFilter = null; p.xfermode = null; c.drawBitmap(frame, src, dst, p)
                    p.xfermode = PorterDuffXfermode(PorterDuff.Mode.ADD); p.colorFilter = rgbFilters[if (i % 2 == 0) 0 else 2]; p.alpha = 150
                    c.drawBitmap(frame, src, RectF(dx * 1.6f, y, W + dx * 1.6f, y2), p)
                    p.alpha = 255; p.colorFilter = null; p.xfermode = null
                }
            }
        }
        val gw = fx.list(FxType.GLOW).firstOrNull()
        if (gw != null && gw.k > 0.01f) {
            val div = (4 + 10 * gw.p("radius", .6f)).toInt()
            val sw = max(16, outW / div); val sh = max(16, outH / div)
            var gb = glow
            if (gb == null || gb.width != sw || gb.height != sh) { gb?.recycle(); gb = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888); glow = gb }
            gb!!.eraseColor(0)
            val thr = gw.p("threshold", .45f); val sc = 1f / (1f - thr); val off = -thr * 255f * sc
            val bp = Paint(Paint.FILTER_BITMAP_FLAG)
            bp.colorFilter = ColorMatrixColorFilter(ColorMatrix(floatArrayOf(sc, 0f, 0f, 0f, off, 0f, sc, 0f, 0f, off, 0f, 0f, sc, 0f, off, 0f, 0f, 0f, 1f, 0f)))
            Canvas(gb).drawBitmap(frame, null, Rect(0, 0, sw, sh), bp)
            val gp = Paint(Paint.FILTER_BITMAP_FLAG); gp.xfermode = PorterDuffXfermode(PorterDuff.Mode.ADD); gp.alpha = (255f * gw.k.coerceIn(0f, 1.2f) * 0.85f).toInt().coerceIn(0, 255)
            c.drawBitmap(gb, null, RectF(0f, 0f, W, H), gp)
        }
    }

    // ------------------------------------------------------------------ screen overlays
    private fun overlays(c: Canvas, w: Float, h: Float, fx: FxFrame, t: Float) {
        for (e in fx.list(FxType.BLOOD)) Fx.blood(c, w, h, t, e.k, e.p("bpm", 72f), e.p("size", .45f))
        for (e in fx.list(FxType.VIGNETTE)) Fx.vignette(c, w, h, e.k, e.p("size", .5f))
        for (e in fx.list(FxType.RED_FLASH)) {
            val a = if (e.p("auto", 0f) > 0.5f) (0.5f + 0.5f * sin(t * e.p("rate", 1.5f) * 2f * PI.toFloat())).pow(3f) * e.k else e.k
            if (a > 0.005f) c.drawColor(Color.argb((255 * 0.7f * a.coerceIn(0f, 1f)).toInt(), 215, 0, 18))
        }
        for (e in fx.list(FxType.LIGHTNING)) {
            val st = Fx.lightning(fx.sc, e, t)
            if (st.on) c.drawColor(Color.argb((255 * 0.8f * st.flash.coerceIn(0f, 1f)).toInt(), 225, 232, 255))
        }
        for (e in fx.list(FxType.GRAIN)) Fx.grain(c, w, h, frameIdx, e.k, e.p("size", 1.6f) * (w / 1280f).coerceAtLeast(0.6f))
    }
}
