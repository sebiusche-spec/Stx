package com.stx.horror.engine

import com.stx.horror.model.ProcClip
import kotlin.math.*

class ParamDef(val key: String, val label: String, val min: Float, val max: Float, val def: Float)

/** Result of evaluating one preset at one instant. Rotations are degree deltas added to the rest pose. */
class PresetOut {
    val rot = HashMap<String, Float>()
    val dx = HashMap<String, Float>()
    val dy = HashMap<String, Float>()
    val sy = HashMap<String, Float>()        // role -> y scale multiplier (breathing)
    var charDx = 0f                          // procedural travel in character space
    var eye: Float? = null                   // 0 open, 1 half, 2 closed
    var brow: Float? = null                  // 0 normal 1 angry 2 sad 3 fear 4 surprised
    var mouth: Float? = null                 // 0 closed 1 small 2 medium 3 wide 4 smile 5 fear
    var lookx: Float? = null
    var looky: Float? = null
    fun r(role: String, v: Float) { rot[role] = (rot[role] ?: 0f) + v }
    fun p(role: String, x: Float, y: Float) { dx[role] = (dx[role] ?: 0f) + x; dy[role] = (dy[role] ?: 0f) + y }
}

object Presets {
    val names = listOf(
        "Idle", "Breathing", "Walking", "Slow Walking", "Fast Walking", "Running", "Talking", "Blinking",
        "Waving", "Pointing", "Nodding", "Head Shake", "Fear Reaction", "Looking Around", "Gestures"
    )

    private fun gaitDefs(speed: Float, stride: Float, bounce: Float, arm: Float, knee: Float, lean: Float) = listOf(
        ParamDef("speed", "Speed (cycles/s)", 0.2f, 3.5f, speed),
        ParamDef("stride", "Stride (deg)", 5f, 70f, stride),
        ParamDef("bounce", "Body bounce (px)", 0f, 30f, bounce),
        ParamDef("armSwing", "Arm swing (deg)", 0f, 80f, arm),
        ParamDef("knee", "Knee bend (deg)", 0f, 120f, knee),
        ParamDef("head", "Head movement", 0f, 3f, 1f),
        ParamDef("lean", "Forward lean (deg)", -5f, 25f, lean),
        ParamDef("travel", "Travel (px/s, 0 = in place)", -600f, 600f, 0f)
    )

    fun defs(name: String): List<ParamDef> = when (name) {
        "Walking" -> gaitDefs(1.0f, 26f, 6f, 24f, 45f, 2f)
        "Slow Walking" -> gaitDefs(0.6f, 16f, 3f, 12f, 28f, 0f)
        "Fast Walking" -> gaitDefs(1.5f, 34f, 9f, 34f, 62f, 5f)
        "Running" -> gaitDefs(2.3f, 46f, 16f, 58f, 95f, 14f)
        "Idle" -> listOf(ParamDef("breath", "Breathing", 0f, 3f, 1f), ParamDef("sway", "Weight shift", 0f, 3f, 1f),
            ParamDef("head", "Head drift", 0f, 3f, 1f), ParamDef("speed", "Speed", 0.2f, 3f, 1f))
        "Breathing" -> listOf(ParamDef("breath", "Depth", 0f, 4f, 1.6f), ParamDef("speed", "Rate (breaths/s)", 0.1f, 1.2f, 0.28f))
        "Talking" -> listOf(ParamDef("rate", "Syllables / s", 2f, 9f, 5f), ParamDef("open", "Mouth openness", 0.2f, 1f, 0.8f),
            ParamDef("gesture", "Hand gestures", 0f, 3f, 1f), ParamDef("head", "Head movement", 0f, 3f, 1f),
            ParamDef("brow", "Eyebrow movement", 0f, 1f, 1f), ParamDef("seed", "Variation seed", 0f, 99f, 3f))
        "Blinking" -> listOf(ParamDef("interval", "Avg. interval (s)", 1f, 8f, 3.4f), ParamDef("speed", "Blink speed", 0.5f, 2f, 1f),
            ParamDef("seed", "Variation seed", 0f, 99f, 7f))
        "Waving" -> listOf(ParamDef("speed", "Wave speed (Hz)", 0.5f, 5f, 2.4f), ParamDef("amount", "Wave size", 0f, 2f, 1f),
            ParamDef("side", "Hand (0 right, 1 left)", 0f, 1f, 0f))
        "Pointing" -> listOf(ParamDef("raise", "Raise (deg)", 20f, 120f, 90f), ParamDef("side", "Hand (0 right, 1 left)", 0f, 1f, 0f),
            ParamDef("lean", "Body lean", 0f, 15f, 4f))
        "Nodding" -> listOf(ParamDef("speed", "Nods / s", 0.5f, 4f, 1.6f), ParamDef("amount", "Amount (deg)", 2f, 30f, 11f))
        "Head Shake" -> listOf(ParamDef("speed", "Shakes / s", 0.5f, 4f, 1.8f), ParamDef("amount", "Amount", 0.2f, 1f, 0.8f))
        "Fear Reaction" -> listOf(ParamDef("intensity", "Intensity", 0f, 2f, 1f), ParamDef("tremble", "Trembling", 0f, 3f, 1.2f),
            ParamDef("recoil", "Recoil (px)", 0f, 60f, 18f))
        "Looking Around" -> listOf(ParamDef("speed", "Speed", 0.2f, 3f, 0.7f), ParamDef("range", "Range", 0.2f, 1f, 0.9f),
            ParamDef("vertical", "Up/down", 0f, 1f, 0.3f))
        "Gestures" -> listOf(ParamDef("speed", "Speed", 0.3f, 3f, 1f), ParamDef("amount", "Amount", 0f, 2f, 1f))
        else -> emptyList()
    }

    fun defaultParams(name: String): LinkedHashMap<String, Float> {
        val m = linkedMapOf<String, Float>(); defs(name).forEach { m[it.key] = it.def }; return m
    }
    fun defaultDuration(name: String) = when (name) {
        "Blinking", "Idle", "Breathing", "Talking" -> 8f
        "Waving", "Pointing", "Fear Reaction" -> 3f
        "Nodding", "Head Shake" -> 2.5f
        else -> 4f
    }

    private fun TAU() = (2.0 * PI).toFloat()
    private fun sn(x: Float) = sin(x)

    /** Evaluate preset for local time lt (seconds inside the clip). env = fade envelope 0..1. */
    fun eval(clip: ProcClip, lt: Float, env: Float, out: PresetOut) {
        val pr = clip.params
        fun g(k: String, d: Float) = pr[k] ?: d
        val w = clip.weight * env
        if (w <= 0.0001f) return
        val o = PresetOut()
        when (clip.preset) {
            "Walking", "Slow Walking", "Fast Walking", "Running" -> gait(o, lt) { k, d -> g(k, d) }
            "Idle" -> idle(o, lt, g("breath", 1f), g("sway", 1f), g("head", 1f), g("speed", 1f))
            "Breathing" -> idle(o, lt * (g("speed", .28f) / 0.25f), g("breath", 1.6f), 0f, 0.3f, 1f)
            "Talking" -> talking(o, lt, g("rate", 5f), g("open", .8f), g("gesture", 1f), g("head", 1f), g("brow", 1f), g("seed", 3f).toInt())
            "Blinking" -> o.eye = blink(lt, g("interval", 3.4f), g("speed", 1f), g("seed", 7f).toInt())
            "Waving" -> waving(o, lt, clip.duration, g("speed", 2.4f), g("amount", 1f), g("side", 0f) > 0.5f)
            "Pointing" -> pointing(o, lt, clip.duration, g("raise", 90f), g("side", 0f) > 0.5f, g("lean", 4f))
            "Nodding" -> { val a = g("amount", 11f); o.r("head", a * sn(TAU() * g("speed", 1.6f) * lt)); o.r("neck", a * 0.35f * sn(TAU() * g("speed", 1.6f) * lt)); o.mouth = 0f }
            "Head Shake" -> { val a = g("amount", .8f); val v = sn(TAU() * g("speed", 1.8f) * lt); o.lookx = v * a; o.r("head", v * a * 6f); o.brow = 2f }
            "Fear Reaction" -> fear(o, lt, clip.duration, g("intensity", 1f), g("tremble", 1.2f), g("recoil", 18f))
            "Looking Around" -> lookAround(o, lt, g("speed", .7f), g("range", .9f), g("vertical", .3f))
            "Gestures" -> gestures(o, lt, g("speed", 1f), g("amount", 1f))
        }
        // merge with weight
        o.rot.forEach { (k, v) -> out.rot[k] = (out.rot[k] ?: 0f) + v * w }
        o.dx.forEach { (k, v) -> out.dx[k] = (out.dx[k] ?: 0f) + v * w }
        o.dy.forEach { (k, v) -> out.dy[k] = (out.dy[k] ?: 0f) + v * w }
        o.sy.forEach { (k, v) -> out.sy[k] = (out.sy[k] ?: 1f) * (1f + (v - 1f) * w) }
        out.charDx += o.charDx * clip.weight
        o.eye?.let { out.eye = it }; o.brow?.let { out.brow = it }; o.mouth?.let { out.mouth = it }
        o.lookx?.let { out.lookx = (out.lookx ?: 0f) + it * w }; o.looky?.let { out.looky = (out.looky ?: 0f) + it * w }
    }

    // ------------------------------------------------------------ gait (walk / run)
    private fun gait(o: PresetOut, lt: Float, g: (String, Float) -> Float) {
        val f = g("speed", 1f); val stride = g("stride", 26f); val bounce = g("bounce", 6f)
        val arm = g("armSwing", 24f); val knee = g("knee", 45f); val head = g("head", 1f); val lean = g("lean", 2f)
        val p = TAU() * f * lt
        val run = stride > 40f
        for (side in 0..1) {
            val ph = p + side * PI.toFloat()
            val s = sn(ph); val c = cos(ph)
            val sfx = if (side == 0) "L" else "R"
            val thigh = -stride * s                               // swing forward (negative = toward +x)
            val kneeBend = knee * max(0f, cos(ph - 0.35f)).pow(if (run) 1f else 1.3f) + knee * 0.12f
            o.r("leg${sfx}1", thigh)
            o.r("leg${sfx}2", kneeBend)
            o.r("foot$sfx", -(thigh + kneeBend) * 0.55f + 8f * c)
            // contralateral arm
            val a = arm * s
            val elbow = -(arm * 0.35f + arm * 0.45f * max(0f, -s)) - (if (run) 25f else 6f)
            o.r("arm${sfx}1", a)
            o.r("arm${sfx}2", elbow)
            o.r("hand$sfx", 6f * s)
        }
        o.p("hip", 2.2f * sn(p), bounce * abs(sn(p)) - bounce * 0.5f)
        o.r("spine", lean + 1.8f * sn(p + 0.5f) * (if (run) 2f else 1f))
        o.r("neck", -lean * 0.4f)
        o.r("head", -lean * 0.5f - 1.8f * sn(p + 0.5f) * head + 1.2f * head * sn(2 * p))   // stabilises head against torso
        o.p("head", 0f, 0f)
        o.charDx = g("travel", 0f) * lt
        o.r("hair", 4f * sn(2 * p - 0.8f)); o.r("scarf", 7f * sn(2 * p - 1.1f)); o.r("coat", 3f * sn(2 * p - 0.6f))
    }

    private fun idle(o: PresetOut, lt: Float, breath: Float, sway: Float, head: Float, speed: Float) {
        val b = sn(TAU() * 0.25f * speed * lt)
        o.r("spine", 0.9f * breath * b); o.r("neck", -0.4f * breath * b); o.r("head", -0.5f * breath * b + 1.2f * head * sn(TAU() * 0.11f * speed * lt))
        o.r("armL1", 1.6f * breath * b + 0.8f * sway * sn(TAU() * 0.1f * lt)); o.r("armR1", -1.6f * breath * b - 0.8f * sway * sn(TAU() * 0.1f * lt))
        o.r("armL2", -1.0f * breath * b); o.r("armR2", -1.0f * breath * b)
        o.p("hip", 3.5f * sway * sn(TAU() * 0.08f * speed * lt), 0.9f * breath * b)
        o.r("legL1", 1.2f * sway * sn(TAU() * 0.08f * lt)); o.r("legR1", -1.2f * sway * sn(TAU() * 0.08f * lt))
        o.sy["spine"] = 1f + 0.012f * breath * b
        o.r("hair", 1.5f * sn(TAU() * 0.3f * lt)); o.r("scarf", 2.5f * sn(TAU() * 0.35f * lt - 1f)); o.r("coat", 1.2f * sn(TAU() * 0.3f * lt - .5f))
    }

    // ------------------------------------------------------------ talking
    private fun talking(o: PresetOut, lt: Float, rate: Float, open: Float, gesture: Float, head: Float, brow: Float, seed: Int) {
        val syl = floor(lt * rate).toInt()
        val u = lt * rate - syl
        val level = Anim.hash2(syl, seed)
        val pause = Anim.hash2(syl / 7, seed + 5) < 0.18f              // short pauses between phrases
        val env = if (pause) 0f else sin(PI.toFloat() * u).pow(0.7f)
        val amp = (0.35f + 0.65f * level) * open * env
        o.mouth = when { amp < 0.12f -> 0f; amp < 0.38f -> 1f; amp < 0.68f -> 2f; else -> 3f }
        val stress = if (Anim.hash2(syl, seed + 11) > 0.82f && !pause) 1f else 0f
        o.brow = if (brow > 0.4f && stress > 0.5f) 4f else 0f
        o.r("head", head * (2.2f * sn(TAU() * 0.7f * lt) + 4f * stress * sin(PI.toFloat() * u)))
        o.r("neck", head * 0.8f * sn(TAU() * 0.7f * lt + 1f))
        o.p("hip", 1.5f * head * sn(TAU() * 0.3f * lt), 0f)
        o.r("spine", 1.4f * head * sn(TAU() * 0.35f * lt))
        val gs = Anim.hash2(lt.toInt() / 2, seed + 21) > 0.3f
        val gi = if (gs) gesture else 0f
        val gp = sin(PI.toFloat() * ((lt / 2f) - floor(lt / 2f)))
        o.r("armR1", -38f * gi * gp * (0.6f + 0.4f * sn(TAU() * 0.9f * lt))); o.r("armR2", -45f * gi * gp)
        o.r("handR", 14f * gi * gp * sn(TAU() * 2f * lt))
        o.r("armL1", -12f * gi * gp * sn(TAU() * 0.6f * lt)); o.r("armL2", -18f * gi * gp)
        o.r("hair", 2f * sn(TAU() * 0.5f * lt))
    }

    /** Returns eye state 0 open .. 1 half .. 2 closed with natural randomised timing. */
    fun blink(lt: Float, interval: Float, speed: Float, seed: Int): Float {
        // walk through blink events, each placed after a random interval
        var t = 0f; var n = 0
        val dur = 0.24f / speed
        // fast skip: events are cheap, but cap iterations for long clips
        while (n < 4000) {
            val gap = interval * (0.45f + 1.1f * Anim.hash2(n, seed))
            t += gap
            val dbl = Anim.hash2(n, seed + 3) < 0.18f
            val total = if (dbl) dur * 2.3f else dur
            if (lt < t) return 0f
            if (lt <= t + total) {
                var l = lt - t
                if (dbl && l > dur * 1.3f) l -= dur * 1.3f
                if (l > dur) return 0f
                val u = l / dur
                // open(0) -> half(1) -> closed(2) -> half(1) -> open(0)
                return when {
                    u < 0.3f -> u / 0.3f
                    u < 0.5f -> 1f + (u - 0.3f) / 0.2f
                    u < 0.75f -> 2f - (u - 0.5f) / 0.25f
                    else -> 1f - (u - 0.75f) / 0.25f
                }.coerceIn(0f, 2f)
            }
            t += total
            n++
        }
        return 0f
    }

    private fun envelope(lt: Float, dur: Float, rise: Float = 0.35f): Float =
        Anim.smooth(min(lt / rise, (dur - lt) / rise))

    private fun waving(o: PresetOut, lt: Float, dur: Float, speed: Float, amount: Float, left: Boolean) {
        val e = envelope(lt, dur, 0.4f); val s = if (left) "L" else "R"
        o.r("arm${s}1", -150f * e + 6f * amount * sn(TAU() * speed * lt) * e)
        o.r("arm${s}2", (-20f + 28f * amount * sn(TAU() * speed * lt)) * e)
        o.r("hand$s", 18f * amount * sn(TAU() * speed * lt + 0.9f) * e)
        o.r("head", -4f * e); o.r("spine", -2f * e); o.mouth = if (e > 0.5f) 4f else 0f
    }

    private fun pointing(o: PresetOut, lt: Float, dur: Float, raise: Float, left: Boolean, lean: Float) {
        val e = envelope(lt, dur, 0.4f); val s = if (left) "L" else "R"
        o.r("arm${s}1", -raise * e + 0.8f * sn(TAU() * 3f * lt) * e)
        o.r("arm${s}2", -4f * e); o.r("hand$s", -6f * e)
        o.r("spine", lean * e); o.r("head", 3f * e); o.p("hip", 4f * e, 0f)
        o.brow = if (e > 0.5f) 1f else 0f
    }

    private fun fear(o: PresetOut, lt: Float, dur: Float, k: Float, tremble: Float, recoil: Float) {
        val e = Anim.smooth(lt / 0.18f) * (if (dur - lt > 0.4f) 1f else Anim.smooth((dur - lt) / 0.4f))
        val jit = { seed: Int, f: Float -> Anim.noise(lt * f, seed) }
        o.p("hip", -recoil * e * k, 8f * e * k)
        o.r("spine", -9f * e * k + tremble * 1.2f * jit(1, 22f))
        o.r("neck", -6f * e * k); o.r("head", -9f * e * k + tremble * 2f * jit(2, 26f))
        o.r("armL1", -55f * e * k + tremble * 4f * jit(3, 25f)); o.r("armR1", -62f * e * k + tremble * 4f * jit(4, 25f))
        o.r("armL2", -85f * e * k + tremble * 5f * jit(5, 28f)); o.r("armR2", -95f * e * k + tremble * 5f * jit(6, 28f))
        o.r("handL", 10f * tremble * jit(7, 30f)); o.r("handR", 10f * tremble * jit(8, 30f))
        o.r("legL1", 6f * e * k + tremble * 1.5f * jit(9, 24f)); o.r("legR1", -10f * e * k + tremble * 1.5f * jit(10, 24f))
        o.r("legL2", 10f * e * k); o.r("legR2", 14f * e * k)
        o.brow = 3f; o.mouth = if (e > 0.3f) 5f else 0f; o.eye = 0f
        o.lookx = 0.35f * tremble * jit(11, 6f); o.looky = 0.1f
        o.r("hair", 6f * tremble * jit(12, 18f)); o.r("scarf", 8f * jit(13, 14f))
    }

    private fun lookAround(o: PresetOut, lt: Float, speed: Float, range: Float, vert: Float) {
        val t = lt * speed
        val lx = (0.75f * sn(TAU() * 0.21f * t) + 0.4f * sn(TAU() * 0.53f * t + 1.3f)).coerceIn(-1f, 1f) * range
        o.lookx = lx
        o.looky = (0.6f * sn(TAU() * 0.17f * t + 2f)).coerceIn(-1f, 1f) * vert
        o.r("spine", lx * 2.5f)
    }

    private fun gestures(o: PresetOut, lt: Float, speed: Float, amount: Float) {
        val t = lt * speed
        o.r("armR1", amount * (-30f + 22f * sn(TAU() * 0.45f * t))); o.r("armR2", amount * (-50f + 28f * sn(TAU() * 0.7f * t + 1f)))
        o.r("armL1", amount * (-18f + 15f * sn(TAU() * 0.38f * t + 2f))); o.r("armL2", amount * (-35f + 20f * sn(TAU() * 0.6f * t)))
        o.r("handR", amount * 16f * sn(TAU() * 1.1f * t)); o.r("handL", amount * 12f * sn(TAU() * 0.9f * t + 1f))
        o.r("spine", 1.5f * sn(TAU() * 0.3f * t)); o.r("head", 2f * sn(TAU() * 0.4f * t + 0.5f))
    }
}
