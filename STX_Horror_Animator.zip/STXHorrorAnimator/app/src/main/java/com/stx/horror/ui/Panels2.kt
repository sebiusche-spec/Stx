@file:OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
package com.stx.horror.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.stx.horror.data.PartCutter
import com.stx.horror.engine.*
import com.stx.horror.model.*
import androidx.compose.foundation.layout.Arrangement
import kotlin.math.*

// ====================================================================================== CAMERA
@Composable
fun CameraPanel(st: EditorState) {
    val sc = st.scene; val cfg = sc.camera
    var dur by remember { mutableFloatStateOf(3f) }
    Title("Camera presets (written as keyframes at the playhead)")
    Sl("Length (s)", dur, 0.3f, 12f) { dur = it }
    Flow { listOf("Horror Zoom", "Slow Push In", "Fast Zoom", "Shake", "Heartbeat Camera", "Reveal", "Dramatic Pull Back").forEach { n -> Tag(n, false, C.Red) { st.cameraPreset(n, dur) } } }
    Glass(Modifier.fillMaxWidth().padding(top = 6.dp)) {
        Title("Camera keyframes")
        PropRow(st, "cam", "zoom", "Zoom", 0.3f, 4f); PropRow(st, "cam", "x", "Pan X", 0f, st.project.width.toFloat(), "%.0f")
        PropRow(st, "cam", "y", "Tilt / Pan Y", 0f, st.project.height.toFloat(), "%.0f"); PropRow(st, "cam", "rot", "Roll", -30f, 30f, "%.1f")
        PropRow(st, "cam", "shake", "Shake", 0f, 3f); PropRow(st, "cam", "hand", "Handheld", 0f, 3f)
        PropRow(st, "cam", "focus", "Focus depth", 8f, 200f, "%.0f")
        Flow { Neon("Reset camera keys", color = C.Red) { st.edit { sc.tracksOf("cam").forEach { sc.removeTrack(it) } } } }
    }
    Glass(Modifier.fillMaxWidth().padding(top = 6.dp)) {
        Title("Tracking / follow")
        Flow {
            Tag("No follow", cfg.followChar.isEmpty()) { st.cameraFollow("", 0f) }
            sc.characters.forEach { c -> Tag("Follow ${c.name}", cfg.followChar == c.id, C.Green) { st.cameraFollow(c.id, 1f) } }
        }
        Sl("Follow amount", cfg.followAmt, 0f, 1f) { v -> st.edit("fa") { cfg.followAmt = v } }
        Sl("Smoothing (s)", cfg.followLag, 0f, 2f) { v -> st.edit("fl") { cfg.followLag = v } }
        Sl("Offset X", cfg.followOffX, -600f, 600f, fmt = "%.0f") { v -> st.edit("fox") { cfg.followOffX = v } }
        Sl("Offset Y", cfg.followOffY, -800f, 400f, fmt = "%.0f") { v -> st.edit("foy") { cfg.followOffY = v } }
        Title("2.5D parallax & depth of field")
        Sl("Parallax", cfg.parallax, 0f, 2.5f) { v -> st.edit("par") { cfg.parallax = v } }
        Sl("Focus depth", cfg.focusDepth, 8f, 200f, fmt = "%.0f") { v -> st.edit("fd") { cfg.focusDepth = v } }
        Sl("Blur (DOF)", cfg.dof, 0f, 2f) { v -> st.edit("dof") { cfg.dof = v } }
        Sl("Base shake", cfg.shake, 0f, 3f) { v -> st.edit("bs") { cfg.shake = v } }
        Sl("Base handheld", cfg.handheld, 0f, 3f) { v -> st.edit("bh") { cfg.handheld = v } }
        Text("Layers have a depth (Assets tab): background 100 · character 50 · foreground 20. Moving or zooming the camera shifts them at different rates.", color = C.Muted, fontSize = 10.sp)
    }
}

// ====================================================================================== EFFECTS + LIGHTS
@Composable
fun EffectsPanel(st: EditorState) {
    val sc = st.scene
    Title("Weather")
    Flow {
        Tag("Light rain", false, C.Neon) { st.addEffectObj(FxDefs.weatherPreset("Light rain")) }
        Tag("Rain", false, C.Neon) { st.addEffectObj(FxDefs.weatherPreset("Rain")) }
        Tag("Heavy rain", false, C.Neon) { st.addEffectObj(FxDefs.weatherPreset("Heavy rain")) }
        listOf(FxType.SNOW, FxType.FOG, FxType.SMOKE, FxType.DUST, FxType.WIND).forEach { t -> Tag(t.label, false, C.Neon) { st.addEffect(t) } }
    }
    Title("Horror & post effects")
    Flow { FxType.values().filter { it.group != "Weather" }.forEach { t -> Tag(t.label, false, C.Red) { st.addEffect(t) } } }
    Title("Active effects")
    sc.effects.forEach { e ->
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(e.enabled, { v -> st.edit { e.enabled = v } })
            Text(e.type.label, color = if (e.id == st.selFx) C.Amber else C.Text, fontSize = 13.sp, modifier = Modifier.weight(1f).clickableNoRipple { st.selFx = e.id })
            Neon("✕", color = C.Red) { st.deleteEffect(e.id) }
        }
    }
    val fx = sc.effects.firstOrNull { it.id == st.selFx }
    if (fx != null) Glass(Modifier.fillMaxWidth()) {
        Title(fx.type.label)
        PropRow(st, fx.id, "intensity", "Intensity", 0f, 2f)
        Sl("Start (s)", fx.start, 0f, sc.duration) { v -> st.edit("fs") { fx.start = v } }
        Sl("End (s)", if (fx.end < 0) sc.duration else fx.end, 0f, sc.duration) { v -> st.edit("fe") { fx.end = if (v >= sc.duration - 0.01f) -1f else v } }
        FxDefs.params(fx.type).forEach { d -> Sl(d.label, fx.params[d.key] ?: d.def, d.min, d.max) { v -> st.edit("fp${fx.id}${d.key}") { fx.params[d.key] = v } } }
        Label("Keyframe Intensity to time flashes, lightning strikes (Lightning with auto = 0) and fades.")
        Flow { Neon("Save effect to library", color = C.Green) { st.libSave("effect", fx.type.label); st.toast("Saved") } }
    }
    val lib = remember(st.version) { st.repo.libraryList("effect") }
    if (lib.isNotEmpty()) { Label("Effect library"); Flow { lib.forEach { Tag(it.name, false, C.Violet) { st.libLoad(it) } } } }

    Title("Lighting")
    Sl("Ambient darkness", sc.ambient, 0f, 0.97f) { v -> st.edit("amb") { sc.ambient = v } }
    Sl("Scene wind", sc.wind, -1.5f, 1.5f) { v -> st.edit("wind") { sc.wind = v } }
    Flow { LightType.values().forEach { t -> Tag("＋ " + t.label, false, C.Amber) { st.addLight(t) } } }
    sc.lights.forEach { li ->
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(li.enabled, { v -> st.edit { li.enabled = v } })
            Text(li.name, color = if (li.id == st.selLight) C.Amber else C.Text, fontSize = 13.sp, modifier = Modifier.weight(1f).clickableNoRipple { st.selLight = li.id })
            Neon("✕", color = C.Red) { st.deleteLight(li.id) }
        }
    }
    val li = sc.lights.firstOrNull { it.id == st.selLight }
    if (li != null) Glass(Modifier.fillMaxWidth()) {
        Title(li.name)
        PropRow(st, li.id, "x", "X", -500f, st.project.width + 500f, "%.0f"); PropRow(st, li.id, "y", "Y", -500f, st.project.height + 500f, "%.0f")
        PropRow(st, li.id, "radius", "Radius", 40f, 2000f, "%.0f"); PropRow(st, li.id, "intensity", "Intensity", 0f, 2f)
        PropRow(st, li.id, "angle", "Direction", -180f, 180f, "%.0f")
        Sl("Cone", li.cone, 5f, 80f, fmt = "%.0f") { v -> st.edit("lc") { li.cone = v } }
        Sl("Falloff", li.falloff, 0.3f, 4f) { v -> st.edit("lfo") { li.falloff = v } }
        Sl("Flicker", li.flicker, 0f, 1f) { v -> st.edit("lfl") { li.flicker = v } }
        Label("Colour")
        Flow { listOf(0xFFFFC878, 0xFFFFF2CC, 0xFFFFA24A, 0xFFCFE0FF, 0xFF9DFFB0, 0xFFFF4D5E).forEach { c -> Box(Modifier.padding(3.dp).size(30.dp).background(Color(c), androidx.compose.foundation.shape.CircleShape).clickableNoRipple { st.edit { li.color = c.toInt() } }) } }
        Label("Attach to a character bone (e.g. flashlight in a hand) – X/Y become offsets")
        val ch = st.character()
        if (ch != null) Flow {
            Pick("Bone", st.scene.bonesOf(ch.id), sc.bone(li.followBone), { it.name }) { b -> st.edit { li.followChar = ch.id; li.followBone = b.id; li.x = 0f; li.y = 0f } }
            if (li.followChar.isNotEmpty()) Neon("Unattach") { st.edit { li.followChar = ""; li.followBone = ""; li.x = st.project.width / 2f; li.y = st.project.height / 2f } }
        }
    }
}

fun Modifier.clickableNoRipple(onClick: () -> Unit): Modifier = this.then(Modifier.pointerInput(Unit) { detectTapGestures { onClick() } })

// ====================================================================================== AUDIO
@Composable
fun AudioPanel(st: EditorState) {
    val sc = st.scene; val pr = st.project
    var kind by remember { mutableStateOf(AudioKind.VOICE) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) st.importAudio(u, kind) }
    Title("Import (MP3 · WAV · M4A)")
    Flow {
        AudioKind.values().forEach { k -> Tag(k.label, kind == k, C.Green) { kind = k } }
    }
    Neon("＋ Import ${kind.label.lowercase()} file at playhead") { picker.launch(arrayOf("audio/*")) }
    Title("Built-in horror sound library (generated offline)")
    Flow { Sfx.names.forEach { n -> Tag(n, false, C.Violet) { st.addSfx(n) } } }
    Title("Mixer")
    Sl("Master", pr.volMaster, 0f, 1.5f) { v -> st.edit("vm") { pr.volMaster = v } }
    Sl("Music", pr.volMusic, 0f, 1.5f) { v -> st.edit("vmu") { pr.volMusic = v } }
    Sl("Voice", pr.volVoice, 0f, 1.5f) { v -> st.edit("vv") { pr.volVoice = v } }
    Sl("SFX", pr.volSfx, 0f, 1.5f) { v -> st.edit("vs") { pr.volSfx = v } }
    Title("Clips on this scene")
    sc.audio.forEach { c -> Row(Modifier.fillMaxWidth().clickableNoRipple { st.selAudio = c.id }, verticalAlignment = Alignment.CenterVertically) {
        Text("${c.kind.label} · ${c.name} @ ${"%.1f".format(c.start)}s", color = if (c.id == st.selAudio) C.Amber else C.Text, fontSize = 12.sp, modifier = Modifier.weight(1f).padding(vertical = 5.dp)) } }
    val c = sc.audio.firstOrNull { it.id == st.selAudio }
    if (c != null) Glass(Modifier.fillMaxWidth()) {
        Title(c.name)
        Flow { AudioKind.values().forEach { k -> Tag(k.label, c.kind == k, C.Green) { st.edit { c.kind = k } } } }
        Sl("Start", c.start, 0f, sc.duration, fmt = "%.2f") { v -> st.edit("as${c.id}") { c.start = v } }
        Sl("Trim in", c.trimIn, 0f, max(0.1f, c.sourceLen - 0.1f), fmt = "%.2f") { v -> st.edit("ati${c.id}") { c.trimIn = v; c.length = min(c.length, c.sourceLen - v) } }
        Sl("Length", c.length, 0.1f, if (c.loop) max(60f, sc.duration) else max(0.2f, c.sourceLen - c.trimIn), fmt = "%.2f") { v -> st.edit("al${c.id}") { c.length = v } }
        Sl("Volume", c.gain, 0f, 2f) { v -> st.edit("ag${c.id}") { c.gain = v } }
        Sl("Fade in", c.fadeIn, 0f, 5f) { v -> st.edit("afi${c.id}") { c.fadeIn = v } }
        Sl("Fade out", c.fadeOut, 0f, 5f) { v -> st.edit("afo${c.id}") { c.fadeOut = v } }
        Toggle("Loop", c.loop) { v -> st.edit { c.loop = v } }
        Toggle("Mute", c.muted) { v -> st.edit { c.muted = v } }
        Flow { Neon("Sync start to playhead") { st.edit { c.start = st.time } }; Neon("Delete", color = C.Red) { st.edit { sc.audio.remove(c); st.selAudio = "" } } }
        if (c.kind == AudioKind.VOICE || c.kind == AudioKind.DIALOGUE) {
            Title("Talking animation")
            Flow { sc.characters.forEach { ch -> Tag(ch.name, c.charId == ch.id, C.Amber) { st.edit { c.charId = ch.id } } } }
            Neon("Generate lip-sync from this voice", color = C.Red) { st.lipSync(c.id) }
            Text("Creates Closed / Small / Medium / Wide mouth keyframes from the voice amplitude. Edit them afterwards on the timeline (Face · Mouth row).", color = C.Muted, fontSize = 10.sp)
        }
    }
}

// ====================================================================================== SCENES + LIBRARY
@Composable
fun ScenePanel(st: EditorState) {
    val sc = st.scene
    Title("Scenes")
    st.project.scenes.forEachIndexed { i, s ->
        Row(Modifier.fillMaxWidth().clickableNoRipple { st.gotoScene(i) }, verticalAlignment = Alignment.CenterVertically) {
            Text("${i + 1}.  ${s.name}  (${"%.1f".format(s.duration)}s)", color = if (i == st.sceneIdx) C.Neon else C.Text, fontSize = 14.sp, modifier = Modifier.padding(vertical = 7.dp))
        }
    }
    Flow { Neon("＋ Scene", color = C.Green) { st.addScene() }; Neon("Duplicate") { st.duplicateScene() }; Neon("Delete", color = C.Red) { st.deleteScene() } }
    var name by remember(st.sceneIdx) { mutableStateOf(sc.name) }
    OutlinedTextField(name, { name = it; st.edit("sn") { sc.name = it } }, label = { Text("Scene name", fontSize = 11.sp) }, singleLine = true, modifier = Modifier.fillMaxWidth())
    Sl("Duration (s)", sc.duration, 1f, 180f, fmt = "%.1f") { v -> st.edit("sd") { sc.duration = v } }
    Label("Background colour")
    Flow { listOf(0xFF05060A, 0xFF0D1018, 0xFF1A0508, 0xFF10161C, 0xFF000000, 0xFF2A2F3A).forEach { c -> Box(Modifier.padding(3.dp).size(30.dp).background(Color(c), androidx.compose.foundation.shape.CircleShape).clickableNoRipple { st.edit { sc.bgColor = c.toInt() } }) } }
    Title("Project")
    var pn by remember { mutableStateOf(st.project.name) }
    OutlinedTextField(pn, { pn = it; st.edit("pn") { st.project.name = it } }, label = { Text("Project name", fontSize = 11.sp) }, singleLine = true, modifier = Modifier.fillMaxWidth())
    Text("Autosave runs every 8 s. “Save” in the top bar writes the project file; on the next start any newer autosave is offered for recovery.", color = C.Muted, fontSize = 10.sp)

    Title("Library · reuse in any project")
    var libName by remember { mutableStateOf("") }
    OutlinedTextField(libName, { libName = it }, label = { Text("Name for new library item", fontSize = 11.sp) }, singleLine = true, modifier = Modifier.fillMaxWidth())
    Label("Save from the current selection:")
    Flow {
        listOf("character" to "Character", "rig" to "Rig", "pose" to "Pose", "animation" to "Animation", "expression" to "Expression", "prop" to "Prop", "background" to "Background", "effect" to "Effect").forEach { (t, n) ->
            Tag("Save $n", false, C.Green) { st.toast(if (st.libSave(t, libName.ifBlank { "$n ${System.currentTimeMillis() % 1000}" })) "$n saved to library" else "Select the right item first") }
        }
    }
    var filter by remember { mutableStateOf("character") }
    Flow { listOf("character", "rig", "pose", "animation", "expression", "prop", "background", "effect").forEach { Tag(it, filter == it, C.Violet) { filter = it } } }
    val items = remember(st.version, filter, st.message) { st.repo.libraryList(filter) }
    items.forEach { it0 -> Row(verticalAlignment = Alignment.CenterVertically) {
        Text(it0.name, color = C.Text, fontSize = 13.sp, modifier = Modifier.weight(1f))
        Neon("Use") { st.libLoad(it0) }; Spacer(Modifier.width(4.dp)); Neon("✕", color = C.Red) { st.repo.libraryDelete(it0); st.toast("Deleted"); st.version++ } } }
    if (items.isEmpty()) Text("Nothing saved for “$filter” yet.", color = C.Muted, fontSize = 11.sp)
}

// ====================================================================================== EXPORT
@Composable
fun ExportPanel(st: EditorState) {
    var h by remember { mutableStateOf(720) }; var fps by remember { mutableStateOf(st.project.fps.takeIf { it in listOf(24, 25, 30, 60) } ?: 30) }
    var q by remember { mutableStateOf(1) }; var all by remember { mutableStateOf(true) }
    Title("Export MP4")
    Label("Resolution"); Flow { listOf(1080, 720, 480).forEach { Tag("${it}p", h == it) { h = it } } }
    Label("Frame rate"); Flow { listOf(24, 25, 30, 60).forEach { Tag("$it fps", fps == it) { fps = it } } }
    Label("Quality"); Flow { listOf("Low", "Medium", "High", "Max").forEachIndexed { i, n -> Tag(n, q == i) { q = i } } }
    Label("Range"); Flow { Tag("All scenes", all, C.Violet) { all = true }; Tag("Current scene", !all, C.Violet) { all = false } }
    val dur = if (all) st.project.scenes.sumOf { it.duration.toDouble() }.toFloat() else st.scene.duration
    Text("${"%.1f".format(dur)} s · ${(dur * fps).roundToInt()} frames. The real animation is rendered frame by frame with the full-quality renderer (not the preview). 1080p/60fps on a phone can take several minutes – keep the app open.", color = C.Muted, fontSize = 11.sp)
    Neon("▶  Render MP4", color = C.Red) { st.export(h, fps, listOf(0.05f, 0.09f, 0.15f, 0.22f)[q], all) }
    if (st.exportText.isNotEmpty()) Text(st.exportText, color = C.Green, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
    Text("Output is saved in Movies/STXHorrorAnimator.", color = C.Muted, fontSize = 11.sp)
}

// ====================================================================================== PART CUTTER
@Composable
fun CutterDialog(st: EditorState, onClose: () -> Unit) {
    val l = st.layer()
    if (l == null) { onClose(); return }
    val bmp = remember(l.id) { st.cache.get(l.image, 2048) }
    if (bmp == null) { onClose(); return }
    var poly by remember { mutableStateOf(listOf<Offset>()) }
    var label by remember { mutableStateOf("Head") }
    var erase by remember { mutableStateOf(true) }
    var size by remember { mutableStateOf(IntSize(1, 1)) }
    val scale = min(size.width / bmp.width.toFloat(), size.height / bmp.height.toFloat())
    val ox = (size.width - bmp.width * scale) / 2f; val oy = (size.height - bmp.height * scale) / 2f
    val made = remember { mutableStateListOf<FloatArray>() }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxSize().background(C.Bg).padding(8.dp)) {
            Text("Cut '${l.name}' into movable parts", color = C.Neon, fontSize = 15.sp)
            Text("Tap around a body part to draw its outline, then press “Cut region”. Or use the automatic humanoid split and fix up regions.", color = C.Muted, fontSize = 11.sp)
            Box(Modifier.weight(1f).fillMaxWidth().background(Color(0xFF15171F)).onSizeChanged { size = it }.pointerInput(scale) { detectTapGestures { o -> poly = poly + Offset(o.x, o.y) } }) {
                Canvas(Modifier.fillMaxSize()) {
                    drawImage(bmp.asImageBitmap(), dstOffset = androidx.compose.ui.unit.IntOffset(ox.toInt(), oy.toInt()), dstSize = IntSize((bmp.width * scale).toInt(), (bmp.height * scale).toInt()))
                    made.forEach { pl -> var i = 0; while (i + 3 < pl.size) { drawLine(C.Green, Offset(ox + pl[i] * scale, oy + pl[i + 1] * scale), Offset(ox + pl[i + 2] * scale, oy + pl[i + 3] * scale), 2f); i += 2 }
                        drawLine(C.Green, Offset(ox + pl[pl.size - 2] * scale, oy + pl[pl.size - 1] * scale), Offset(ox + pl[0] * scale, oy + pl[1] * scale), 2f) }
                    for (i in poly.indices) { drawCircle(C.Red, 7f, poly[i]); if (i > 0) drawLine(C.Red, poly[i - 1], poly[i], 3f) }
                    if (poly.size > 2) drawLine(C.Red.copy(alpha = 0.4f), poly.last(), poly.first(), 2f, pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(10f, 10f)))
                }
            }
            OutlinedTextField(label, { label = it }, label = { Text("Part name (head, left arm, right thigh, torso…)", fontSize = 11.sp) }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Toggle("Erase cut area from the original (so the part can move)", erase) { erase = it }
            Flow {
                Neon("Cut region", color = C.Red, enabled = poly.size >= 3) {
                    val pts = FloatArray(poly.size * 2) { i -> val p = poly[i / 2]; if (i % 2 == 0) (p.x - ox) / scale else (p.y - oy) / scale }
                    made.add(pts); cutParts(st, l, bmp, listOf(label to pts), false); poly = emptyList(); label = ""
                }
                Neon("Undo point", enabled = poly.isNotEmpty()) { poly = poly.dropLast(1) }
                Neon("Clear") { poly = emptyList() }
                Neon("Auto-split humanoid", color = C.Violet) {
                    val b = PartCutter.alphaBounds(bmp); val regs = PartCutter.humanoidRegions(b)
                    regs.forEach { made.add(it.poly) }
                    cutParts(st, l, bmp, regs.map { it.label to it.poly }, true)
                }
                Neon("Finish") { 
                    if (erase && made.isNotEmpty()) eraseOriginal(st, l, bmp, made.toList())
                    onClose()
                }
            }
        }
    }
}

/** Creates one layer per polygon. The new layers sit exactly over the source so the picture is unchanged until you move a part. */
private fun cutParts(st: EditorState, src: Layer, bmp: android.graphics.Bitmap, regions: List<Pair<String, FloatArray>>, humanoid: Boolean) {
    val factor = bmp.width.toFloat() / src.imgW
    val local = RigTools.layerLocalMatrix(src)
    var n = 0
    st.edit {
        for ((name, poly) in regions) {
            val cut = PartCutter.cut(bmp, poly) ?: continue
            val file = st.repo.saveBitmap(st.project.id, cut.first, name.ifBlank { "part" })
            if (!st.project.assets.contains(file)) st.project.assets.add(file)
            val l = Layer(newId(), name.ifBlank { "Part ${n + 1}" })
            l.image = file; l.imgW = cut.first.width; l.imgH = cut.first.height
            l.sx = src.sx / factor; l.sy = src.sy / factor; l.rot = src.rot; l.skx = src.skx; l.sky = src.sky
            l.charId = src.charId; l.boneId = src.boneId; l.depth = src.depth; l.blend = src.blend; l.opacity = src.opacity
            // centre of the cut in source image px (relative to the source pivot), mapped into the parent space
            val cx = (cut.second.x + cut.first.width / 2f) / factor - src.px * src.imgW
            val cy = (cut.second.y + cut.first.height / 2f) / factor - src.py * src.imgH
            val pt = floatArrayOf(cx, cy); local.mapPoints(pt)
            l.x = pt[0]; l.y = pt[1]
            val nl = name.lowercase()
            if (nl.contains("eye")) { l.role = "eye"; l.side = if (nl.contains("left")) "L" else "R" }
            if (nl.contains("mouth")) l.role = "mouth"
            val at = st.scene.layers.indexOf(src)
            st.scene.layers.add(at + 1 + n, l); n++
        }
    }
    st.toast("Cut $n part(s). Name matching lets “Auto-rig” build a rig from them.")
}

private fun eraseOriginal(st: EditorState, src: Layer, bmp: android.graphics.Bitmap, polys: List<FloatArray>) {
    val out = PartCutter.erase(bmp, polys)
    val file = st.repo.saveBitmap(st.project.id, out, src.name + "_body")
    val factor = bmp.width.toFloat() / src.imgW
    st.edit {
        if (!st.project.assets.contains(file)) st.project.assets.add(file)
        src.image = file
        // keep layer geometry: new bitmap has the (possibly downscaled) size of the decoded source
        src.sx /= factor; src.sy /= factor; src.imgW = out.width; src.imgH = out.height
        src.name = src.name + " (body)"
    }
    st.cache.assetDir = st.assetsDir
}
