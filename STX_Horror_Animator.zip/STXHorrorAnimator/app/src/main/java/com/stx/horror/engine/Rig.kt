package com.stx.horror.engine

import android.graphics.Matrix
import com.stx.horror.model.*
import kotlin.math.*

class BonePose(var x: Float, var y: Float, var rot: Float)

class CharPose {
    val bones = HashMap<String, BonePose>()            // world transform in character space, by bone id
    val delta = HashMap<String, FloatArray>()          // animated delta (rot, dx, dy) by bone id
    val syRole = HashMap<String, Float>()
    var eye = 0f; var brow = 0f; var mouth = 0f; var lookx = 0f; var looky = 0f
    var charDx = 0f
    var x = 0f; var y = 0f; var rot = 0f; var sx = 1f; var sy = 1f; var opacity = 1f
    val matrix = Matrix()
    fun boneMatrix(id: String, out: Matrix): Boolean {
        val b = bones[id] ?: return false
        out.reset(); out.postRotate(b.rot); out.postTranslate(b.x, b.y); return true
    }
}

object RigSolver {
    @Volatile var restMode = false      // editor: show the un-animated rest pose while rigging
    private fun v(sc: Scene, target: String, prop: String, t: Float): Float? = Anim.eval(sc.track(target, prop), t)

    fun orderBones(list: List<Bone>): List<Bone> {
        val byId = list.associateBy { it.id }
        val done = HashSet<String>(); val out = ArrayList<Bone>(list.size)
        fun visit(b: Bone, depth: Int) {
            if (b.id in done || depth > 64) return
            val p = byId[b.parent]; if (p != null) visit(p, depth + 1)
            if (done.add(b.id)) out.add(b)
        }
        list.forEach { visit(it, 0) }
        return out
    }

    fun presetsAt(sc: Scene, ch: Character, t: Float): PresetOut {
        val out = PresetOut()
        for (c in sc.clips) {
            if (c.charId != ch.id) continue
            val rel = t - c.start
            if (rel < 0f) continue
            val sp = max(0.01f, c.speed)
            if (rel > c.duration) {             // finished: keep travel distance only
                val tmp = PresetOut(); Presets.eval(c, c.duration * sp, 1f, tmp); out.charDx += tmp.charDx; continue
            }
            val envelopeKind = c.preset == "Waving" || c.preset == "Pointing" || c.preset == "Fear Reaction"
            var lt = rel * sp
            var dur = c.duration * sp
            if (c.loop && envelopeKind) {
                val cyc = c.params["cycle"] ?: Presets.defaultDuration(c.preset)
                lt %= cyc; dur = cyc
            }
            val fade = max(0.001f, c.fade)
            val env = Anim.clamp01(min(rel / fade, (c.duration - rel) / fade)).let { Anim.smooth(it) }
            // envelope-based presets receive their own duration through the clip copy
            if (envelopeKind) {
                val cc = ProcClip(c.id, c.charId, c.preset).also { it.params = c.params; it.weight = c.weight; it.duration = dur }
                Presets.eval(cc, lt, 1f, out)   // preset applies its own envelope
                out.charDx += 0f
            } else Presets.eval(c, lt, env, out)
        }
        return out
    }

    fun charRootX(sc: Scene, ch: Character, t: Float): Float =
        (v(sc, ch.id, "x", t) ?: ch.x) + presetsAt(sc, ch, t).charDx * (if (ch.sx < 0f) -1f else 1f)

    fun solve(sc: Scene, ch: Character, t: Float, wind: Float): CharPose {
        val cp = CharPose()
        val po = if (restMode) PresetOut() else presetsAt(sc, ch, t)
        cp.charDx = po.charDx
        cp.eye = v(sc, ch.id, "eye", t) ?: po.eye ?: 0f
        cp.brow = v(sc, ch.id, "brow", t) ?: po.brow ?: 0f
        cp.mouth = v(sc, ch.id, "mouth", t) ?: po.mouth ?: 0f
        cp.lookx = (v(sc, ch.id, "lookx", t) ?: po.lookx ?: 0f).coerceIn(-1.2f, 1.2f)
        cp.looky = (v(sc, ch.id, "looky", t) ?: po.looky ?: 0f).coerceIn(-1.2f, 1.2f)
        cp.x = v(sc, ch.id, "x", t) ?: ch.x; cp.y = v(sc, ch.id, "y", t) ?: ch.y
        cp.rot = v(sc, ch.id, "rot", t) ?: ch.rot
        cp.sx = v(sc, ch.id, "sx", t) ?: ch.sx; cp.sy = v(sc, ch.id, "sy", t) ?: ch.sy
        cp.opacity = v(sc, ch.id, "opacity", t) ?: ch.opacity
        cp.syRole.putAll(po.sy)
        // character matrix: translate, rotate, scale, then procedural travel along the facing direction
        cp.matrix.reset()
        cp.matrix.postTranslate(cp.charDx, 0f)
        cp.matrix.postScale(cp.sx, cp.sy)
        cp.matrix.postRotate(cp.rot)
        cp.matrix.postTranslate(cp.x, cp.y)

        val bones = orderBones(sc.bonesOf(ch.id))
        if (bones.isEmpty()) return cp
        val n = bones.size
        val lrot = FloatArray(n); val lx = FloatArray(n); val ly = FloatArray(n)
        val index = HashMap<String, Int>()
        bones.forEachIndexed { i, b -> index[b.id] = i }

        // ---- pass 1 : local values (rest + presets + keyframes + constraints + secondary motion)
        for (i in 0 until n) {
            val b = bones[i]
            var d = (po.rot[b.role] ?: 0f) + (if (restMode) 0f else (v(sc, b.id, "rot", t) ?: 0f))
            if (b.role == "head") d += cp.lookx * ch.lookTurn
            d = d.coerceIn(b.minRot, b.maxRot)
            if (!restMode && (b.windAmp > 0f || b.lagFollow > 0f)) d += secondary(sc, ch, b, bones, t, wind, i)
            val ddx = (po.dx[b.role] ?: 0f) + (if (restMode) 0f else (v(sc, b.id, "x", t) ?: 0f))
            val ddy = (po.dy[b.role] ?: 0f) + (if (restMode) 0f else (v(sc, b.id, "y", t) ?: 0f))
            lrot[i] = b.rot + d; lx[i] = b.x + ddx; ly[i] = b.y + ddy
            cp.delta[b.id] = floatArrayOf(d, ddx, ddy)
        }
        // ---- pass 2 : forward kinematics
        val wx = FloatArray(n); val wy = FloatArray(n); val wr = FloatArray(n)
        fun fk() {
            for (i in 0 until n) {
                val pi = index[bones[i].parent]
                if (pi == null) { wx[i] = lx[i]; wy[i] = ly[i]; wr[i] = lrot[i] }
                else {
                    val rad = Math.toRadians(wr[pi].toDouble()); val c = cos(rad).toFloat(); val s = sin(rad).toFloat()
                    wx[i] = wx[pi] + lx[i] * c - ly[i] * s; wy[i] = wy[pi] + lx[i] * s + ly[i] * c; wr[i] = wr[pi] + lrot[i]
                }
            }
        }
        fk()
        // ---- pass 3 : inverse kinematics for bones with IK targets (CCD with joint constraints)
        var anyIk = false
        for (i in 0 until n) {
            val b = bones[i]
            if (b.ikLen <= 0) continue
            val tx = v(sc, b.id, "ikx", t); val ty = v(sc, b.id, "iky", t)
            if (restMode || tx == null || ty == null) continue
            val weight = (v(sc, b.id, "ikw", t) ?: 1f).coerceIn(0f, 1f)
            if (weight <= 0.001f) continue
            solveCcd(bones, index, i, b.ikLen, tx, ty, weight, lrot, lx, ly, wx, wy, wr)
            anyIk = true
        }
        if (anyIk) fk()
        for (i in 0 until n) cp.bones[bones[i].id] = BonePose(wx[i], wy[i], wr[i])
        return cp
    }

    private fun secondary(sc: Scene, ch: Character, b: Bone, bones: List<Bone>, t: Float, wind: Float, idx: Int): Float {
        var r = 0f
        val ph = idx * 0.75f + Anim.hash(b.id.hashCode()) * 3f
        if (b.windAmp > 0f) {
            val f = b.windFreq * (1f + abs(wind) * 1.5f)
            r += b.windAmp * (0.65f * sin(TWO_PI * f * t + ph) + 0.35f * Anim.noise(t * f * 1.7f + ph, 7))
            r += -wind * b.windAmp * 1.4f
        }
        if (b.lagFollow > 0f) {
            val dly = b.lagDelay
            val a0 = ancestorDelta(sc, ch, b, bones, t); val a1 = ancestorDelta(sc, ch, b, bones, t - dly)
            r += b.lagFollow * (a1 - a0)
            val drag = charRootX(sc, ch, t - dly) - charRootX(sc, ch, t)
            r += -drag * 0.18f * b.lagFollow * (if (ch.sx < 0f) -1f else 1f)
        }
        return r
    }
    private val TWO_PI = (2.0 * PI).toFloat()

    private fun ancestorDelta(sc: Scene, ch: Character, b: Bone, bones: List<Bone>, t: Float): Float {
        if (t < 0f) return ancestorDelta(sc, ch, b, bones, 0f)
        val po = presetsAt(sc, ch, t)
        var sum = 0f; var cur = bones.firstOrNull { it.id == b.parent }; var guard = 0
        while (cur != null && guard++ < 32) {
            sum += (po.rot[cur.role] ?: 0f) + (v(sc, cur.id, "rot", t) ?: 0f)
            if (cur.role == "head") sum += (v(sc, ch.id, "lookx", t) ?: po.lookx ?: 0f) * ch.lookTurn
            cur = bones.firstOrNull { it.id == cur!!.parent }
        }
        return sum
    }

    private fun solveCcd(
        bones: List<Bone>, index: Map<String, Int>, tip: Int, len: Int, tx: Float, ty: Float, weight: Float,
        lrot: FloatArray, lx: FloatArray, ly: FloatArray, wx: FloatArray, wy: FloatArray, wr: FloatArray
    ) {
        val chain = ArrayList<Int>()
        var cur: Int? = tip
        while (cur != null && chain.size < len) { chain.add(cur); cur = index[bones[cur].parent] }
        chain.reverse()                              // root of chain first
        val fkRot = FloatArray(chain.size) { lrot[chain[it]] }
        val m = chain.size
        val ox = FloatArray(m); val oy = FloatArray(m); val orr = FloatArray(m)
        fun chainFk() {
            for (k in 0 until m) {
                val i = chain[k]
                if (k == 0) {
                    val pi = index[bones[i].parent]
                    if (pi == null) { ox[0] = lx[i]; oy[0] = ly[i]; orr[0] = lrot[i] }
                    else {
                        val rad = Math.toRadians(wr[pi].toDouble()); val c = cos(rad).toFloat(); val s = sin(rad).toFloat()
                        ox[0] = wx[pi] + lx[i] * c - ly[i] * s; oy[0] = wy[pi] + lx[i] * s + ly[i] * c; orr[0] = wr[pi] + lrot[i]
                    }
                } else {
                    val rad = Math.toRadians(orr[k - 1].toDouble()); val c = cos(rad).toFloat(); val s = sin(rad).toFloat()
                    ox[k] = ox[k - 1] + lx[i] * c - ly[i] * s; oy[k] = oy[k - 1] + lx[i] * s + ly[i] * c; orr[k] = orr[k - 1] + lrot[i]
                }
            }
        }
        chainFk()
        for (iter in 0 until 14) {
            for (k in m - 1 downTo 0) {
                val tb = bones[chain[m - 1]]
                val er = Math.toRadians(orr[m - 1].toDouble())
                val ex = ox[m - 1] + cos(er).toFloat() * tb.length; val ey = oy[m - 1] + sin(er).toFloat() * tb.length
                val a1 = atan2(ey - oy[k], ex - ox[k]); val a2 = atan2(ty - oy[k], tx - ox[k])
                var d = Math.toDegrees((a2 - a1).toDouble()).toFloat()
                while (d > 180f) d -= 360f; while (d < -180f) d += 360f
                val b = bones[chain[k]]
                val newRot = lrot[chain[k]] + d
                lrot[chain[k]] = newRot.coerceIn(b.rot + b.minRot, b.rot + b.maxRot)
                chainFk()
            }
            val tb = bones[chain[m - 1]]; val er = Math.toRadians(orr[m - 1].toDouble())
            val ex = ox[m - 1] + cos(er).toFloat() * tb.length; val ey = oy[m - 1] + sin(er).toFloat() * tb.length
            if (hypot(ex - tx, ey - ty) < 0.5f) break
        }
        for (k in 0 until m) lrot[chain[k]] = Anim.lerp(fkRot[k], lrot[chain[k]], weight)
    }
}

// ------------------------------------------------------------------------------------------
class Pose(var name: String) {
    val rot = linkedMapOf<String, Float>()   // by bone role/name key
    val dx = linkedMapOf<String, Float>()
    val dy = linkedMapOf<String, Float>()
    fun toJson() = JSONObjectHelper.pose(this)
}

object JSONObjectHelper {
    fun pose(p: Pose): org.json.JSONObject {
        val o = org.json.JSONObject().put("name", p.name)
        val a = org.json.JSONArray()
        for (k in p.rot.keys) a.put(org.json.JSONObject().put("k", k).putF("r", p.rot[k] ?: 0f).putF("x", p.dx[k] ?: 0f).putF("y", p.dy[k] ?: 0f))
        return o.put("bones", a)
    }
    fun poseFrom(o: org.json.JSONObject): Pose {
        val p = Pose(o.s("name", "Pose"))
        o.optJSONArray("bones")?.objects()?.forEach { b -> val k = b.s("k"); p.rot[k] = b.f("r"); p.dx[k] = b.f("x"); p.dy[k] = b.f("y") }
        return p
    }
}

object RigTools {
    private val sideRegex = Regex("^(arm|leg|hand|foot)([LR])(\\d?)$")

    fun counterpartRole(role: String): String? {
        val m = sideRegex.matchEntire(role) ?: return null
        val side = if (m.groupValues[2] == "L") "R" else "L"
        return m.groupValues[1] + side + m.groupValues[3]
    }
    fun boneKey(b: Bone) = if (b.role.isNotEmpty()) b.role else b.name

    // ---------------------------------------------------------------- humanoid template
    fun createHumanoid(sc: Scene, ch: Character, sideView: Boolean): List<Bone> {
        val made = ArrayList<Bone>()
        fun add(name: String, role: String, parent: Bone?, x: Float, y: Float, rot: Float, len: Float,
                minR: Float = -180f, maxR: Float = 180f): Bone {
            val b = Bone(newId(), name, parent?.id ?: "", ch.id)
            b.role = role; b.x = x; b.y = y; b.rot = rot; b.length = len; b.minRot = minR; b.maxRot = maxR
            sc.bones.add(b); made.add(b); return b
        }
        val hip = add("Hip", "hip", null, 0f, 0f, 0f, 0f)
        val spine = add("Torso", "spine", hip, 0f, 0f, -90f, 130f, -50f, 50f)
        val neck = add("Neck", "neck", spine, 130f, 0f, 0f, 22f, -40f, 40f)
        val head = add("Head", "head", neck, 22f, 0f, 0f, 105f, -50f, 50f)
        val sy = if (sideView) 0f else 40f
        val hx = if (sideView) 0f else 22f
        for (side in listOf("L", "R")) {
            val sg = if (side == "L") -1f else 1f
            val full = if (side == "L") "Left" else "Right"
            val a1 = add("$full Upper Arm", "arm${side}1", spine, 112f, sg * sy, 180f, 95f, -170f, 170f)
            val a2 = add("$full Forearm", "arm${side}2", a1, 95f, 0f, 0f, 88f, -150f, 8f)
            add("$full Hand", "hand$side", a2, 88f, 0f, 0f, 38f, -60f, 60f)
            val l1 = add("$full Thigh", "leg${side}1", hip, sg * hx, 0f, 90f, 125f, -90f, 90f)
            val l2 = add("$full Lower Leg", "leg${side}2", l1, 125f, 0f, 0f, 120f, -4f, 150f)
            add("$full Foot", "foot$side", l2, 120f, 0f, -90f, 55f, -50f, 50f)
            a2.ikSign = -1; l2.ikSign = 1
        }
        // secondary motion chains
        var prev: Bone? = head
        for (i in 0 until 3) {
            val b = add("Hair ${i + 1}", "hair", prev, if (i == 0) 70f else 45f, if (i == 0) -28f else 0f, if (i == 0) 190f else 0f, 45f)
            b.windAmp = 6f; b.windFreq = 0.55f + i * 0.1f; b.lagFollow = 0.8f; prev = b
        }
        prev = neck
        for (i in 0 until 4) {
            val b = add("Scarf ${i + 1}", "scarf", prev, if (i == 0) 10f else 38f, if (i == 0) -6f else 0f, if (i == 0) -105f else 0f, 38f)
            b.windAmp = 9f; b.windFreq = 0.5f + i * 0.08f; b.lagFollow = 1.0f; b.lagDelay = 0.14f + 0.02f * i; prev = b
        }
        prev = hip
        for (i in 0 until 2) {
            val b = add("Coat ${i + 1}", "coat", prev, if (i == 0) 0f else 70f, if (i == 0) 10f else 0f, if (i == 0) 90f else 0f, 70f)
            b.windAmp = 4f; b.windFreq = 0.45f; b.lagFollow = 0.6f; prev = b
        }
        return made
    }

    // ---------------------------------------------------------------- mirror L -> R (or R -> L)
    fun mirrorRig(sc: Scene, charId: String, from: String, includeLayers: Boolean): Int {
        val bones = RigSolver.orderBones(sc.bonesOf(charId))
        val world = HashMap<String, FloatArray>()      // id -> x,y,rot (character space, rest pose)
        for (b in bones) {
            val p = world[b.parent]
            if (p == null) world[b.id] = floatArrayOf(b.x, b.y, b.rot)
            else {
                val rad = Math.toRadians(p[2].toDouble()); val c = cos(rad).toFloat(); val s = sin(rad).toFloat()
                world[b.id] = floatArrayOf(p[0] + b.x * c - b.y * s, p[1] + b.x * s + b.y * c, p[2] + b.rot)
            }
        }
        var changed = 0
        val newWorld = HashMap<String, FloatArray>(world)
        for (b in bones) {
            val role = b.role
            val m = sideRegex.matchEntire(role) ?: continue
            if (m.groupValues[2] != from) continue
            val cr = counterpartRole(role) ?: continue
            val target = bones.firstOrNull { it.role == cr } ?: continue
            val w = world[b.id]!!
            newWorld[target.id] = floatArrayOf(-w[0], w[1], 180f - w[2])
            // update local values from new world given (possibly updated) parent
            val par = newWorld[target.parent]
            if (par == null) { target.x = -w[0]; target.y = w[1]; target.rot = 180f - w[2] }
            else {
                val rad = Math.toRadians(par[2].toDouble()); val c = cos(rad).toFloat(); val s = sin(rad).toFloat()
                val dxw = -w[0] - par[0]; val dyw = w[1] - par[1]
                target.x = dxw * c + dyw * s; target.y = -dxw * s + dyw * c
                target.rot = 180f - w[2] - par[2]
            }
            while (target.rot > 180f) target.rot -= 360f; while (target.rot < -180f) target.rot += 360f
            target.length = b.length
            target.minRot = -b.maxRot; target.maxRot = -b.minRot; target.ikSign = -b.ikSign
            changed++
            if (includeLayers) {
                for (l in sc.layers.filter { it.boneId == b.id }) {
                    val existing = sc.layers.firstOrNull { it.boneId == target.id && it.name == l.name.replace(Regex("(?i)left"), "Right") }
                    val nl = existing ?: l.copyOf()
                    nl.name = if (existing != null) nl.name else l.name.replace(Regex("(?i)left"), "Right").let { if (it == l.name) "${l.name} (mirror)" else it }
                    nl.boneId = target.id; nl.x = l.x; nl.y = -l.y; nl.rot = -l.rot; nl.sy = -l.sy; nl.sx = l.sx
                    nl.px = l.px; nl.py = l.py
                    if (existing == null) { val at = sc.layers.indexOf(l); sc.layers.add(minOf(sc.layers.size, at + 1), nl) }
                }
            }
        }
        return changed
    }

    // ---------------------------------------------------------------- poses
    fun capturePose(sc: Scene, ch: Character, t: Float, name: String): Pose {
        val cp = RigSolver.solve(sc, ch, t, sc.wind)
        val p = Pose(name)
        for (b in sc.bonesOf(ch.id)) {
            val d = cp.delta[b.id] ?: continue
            val k = boneKey(b)
            p.rot[k] = (p.rot[k] ?: 0f) + d[0]; p.dx[k] = (p.dx[k] ?: 0f) + d[1]; p.dy[k] = (p.dy[k] ?: 0f) + d[2]
        }
        return p
    }
    fun applyPose(sc: Scene, ch: Character, pose: Pose, t: Float, mirror: Boolean) {
        for (b in sc.bonesOf(ch.id)) {
            val key = boneKey(b)
            var src = key
            if (mirror) src = counterpartRole(b.role) ?: key
            val r = pose.rot[src] ?: continue
            val sign = if (mirror) -1f else 1f
            Anim.setKey(sc.trackOrCreate(b.id, "rot"), t, r * sign, Ease.EASE_IN_OUT)
            val dx = pose.dx[src] ?: 0f; val dy = pose.dy[src] ?: 0f
            if (abs(dx) > 0.01f || abs(dy) > 0.01f || sc.track(b.id, "x") != null) {
                Anim.setKey(sc.trackOrCreate(b.id, "x"), t, dx, Ease.EASE_IN_OUT)
                Anim.setKey(sc.trackOrCreate(b.id, "y"), t, dy * sign * (if (mirror) -1f else 1f), Ease.EASE_IN_OUT)
            }
        }
    }

    /** Bake the procedural clips of a character into editable bone keyframes. */
    fun bakeProcedural(sc: Scene, ch: Character, t0: Float, t1: Float, fps: Int): Int {
        var count = 0
        val step = 1f / fps
        val bones = sc.bonesOf(ch.id)
        var t = t0
        while (t <= t1 + 1e-4f) {
            val cp = RigSolver.solve(sc, ch, t, sc.wind)
            for (b in bones) {
                val d = cp.delta[b.id] ?: continue
                Anim.setKey(sc.trackOrCreate(b.id, "rot"), t, d[0], Ease.LINEAR)
                if (abs(d[1]) > 0.001f || abs(d[2]) > 0.001f) {
                    Anim.setKey(sc.trackOrCreate(b.id, "x"), t, d[1], Ease.LINEAR); Anim.setKey(sc.trackOrCreate(b.id, "y"), t, d[2], Ease.LINEAR)
                }
                count++
            }
            Anim.setKey(sc.trackOrCreate(ch.id, "eye"), t, cp.eye, Ease.LINEAR)
            Anim.setKey(sc.trackOrCreate(ch.id, "mouth"), t, cp.mouth, Ease.HOLD)
            t += step
        }
        sc.clips.removeAll { it.charId == ch.id && it.start >= t0 - 1e-3f && it.start + it.duration <= t1 + 1e-3f }
        return count
    }

    // ---------------------------------------------------------------- attach / pivot / layer transforms
    fun layerLocalMatrix(l: Layer, out: Matrix = Matrix()): Matrix {
        out.reset()
        out.postScale(l.sx, l.sy); out.postSkew(tan(Math.toRadians(l.skx.toDouble())).toFloat(), tan(Math.toRadians(l.sky.toDouble())).toFloat())
        out.postRotate(l.rot); out.postTranslate(l.x, l.y)
        return out
    }

    /** Rest-pose world matrix (scene space) of a bone including the character transform at its base values. */
    fun boneRestMatrix(sc: Scene, bone: Bone): Matrix {
        val ch = sc.character(bone.charId) ?: Character()
        val bones = RigSolver.orderBones(sc.bonesOf(bone.charId))
        val world = HashMap<String, FloatArray>()
        for (b in bones) {
            val p = world[b.parent]
            world[b.id] = if (p == null) floatArrayOf(b.x, b.y, b.rot) else {
                val rad = Math.toRadians(p[2].toDouble()); val c = cos(rad).toFloat(); val s = sin(rad).toFloat()
                floatArrayOf(p[0] + b.x * c - b.y * s, p[1] + b.x * s + b.y * c, p[2] + b.rot)
            }
        }
        val w = world[bone.id] ?: floatArrayOf(0f, 0f, 0f)
        val m = Matrix(); m.postRotate(w[2]); m.postTranslate(w[0], w[1])
        val cm = Matrix(); cm.postScale(ch.sx, ch.sy); cm.postRotate(ch.rot); cm.postTranslate(ch.x, ch.y)
        m.postConcat(cm)
        return m
    }

    /** Scene-space matrix of a layer at its base values (not animated). */
    fun layerWorldMatrix(sc: Scene, l: Layer): Matrix {
        val m = layerLocalMatrix(l)
        val bone = sc.bone(l.boneId)
        if (bone != null) m.postConcat(boneRestMatrix(sc, bone))
        else sc.character(l.charId)?.let { c -> val cm = Matrix(); cm.postScale(c.sx, c.sy); cm.postRotate(c.rot); cm.postTranslate(c.x, c.y); m.postConcat(cm) }
        return m
    }

    /** Attach a layer to a bone keeping its current appearance in the rest pose. */
    fun attachLayer(sc: Scene, l: Layer, bone: Bone?) {
        val world = layerWorldMatrix(sc, l)
        val pivot = floatArrayOf(l.px * l.imgW, l.py * l.imgH)
        // transform of pivot point and the x-axis direction to world
        val pw = floatArrayOf(pivot[0] - pivot[0], 0f)           // pivot is local origin => (0,0)
        val org = floatArrayOf(0f, 0f); world.mapPoints(org)
        val ax = floatArrayOf(1f, 0f); world.mapVectors(ax)
        val worldRot = Math.toDegrees(atan2(ax[1].toDouble(), ax[0].toDouble())).toFloat()
        if (bone == null) {
            l.boneId = ""; l.charId = bone?.charId ?: ""
            l.x = org[0]; l.y = org[1]; l.rot = worldRot
            return
        }
        val inv = Matrix()
        boneRestMatrix(sc, bone).invert(inv)
        val lp = floatArrayOf(org[0], org[1]); inv.mapPoints(lp)
        val bx = floatArrayOf(1f, 0f); boneRestMatrix(sc, bone).mapVectors(bx)
        val boneRot = Math.toDegrees(atan2(bx[1].toDouble(), bx[0].toDouble())).toFloat()
        l.boneId = bone.id; l.charId = bone.charId
        l.x = lp[0]; l.y = lp[1]; l.rot = worldRot - boneRot
        while (l.rot > 180f) l.rot -= 360f; while (l.rot < -180f) l.rot += 360f
    }

    /** Move the pivot inside the image while keeping the layer visually in place. */
    fun setPivot(l: Layer, npx: Float, npy: Float) {
        val dx = (npx - l.px) * l.imgW; val dy = (npy - l.py) * l.imgH
        val m = Matrix(); m.postScale(l.sx, l.sy); m.postSkew(tan(Math.toRadians(l.skx.toDouble())).toFloat(), tan(Math.toRadians(l.sky.toDouble())).toFloat()); m.postRotate(l.rot)
        val v = floatArrayOf(dx, dy); m.mapVectors(v)
        l.x += v[0]; l.y += v[1]; l.px = npx; l.py = npy
    }

    // ---------------------------------------------------------------- auto rig from named parts
    class Match(val layer: Layer, val role: String)

    fun classify(name: String): Pair<String, String>? {      // -> (kind, side)
        val n = name.lowercase().replace(Regex("[^a-z0-9]+"), " ").trim()
        fun has(vararg w: String) = w.any { n.contains(it) }
        val padded = " $n "
        val side = when {
            has("left") || padded.contains(" l ") || n.endsWith(" l") -> "L"
            has("right") || padded.contains(" r ") || n.endsWith(" r") -> "R"
            else -> ""
        }
        val kind = when {
            has("eyebrow", "brow") -> "brow"
            has("eye") -> "eye"
            has("mouth", "lips", "lip") -> "mouth"
            has("hair") -> "hair"
            has("scarf") -> "scarf"
            has("coat", "cape", "cloak") -> "coat"
            has("neck") -> "neck"
            has("head", "face") -> "head"
            has("forearm", "lower arm", "elbow") -> "arm2"
            has("upper arm", "arm", "shoulder", "sleeve") -> "arm1"
            has("hand", "palm", "fist") -> "hand"
            has("shin", "calf", "lower leg") -> "leg2"
            has("thigh", "upper leg", "leg") -> "leg1"
            has("foot", "feet", "shoe", "boot") -> "foot"
            has("torso", "body", "chest", "spine", "trunk") -> "spine"
            else -> return null
        }
        return kind to side
    }

    /** Builds a humanoid rig fitted to the layers (by name) and attaches them. Returns the number of attached parts. */
    fun autoRigFromParts(sc: Scene, ch: Character, layers: List<Layer>, sideView: Boolean): Int {
        val items = layers.mapNotNull { l -> classify(l.name)?.let { Triple(l, it.first, it.second) } }
        if (items.isEmpty()) return 0
        // scene-space bbox of each layer (assumes upright, unrotated source parts)
        fun bbox(l: Layer): FloatArray {
            val w = l.imgW * abs(l.sx); val h = l.imgH * abs(l.sy)
            val left = l.x - l.px * w; val top = l.y - l.py * h
            return floatArrayOf(left, top, left + w, top + h)
        }
        sc.bones.removeAll { it.charId == ch.id }
        createHumanoid(sc, ch, sideView)
        val bones = sc.bonesOf(ch.id)
        fun roleOf(kind: String, side: String): String? = when (kind) {
            "spine", "neck", "head" -> kind
            "arm1" -> "arm${side.ifEmpty { "R" }}1"; "arm2" -> "arm${side.ifEmpty { "R" }}2"; "hand" -> "hand${side.ifEmpty { "R" }}"
            "leg1" -> "leg${side.ifEmpty { "R" }}1"; "leg2" -> "leg${side.ifEmpty { "R" }}2"; "foot" -> "foot${side.ifEmpty { "R" }}"
            else -> null
        }
        // fitted world data: role -> (x, y, rot, length) in SCENE space
        val fit = HashMap<String, FloatArray>()
        for ((l, kind, side) in items) {
            val role = roleOf(kind, side) ?: continue
            val b = bbox(l); val w = b[2] - b[0]; val h = b[3] - b[1]; val cx = (b[0] + b[2]) / 2f
            fit[role] = when (kind) {
                "head", "neck", "spine" -> floatArrayOf(cx, b[3], -90f, h)
                "foot" -> floatArrayOf(b[0] + w * 0.2f, b[1] + h * 0.3f, 0f, w * 0.8f)
                else -> floatArrayOf(cx, b[1] + h * 0.04f, 90f, h * 0.96f)
            }
        }
        // origin of the character = hip = bottom of torso (fallback: from head/legs)
        val hipPos: FloatArray = fit["spine"]?.let { floatArrayOf(it[0], it[1]) }
            ?: run {
                val bb = items.map { bbox(it.first) }
                floatArrayOf(bb.map { (it[0] + it[2]) / 2f }.average().toFloat(), (bb.minOf { it[1] } + bb.maxOf { it[3] }) / 2f)
            }
        ch.x = hipPos[0]; ch.y = hipPos[1]; ch.sx = 1f; ch.sy = 1f; ch.rot = 0f
        val world = HashMap<String, FloatArray>()   // bone id -> x,y,rot in character space
        for (b in RigSolver.orderBones(bones)) {
            val f = fit[b.role]
            val p = world[b.parent]
            if (f != null) {
                val wx = f[0] - ch.x; val wy = f[1] - ch.y
                if (p == null) { b.x = wx; b.y = wy; b.rot = f[2] }
                else {
                    val rad = Math.toRadians(p[2].toDouble()); val c = cos(rad).toFloat(); val s = sin(rad).toFloat()
                    val dx = wx - p[0]; val dy = wy - p[1]
                    b.x = dx * c + dy * s; b.y = -dx * s + dy * c; b.rot = f[2] - p[2]
                }
                b.length = f[3]
                while (b.rot > 180f) b.rot -= 360f; while (b.rot < -180f) b.rot += 360f
            }
            world[b.id] = if (p == null) floatArrayOf(b.x, b.y, b.rot) else {
                val rad = Math.toRadians(p[2].toDouble()); val c = cos(rad).toFloat(); val s = sin(rad).toFloat()
                floatArrayOf(p[0] + b.x * c - b.y * s, p[1] + b.x * s + b.y * c, p[2] + b.rot)
            }
        }
        // attach
        var attached = 0
        val head = bones.first { it.role == "head" }
        val usedSecondary = HashSet<String>()
        for ((l, kind, side) in items) {
            l.charId = ch.id
            when (kind) {
                "eye", "brow", "mouth" -> { l.role = kind; l.side = side; attachLayer(sc, l, head) }
                "hair" -> { l.swayAmt = max(l.swayAmt, 6f); attachLayer(sc, l, head); usedSecondary.add("hair") }
                "scarf" -> { l.swayAmt = max(l.swayAmt, 8f); attachLayer(sc, l, bones.first { it.role == "neck" }); usedSecondary.add("scarf") }
                "coat" -> { l.swayAmt = max(l.swayAmt, 5f); attachLayer(sc, l, bones.first { it.role == "spine" }); usedSecondary.add("coat") }
                else -> {
                    val role = roleOf(kind, side) ?: continue
                    val bone = bones.firstOrNull { it.role == role } ?: continue
                    val f = fit[role]!!
                    val bb = bbox(l)
                    val ox = f[0]; val oy = f[1]
                    // pivot at the joint
                    setPivot(l, ((ox - bb[0]) / (bb[2] - bb[0]).coerceAtLeast(1f)).coerceIn(0f, 1f), ((oy - bb[1]) / (bb[3] - bb[1]).coerceAtLeast(1f)).coerceIn(0f, 1f))
                    attachLayer(sc, l, bone)
                    l.role = ""
                }
            }
            attached++
        }
        // secondary chains are replaced by mesh sway where an image exists; remove unused ones for a clean rig
        sc.bones.removeAll { it.charId == ch.id && (it.role == "hair" || it.role == "scarf" || it.role == "coat") && (it.role in usedSecondary || true) }
        return attached
    }
}
