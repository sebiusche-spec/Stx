@file:OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
package com.stx.horror.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.clickable
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.stx.horror.engine.*
import com.stx.horror.model.*
import kotlin.math.*

@Composable
fun PropRow(st: EditorState, target: String, prop: String, label: String, min: Float, max: Float, fmt: String = "%.2f") {
    val v = st.getProp(target, prop)
    Sl(label, v, min, max, st.hasKeyAt(target, prop), { st.toggleKey(target, prop) }, fmt) { st.setProp(target, prop, it) }
}

@Composable
fun Flow(content: @Composable () -> Unit) { FlowRow(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(2.dp)) { content() } }

// ====================================================================================== ASSETS
@Composable
fun AssetsPanel(st: EditorState, openCutter: () -> Unit) {
    val sc = st.scene
    val img = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { st.importImages(it) }
    val bg = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { st.importImages(it, true) }
    val mime = arrayOf("image/png", "image/jpeg", "image/webp")
    Title("Import")
    Flow {
        Neon("＋ Images / parts (PNG JPG WEBP)") { img.launch(mime) }
        Neon("＋ Background", color = C.Violet) { bg.launch(mime) }
    }
    Text("Transparent PNG parts, full characters, props, vehicles, monsters, effects – all supported.", color = C.Muted, fontSize = 11.sp)
    Title("Layers (top = front)")
    sc.layers.reversed().forEach { l ->
        Row(Modifier.fillMaxWidth().clickable { st.selectLayer(l.id) }.padding(vertical = 1.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(if (l.visible) "👁" else "—", Modifier.clickable { st.edit { l.visible = !l.visible } }.padding(6.dp), fontSize = 14.sp)
            Text(if (l.locked) "🔒" else "🔓", Modifier.clickable { st.edit { l.locked = !l.locked } }.padding(6.dp), fontSize = 14.sp)
            Text(l.name + (if (l.boneId.isNotEmpty()) "  🦴" else "") + (if (l.role.isNotEmpty()) "  [${l.role}]" else ""), color = if (l.id == st.selLayer) C.Neon else C.Text, fontSize = 13.sp, modifier = Modifier.weight(1f), maxLines = 1)
            Text("d${l.depth.toInt()}", color = C.Muted, fontSize = 10.sp)
        }
    }
    val l = st.layer()
    if (l == null) { if (sc.layers.isEmpty()) Text("Import an image to start.", color = C.Muted, fontSize = 12.sp); return }
    Spacer(Modifier.height(6.dp))
    Glass(Modifier.fillMaxWidth()) {
        Title("Layer · ${l.name}")
        Flow {
            Neon("Duplicate") { st.duplicateLayer() }; Neon("▲") { st.moveLayerOrder(1) }; Neon("▼") { st.moveLayerOrder(-1) }
            Neon("Cut into parts…", color = C.Red) { openCutter() }; Neon("Delete", color = C.Red) { st.deleteLayer() }
        }
        PropRow(st, l.id, "opacity", "Opacity", 0f, 1f)
        PropRow(st, l.id, "x", "X", -500f, st.project.width + 500f, "%.0f"); PropRow(st, l.id, "y", "Y", -500f, st.project.height + 500f, "%.0f")
        PropRow(st, l.id, "rot", "Rotation", -360f, 360f, "%.1f")
        PropRow(st, l.id, "sx", "Scale X", -4f, 4f); PropRow(st, l.id, "sy", "Scale Y", -4f, 4f)
        PropRow(st, l.id, "skx", "Skew X", -45f, 45f, "%.1f"); PropRow(st, l.id, "sky", "Skew Y", -45f, 45f, "%.1f")
        PropRow(st, l.id, "px", "Pivot X", -0.5f, 1.5f); PropRow(st, l.id, "py", "Pivot Y", -0.5f, 1.5f)
        Label("Parallax depth (100 background · 50 character · 20 foreground)")
        Flow { listOf("Background" to 100f, "Midground" to 70f, "Character" to 50f, "Foreground" to 20f).forEach { (n, d) -> Tag(n, abs(l.depth - d) < 1f) { st.edit { l.depth = d } } } }
        Sl("Depth", l.depth, 8f, 200f, fmt = "%.0f") { v -> st.edit("depth-${l.id}") { l.depth = v } }
        Pick("Blend", Blend.values().toList(), l.blend, { it.label }) { b -> st.edit { l.blend = b } }
        Label("Crop")
        Sl("Left", l.cropL, 0f, 0.9f) { v -> st.edit("cl${l.id}") { l.cropL = min(v, l.cropR - 0.05f) } }
        Sl("Top", l.cropT, 0f, 0.9f) { v -> st.edit("ct${l.id}") { l.cropT = min(v, l.cropB - 0.05f) } }
        Sl("Right", l.cropR, 0.1f, 1f) { v -> st.edit("cr${l.id}") { l.cropR = max(v, l.cropL + 0.05f) } }
        Sl("Bottom", l.cropB, 0.1f, 1f) { v -> st.edit("cb${l.id}") { l.cropB = max(v, l.cropT + 0.05f) } }
        Flow {
            if (l.mask != null) Neon("Remove mask") { st.edit { l.mask = null } }
            Neon("Rect mask from crop") { st.edit { val w = l.imgW.toFloat(); val h = l.imgH.toFloat(); l.mask = floatArrayOf(l.cropL * w, l.cropT * h, l.cropR * w, l.cropT * h, l.cropR * w, l.cropB * h, l.cropL * w, l.cropB * h) } }
        }
        Title("Secondary motion (hair / cloth / scarf mesh sway)")
        Sl("Sway", l.swayAmt, 0f, 30f, fmt = "%.1f") { v -> st.edit("sway${l.id}") { l.swayAmt = v } }
        Sl("Speed", l.swaySpeed, 0.2f, 4f) { v -> st.edit("swsp${l.id}") { l.swaySpeed = v } }
        Toggle("Ghost (affected by ghost effects)", l.ghost) { v -> st.edit { l.ghost = v } }
        Title("Face role")
        Flow { listOf("", "eye", "brow", "mouth").forEach { r -> Tag(if (r.isEmpty()) "none" else r, l.role == r) { st.edit { l.role = r } } }
            listOf("", "L", "R").forEach { s -> Tag("side " + (if (s.isEmpty()) "-" else s), l.side == s, C.Violet) { st.edit { l.side = s } } } }
        if (l.role == "eye" || l.role == "mouth" || l.role == "brow") {
            Text("States: ${l.states.size} (eyes: open/half/closed · brows: 5 · mouth: closed/small/medium/wide/smile/fear). Without state images the face role is animated procedurally (blink squash / mouth shapes).", color = C.Muted, fontSize = 10.sp)
            val names = st.project.assets.filter { it != l.image }
            Pick("Add state image", names, null, { it }) { n -> st.addStateImage(l, n) }
            if (l.states.isNotEmpty()) Neon("Clear states", color = C.Red) { st.edit { l.states.clear() } }
        }
    }
    if (st.project.assets.isNotEmpty()) {
        Title("Project assets (tap to add again)")
        Flow { st.project.assets.filter { a -> a.substringAfterLast('.').lowercase() in listOf("png", "jpg", "jpeg", "webp") }.forEach { a -> Tag(a.take(18), false, C.Violet) { st.addAssetAgain(a) } } }
    }
}

// ====================================================================================== RIG
@Composable
fun RigPanel(st: EditorState) {
    val sc = st.scene
    Title("Character")
    Flow {
        sc.characters.forEach { c -> Tag(c.name, c.id == st.selChar) { st.selChar = c.id; st.selBone = "" } }
        Neon("＋ New", color = C.Green) { st.createCharacter("") }
    }
    val ch = st.character()
    if (ch == null) { Text("Create a character, then import its parts (head, torso, left arm …), assign them to the character and build a rig.", color = C.Muted, fontSize = 12.sp); return }
    Glass(Modifier.fillMaxWidth()) {
        Title("1 · Build the skeleton")
        Flow {
            Neon("Humanoid (front)") { st.addHumanoidRig(false) }
            Neon("Humanoid (side view)") { st.addHumanoidRig(true) }
            Neon("＋ Bone") { st.addBone() }
            Neon("Delete bone", color = C.Red) { st.deleteBone() }
        }
        Title("2 · Attach images")
        Flow {
            Neon("Assign selected layer to this character") { st.assignLayerToCharacter() }
            Neon("Auto-rig from named parts", color = C.Red) { st.autoRig(false) }
            Neon("Auto-rig (side view)", color = C.Red) { st.autoRig(true) }
        }
        Text("Auto-rig reads layer names (head, hair, eye, mouth, torso, left/right upper arm, forearm, hand, thigh, shin, foot, scarf, coat), fits the bones to the images and attaches them.", color = C.Muted, fontSize = 10.sp)
        val bones = RigSolver.orderBones(sc.bonesOf(ch.id))
        val l = st.layer()
        if (l != null) Flow {
            Pick("Attach '${l.name.take(10)}' to", bones, sc.bone(l.boneId), { it.name }) { b -> st.attachSelectedToBone(b.id) }
            Neon("Snap pivot to joint") { st.snapPivotToBone() }
            if (l.boneId.isNotEmpty()) Neon("Detach") { st.attachSelectedToBone("") }
        }
        Title("3 · Mirror & rest pose")
        Flow {
            Neon("Mirror left → right") { st.mirrorRig("L", true) }
            Neon("Mirror right → left") { st.mirrorRig("R", true) }
        }
        Text("Rig tab shows the rest pose. Tools on the stage: 🦴 rotate bone (drag the bone) · drag a joint dot to move it · ⌖ IK drag · ⊕ pivot.", color = C.Muted, fontSize = 10.sp)
    }
    Title("Bones")
    val ordered = RigSolver.orderBones(sc.bonesOf(ch.id))
    ordered.forEach { b ->
        var depth = 0; var p = sc.bone(b.parent); while (p != null && depth < 12) { depth++; p = sc.bone(p.parent) }
        Text("${"  ".repeat(depth)}${if (depth > 0) "└ " else ""}${b.name}${if (b.ikLen > 0) "  (IK ${b.ikLen})" else ""}", color = if (b.id == st.selBone) C.Amber else C.Text, fontSize = 12.sp,
            modifier = Modifier.fillMaxWidth().clickable { st.selBone = b.id; st.tool = if (st.tool == "move") "bone" else st.tool }.padding(vertical = 3.dp))
    }
    val b = st.bone()
    if (b != null) Glass(Modifier.fillMaxWidth()) {
        Title("Bone · ${b.name}")
        Flow { Pick("Parent", listOf<Bone?>(null) + ordered.filter { it.id != b.id }, sc.bone(b.parent), { it?.name ?: "(root)" }) { n -> st.reparentBone(n?.id ?: "") } }
        PropRow(st, b.id, "rot", if (st.rigMode) "Rest rot" else "Pose rot", -180f, 180f, "%.1f")
        PropRow(st, b.id, "x", "X", -300f, 300f, "%.1f"); PropRow(st, b.id, "y", "Y", -300f, 300f, "%.1f")
        Sl("Length", b.length, 5f, 300f, fmt = "%.0f") { v -> st.edit("len${b.id}") { b.length = v } }
        Label("Constraints (limit of animated rotation, degrees)")
        Sl("Min", b.minRot, -180f, 0f, fmt = "%.0f") { v -> st.edit("min${b.id}") { b.minRot = v } }
        Sl("Max", b.maxRot, 0f, 180f, fmt = "%.0f") { v -> st.edit("max${b.id}") { b.maxRot = v } }
        Label("Inverse kinematics – choose the chain length, then drag the bone tip with ⌖")
        Flow { listOf(0, 2, 3).forEach { n -> Tag(if (n == 0) "FK only" else "IK $n bones", b.ikLen == n, C.Violet) { st.edit { b.ikLen = n } } } }
        if (b.ikLen > 0) { PropRow(st, b.id, "ikw", "IK weight", 0f, 1f); Neon("Clear IK keys") { st.edit { listOf("ikx", "iky", "ikw").forEach { p -> sc.track(b.id, p)?.let { sc.removeTrack(it) } } } } }
        Label("Secondary motion (hair / scarf / coat bones)")
        Sl("Wind sway", b.windAmp, 0f, 30f, fmt = "%.1f") { v -> st.edit("wa${b.id}") { b.windAmp = v } }
        Sl("Sway freq", b.windFreq, 0.1f, 3f) { v -> st.edit("wf${b.id}") { b.windFreq = v } }
        Sl("Follow-thru", b.lagFollow, 0f, 2f) { v -> st.edit("lf${b.id}") { b.lagFollow = v } }
        Sl("Delay (s)", b.lagDelay, 0.02f, 0.6f) { v -> st.edit("ld${b.id}") { b.lagDelay = v } }
        Label("Role: ${b.role.ifEmpty { "(none)" }}  – presets drive bones by role (hip, spine, neck, head, armL1/2, handL, legL1/2, footL …)")
    }
    PoseLibrary(st)
}

@Composable
fun PoseLibrary(st: EditorState) {
    val ch = st.character() ?: return
    var poseName by remember { mutableStateOf("") }
    val items = remember(st.version) { st.repo.libraryList("pose") }
    Glass(Modifier.fillMaxWidth().padding(top = 6.dp)) {
        Title("Poses · copy / paste / library")
        Flow {
            Neon("Copy keys at playhead") { st.toast("Copied ${st.copyKeysAtTime()} keys") }
            Neon("Paste keys at playhead") { st.toast("Pasted ${st.pasteKeys()} keys") }
            Neon("Key pose now") { st.edit { st.scene.bonesOf(ch.id).forEach { b -> Anim.setKey(st.scene.trackOrCreate(b.id, "rot"), st.time, st.getProp(b.id, "rot"), Ease.EASE_IN_OUT) } } }
            Neon("Save pose to library", color = C.Green) { st.libSave("pose", poseName.ifBlank { "Pose ${items.size + 1}" }); st.toast("Pose saved") }
        }
        OutlinedTextField(poseName, { poseName = it }, label = { Text("Pose name", fontSize = 11.sp) }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Flow { items.forEach { it0 -> Tag(it0.name, false, C.Violet) { st.libLoad(it0) } } }
        Flow { Neon("Mirror last copied pose onto selection", color = C.Violet) {
            val pose = RigTools.capturePose(st.scene, ch, st.time, "tmp"); st.edit { RigTools.applyPose(st.scene, ch, pose, st.time, true) } } }
    }
}


// ====================================================================================== ANIMATE
@Composable
fun AnimatePanel(st: EditorState) {
    val sc = st.scene
    Title("Character")
    Flow {
        sc.characters.forEach { c -> Tag(c.name, c.id == st.selChar) { st.selChar = c.id } }
        Neon("＋ New", color = C.Green) { st.createCharacter("") }
    }
    val ch = st.character()
    if (ch != null) {
        Title("Procedural motion presets (add at playhead – all editable)")
        Flow { Presets.names.forEach { n -> Tag(n, false, C.Green) { st.addClip(n) } } }
        val clip = sc.clips.firstOrNull { it.id == st.selClip && it.charId == ch.id }
        if (clip != null) Glass(Modifier.fillMaxWidth()) {
            Title("${clip.preset} clip")
            Sl("Start", clip.start, 0f, sc.duration, fmt = "%.2f") { v -> st.edit("cs${clip.id}") { clip.start = v } }
            Sl("Duration", clip.duration, 0.3f, max(sc.duration, 2f), fmt = "%.2f") { v -> st.edit("cd${clip.id}") { clip.duration = v } }
            Sl("Speed", clip.speed, 0.2f, 3f) { v -> st.edit("cp${clip.id}") { clip.speed = v } }
            Sl("Weight", clip.weight, 0f, 1.5f) { v -> st.edit("cw${clip.id}") { clip.weight = v } }
            Sl("Fade", clip.fade, 0f, 1.5f) { v -> st.edit("cf${clip.id}") { clip.fade = v } }
            Toggle("Loop", clip.loop) { v -> st.edit { clip.loop = v } }
            Presets.defs(clip.preset).forEach { d ->
                Sl(d.label, clip.params[d.key] ?: d.def, d.min, d.max) { v -> st.edit("pp${clip.id}${d.key}") { clip.params[d.key] = v } }
            }
            Flow {
                Neon("Duplicate") { st.edit { val n = ProcClip.fromJson(clip.toJson()); n.id = newId(); n.start = clip.start + clip.duration; sc.clips.add(n); st.selClip = n.id } }
                Neon("Delete", color = C.Red) { st.edit { sc.clips.remove(clip); st.selClip = "" } }
            }
        }
        Flow {
            Neon("Bake presets to keyframes", color = C.Violet) { st.bakeSelectedChar() }
            Neon("Save animation to library", color = C.Green) { st.libSave("animation", "Anim ${sc.clips.size}"); st.toast("Saved to library") }
        }
        val anims = remember(st.version) { st.repo.libraryList("animation") }
        if (anims.isNotEmpty()) { Label("Library animations (apply at playhead)"); Flow { anims.forEach { a -> Tag(a.name, false, C.Violet) { st.libLoad(a) } } } }
    }
    Glass(Modifier.fillMaxWidth().padding(top = 6.dp)) {
        Title("Transform · ${if (st.autoKey) "AUTO-KEY ON" else "tap ◇ to keyframe"}")
        val l = st.layer(); val b = st.bone()
        if (l != null) {
            Label("Layer ${l.name}")
            PropRow(st, l.id, "x", "X", -500f, st.project.width + 500f, "%.0f"); PropRow(st, l.id, "y", "Y", -500f, st.project.height + 500f, "%.0f")
            PropRow(st, l.id, "rot", "Rotation", -360f, 360f, "%.1f"); PropRow(st, l.id, "sx", "Scale X", -4f, 4f); PropRow(st, l.id, "sy", "Scale Y", -4f, 4f)
            PropRow(st, l.id, "opacity", "Opacity", 0f, 1f); PropRow(st, l.id, "skx", "Skew X", -45f, 45f, "%.1f"); PropRow(st, l.id, "py", "Pivot Y", -0.5f, 1.5f)
        }
        if (ch != null) {
            Label("Character root ${ch.name}")
            PropRow(st, ch.id, "x", "X", -500f, st.project.width + 500f, "%.0f"); PropRow(st, ch.id, "y", "Y", -500f, st.project.height + 500f, "%.0f")
            PropRow(st, ch.id, "rot", "Rotation", -45f, 45f, "%.1f"); PropRow(st, ch.id, "sx", "Scale X (neg = flip)", -3f, 3f); PropRow(st, ch.id, "sy", "Scale Y", -3f, 3f)
            Flow { Neon("Face right") { st.edit { ch.sx = abs(ch.sx) } }; Neon("Face left") { st.edit { ch.sx = -abs(ch.sx) } } }
        }
        if (b != null) { Label("Bone ${b.name}"); PropRow(st, b.id, "rot", "Bone rot", -180f, 180f, "%.1f"); PropRow(st, b.id, "x", "Bone X", -100f, 100f, "%.1f"); PropRow(st, b.id, "y", "Bone Y", -100f, 100f, "%.1f") }
        if (l == null && ch == null) Text("Select a layer or a character.", color = C.Muted, fontSize = 12.sp)
    }
    KeyEditor(st)
    RangeTools(st)
}

@Composable
fun KeyEditor(st: EditorState) {
    val r = st.selKey ?: return
    val k = st.keyOf(r) ?: return
    Glass(Modifier.fillMaxWidth().padding(top = 6.dp)) {
        Title("Keyframe · ${r.prop} @ ${"%.2fs".format(r.t)}")
        Flow { Ease.values().forEach { e -> Tag(e.label, k.ease == e, C.Amber) { st.setKeyEase(r, e) } } }
        Sl("Value", k.v, k.v - 200f, k.v + 200f) { st.setKeyValue(r, it) }
        Sl("Time", r.t, 0f, st.scene.duration) { nt -> st.selKey = st.moveKey(r, nt) }
        if (k.ease == Ease.BEZIER) {
            Label("Custom easing curve (cubic-bezier)")
            Sl("x1", k.x1, 0f, 1f) { st.setKeyBezier(r, it, k.y1, k.x2, k.y2) }; Sl("y1", k.y1, -0.5f, 1.5f) { st.setKeyBezier(r, k.x1, it, k.x2, k.y2) }
            Sl("x2", k.x2, 0f, 1f) { st.setKeyBezier(r, k.x1, k.y1, it, k.y2) }; Sl("y2", k.y2, -0.5f, 1.5f) { st.setKeyBezier(r, k.x1, k.y1, k.x2, it) }
        }
        Flow {
            Neon("Copy key") { st.copySelectedKey(); st.toast("Key copied") }
            Neon("Paste at playhead") { st.pasteKeys() }
            Neon("Delete key", color = C.Red) { st.deleteKey(r) }
        }
    }
}

@Composable
fun RangeTools(st: EditorState) {
    var a by remember { mutableFloatStateOf(0f) }; var b by remember { mutableFloatStateOf(2f) }; var spd by remember { mutableFloatStateOf(2f) }
    Glass(Modifier.fillMaxWidth().padding(top = 6.dp)) {
        Title("Animation range tools (selected character / layer)")
        Sl("From", a, 0f, st.scene.duration, fmt = "%.2f") { a = it }
        Sl("To", b, 0f, st.scene.duration, fmt = "%.2f") { b = it }
        Sl("Speed ×", spd, 0.25f, 4f) { spd = it }
        Flow {
            Neon("Duplicate to playhead") { st.rangeOp("duplicate", min(a, b), max(a, b), st.time) }
            Neon("Loop ×3") { st.rangeOp("loop", min(a, b), max(a, b), 3f) }
            Neon("Reverse") { st.rangeOp("reverse", min(a, b), max(a, b), 0f) }
            Neon("Apply speed") { st.rangeOp("speed", min(a, b), max(a, b), spd) }
        }
    }
}

// ====================================================================================== FACE
@Composable
fun FacePanel(st: EditorState) {
    val ch = st.character()
    if (ch == null) { Text("Select a character first (Rig tab).", color = C.Muted); return }
    val cp = remember(st.time, st.version) { RigSolver.solve(st.scene, ch, st.time, st.scene.wind) }
    Title("Expressions (keyframe at playhead)")
    Flow { listOf("Neutral", "Angry", "Sad", "Fear", "Surprised", "Smile").forEach { Tag(it, false, C.Amber) { st.applyExpression(it) } } }
    Title("Eyes")
    Flow { listOf("Open", "Half", "Closed").forEachIndexed { i, n -> Tag(n, cp.eye.roundToInt() == i) { st.setFace("eye", i.toFloat()) } }; Neon("Blink (5 keys)", color = C.Green) { st.blinkKeys() } }
    Title("Eyebrows")
    Flow { listOf("Normal", "Angry", "Sad", "Fear", "Surprised").forEachIndexed { i, n -> Tag(n, cp.brow.roundToInt() == i) { st.setFace("brow", i.toFloat()) } } }
    Title("Mouth")
    Flow { listOf("Closed", "Small", "Medium", "Wide", "Smile", "Fear").forEachIndexed { i, n -> Tag(n, cp.mouth.roundToInt() == i) { st.setFace("mouth", i.toFloat()) } } }
    Title("Head look")
    PropRow(st, ch.id, "lookx", "Left ↔ Right", -1f, 1f); PropRow(st, ch.id, "looky", "Down ↔ Up", -1f, 1f)
    Flow {
        Neon("Left") { st.lookKey(-1f, 0f) }; Neon("Right") { st.lookKey(1f, 0f) }; Neon("Up") { st.lookKey(0f, 1f) }; Neon("Down") { st.lookKey(0f, -1f) }; Neon("Center") { st.lookKey(0f, 0f) }
    }
    Sl("Turn (deg)", ch.lookTurn, 0f, 40f, fmt = "%.0f") { v -> st.edit("lt") { ch.lookTurn = v } }
    Sl("Face shift", ch.lookRange, 0f, 40f, fmt = "%.0f") { v -> st.edit("lr") { ch.lookRange = v } }
    Title("Automatic animation")
    Flow {
        Neon("Auto blinking", color = C.Green) { st.addClip("Blinking") }; Neon("Talking (procedural)", color = C.Green) { st.addClip("Talking") }
        Neon("Nod") { st.addClip("Nodding") }; Neon("Head shake") { st.addClip("Head Shake") }; Neon("Fear") { st.addClip("Fear Reaction") }; Neon("Look around") { st.addClip("Looking Around") }
    }
    Text("For real voice-driven mouth animation import a voice file in the Audio tab and press “Generate lip-sync”.", color = C.Muted, fontSize = 10.sp)
    var nm by remember { mutableStateOf("") }
    val exps = remember(st.version) { st.repo.libraryList("expression") }
    Glass(Modifier.fillMaxWidth().padding(top = 6.dp)) {
        Title("Expression library")
        OutlinedTextField(nm, { nm = it }, label = { Text("Name", fontSize = 11.sp) }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Neon("Save current face", color = C.Green) { st.libSave("expression", nm.ifBlank { "Expression ${exps.size + 1}" }); st.toast("Saved") }
        Flow { exps.forEach { e -> Tag(e.name, false, C.Violet) { st.libLoad(e) } } }
    }
}
