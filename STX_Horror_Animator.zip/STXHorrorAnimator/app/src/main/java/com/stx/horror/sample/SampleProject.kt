package com.stx.horror.sample

import android.content.Context
import android.graphics.*
import com.stx.horror.audio.*
import com.stx.horror.data.ProjectRepo
import com.stx.horror.engine.*
import com.stx.horror.model.*
import java.io.File
import java.io.FileOutputStream
import kotlin.math.*

/**
 * Builds the demo project entirely from code: procedurally drawn character parts (separate PNGs), a rigged skeleton,
 * three scenes with walking, talking (voice-driven lip-sync), blinking, camera moves, parallax, rain, fog, lightning, lights and audio.
 * It proves that the engine animates a rig continuously – nothing here is a slideshow or a moved still image.
 */
object SampleProject {
    private val skin = 0xFFC9B8A6.toInt(); private val coat = 0xFF1E2430.toInt(); private val coatLight = 0xFF2C3544.toInt()
    private val pants = 0xFF14161C.toInt(); private val shoe = 0xFF0A0A0C.toInt(); private val hair = 0xFF0E0E12.toInt(); private val scarfC = 0xFFB3122B.toInt()

    private fun bmp(w: Int, h: Int, draw: (Canvas, Paint) -> Unit): Bitmap {
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val p = Paint(Paint.ANTI_ALIAS_FLAG); draw(Canvas(b), p); return b
    }
    private fun save(dir: File, name: String, b: Bitmap): String { FileOutputStream(File(dir, name)).use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }; return name }
    private fun fill(p: Paint, c: Int) { p.reset(); p.isAntiAlias = true; p.style = Paint.Style.FILL; p.color = c }

    // ------------------------------------------------------------------ artwork
    private fun art(dir: File): Map<String, String> {
        val m = LinkedHashMap<String, String>()
        m["sky"] = save(dir, "bg_sky.png", bmp(1920, 1080) { c, p ->
            p.shader = LinearGradient(0f, 0f, 0f, 1080f, intArrayOf(0xFF03040A.toInt(), 0xFF0E1522.toInt(), 0xFF202C3C.toInt()), floatArrayOf(0f, .6f, 1f), Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, 1920f, 1080f, p); p.shader = null
            p.shader = RadialGradient(1500f, 170f, 260f, intArrayOf(0x55CFE0FF, 0x00CFE0FF), null, Shader.TileMode.CLAMP); c.drawCircle(1500f, 170f, 260f, p); p.shader = null
            fill(p, 0xFFE8EEF8.toInt()); c.drawCircle(1500f, 170f, 64f, p)
            fill(p, 0xFFB9C6DA.toInt()); c.drawCircle(1480f, 155f, 12f, p); c.drawCircle(1522f, 190f, 16f, p)
            for (i in 0 until 90) { fill(p, Color.argb(60 + (Anim.hash(i) * 160).toInt(), 255, 255, 255)); c.drawCircle(Anim.hash(i * 3 + 1) * 1920f, Anim.hash(i * 3 + 2) * 560f, 1f + Anim.hash(i * 5) * 1.8f, p) }
        })
        m["mansion"] = save(dir, "bg_mansion.png", bmp(1920, 760) { c, p ->
            fill(p, 0xFF08090F.toInt())
            c.drawRect(520f, 250f, 1560f, 760f, p); c.drawRect(400f, 380f, 560f, 760f, p); c.drawRect(1500f, 340f, 1700f, 760f, p)
            val roof = Path(); roof.moveTo(500f, 250f); roof.lineTo(1040f, 70f); roof.lineTo(1580f, 250f); roof.close(); c.drawPath(roof, p)
            val t1 = Path(); t1.moveTo(380f, 380f); t1.lineTo(480f, 190f); t1.lineTo(580f, 380f); t1.close(); c.drawPath(t1, p)
            c.drawRect(455f, 190f, 505f, 380f, p)
            val t2 = Path(); t2.moveTo(1480f, 340f); t2.lineTo(1600f, 140f); t2.lineTo(1720f, 340f); t2.close(); c.drawPath(t2, p)
            c.drawRect(1570f, 140f, 1630f, 340f, p)
            // chimney
            c.drawRect(1180f, 40f, 1240f, 150f, p)
            // windows
            for (r in 0 until 3) for (cI in 0 until 7) {
                val x = 590f + cI * 140f; val y = 310f + r * 130f
                val lit = Anim.hash(r * 11 + cI * 7) > 0.62f
                fill(p, if (lit) 0xFFFFB347.toInt() else 0xFF11141C.toInt()); c.drawRect(x, y, x + 52f, y + 80f, p)
                fill(p, 0xFF05060A.toInt()); c.drawRect(x + 24f, y, x + 28f, y + 80f, p); c.drawRect(x, y + 36f, x + 52f, y + 40f, p)
            }
            fill(p, 0xFFFFC861.toInt()); c.drawRect(1020f, 120f, 1060f, 190f, p)    // attic light
            fill(p, 0xFF05060A.toInt()); c.drawRect(1020f, 154f, 1060f, 158f, p)
            // door
            fill(p, 0xFF040508.toInt()); c.drawRoundRect(RectF(990f, 600f, 1090f, 760f), 40f, 40f, p)
        })
        m["fence"] = save(dir, "bg_fence.png", bmp(1920, 360) { c, p ->
            fill(p, 0xFF050608.toInt())
            c.drawRect(0f, 250f, 1920f, 262f, p); c.drawRect(0f, 120f, 1920f, 128f, p)
            var x = 0f; while (x < 1920f) { c.drawRect(x, 60f, x + 8f, 360f, p); val tip = Path(); tip.moveTo(x - 4f, 60f); tip.lineTo(x + 4f, 28f); tip.lineTo(x + 12f, 60f); tip.close(); c.drawPath(tip, p); x += 54f }
            c.drawRect(1400f, 0f, 1470f, 360f, p); c.drawRect(1700f, 0f, 1770f, 360f, p)
            c.drawCircle(1435f, 0f, 30f, p); c.drawCircle(1735f, 0f, 30f, p)
        })
        m["ground"] = save(dir, "bg_ground.png", bmp(1920, 360) { c, p ->
            p.shader = LinearGradient(0f, 0f, 0f, 360f, intArrayOf(0xFF1A2029.toInt(), 0xFF07090C.toInt()), null, Shader.TileMode.CLAMP); c.drawRect(0f, 0f, 1920f, 360f, p); p.shader = null
            fill(p, 0x2230394A); c.drawOval(RectF(-200f, 40f, 2200f, 200f), p)
        })
        m["branches"] = save(dir, "fg_branches.png", bmp(1920, 520) { c, p ->
            fill(p, 0xFF020203.toInt()); p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND
            for (i in 0 until 14) {
                val sx = if (i % 2 == 0) 0f else 1920f; val dir = if (i % 2 == 0) 1f else -1f
                var x = sx; var y = -20f + i * 8f; var w = 26f - i; var a = 0.5f + Anim.hash(i) * 0.7f
                for (s in 0 until 9) { p.strokeWidth = max(2f, w); val nx = x + dir * (60f + Anim.hash(i * 9 + s) * 90f); val ny = y + 30f + Anim.hash(i * 5 + s) * 60f * a
                    c.drawLine(x, y, nx, ny, p); x = nx; y = ny; w *= 0.78f }
            }
        })
        m["grass"] = save(dir, "fg_grass.png", bmp(1920, 190) { c, p ->
            fill(p, 0xFF010202.toInt())
            var x = -10f; var i = 0
            while (x < 1950f) { val h = 70f + Anim.hash(i) * 120f; val t = Path(); t.moveTo(x, 190f); t.quadTo(x + 4f + Anim.hash(i + 1) * 20f, 190f - h * .6f, x + 10f + Anim.hash(i + 2) * 30f, 190f - h); t.lineTo(x + 18f, 190f); t.close(); c.drawPath(t, p); x += 14f; i++ }
            c.drawRect(0f, 170f, 1920f, 190f, p)
        })
        // ---- character parts (side view, facing right) ----
        m["head"] = save(dir, "head.png", bmp(134, 126) { c, p ->
            fill(p, skin); c.drawOval(RectF(6f, 0f, 108f, 124f), p)
            val nose = Path(); nose.moveTo(100f, 62f); nose.lineTo(128f, 84f); nose.lineTo(100f, 92f); nose.close(); c.drawPath(nose, p)
            fill(p, 0x22000000); c.drawOval(RectF(10f, 70f, 90f, 124f), p)
            fill(p, 0xFFB5A290.toInt()); c.drawOval(RectF(18f, 56f, 36f, 86f), p)
        })
        m["hairBack"] = save(dir, "hair_back.png", bmp(150, 176) { c, p ->
            fill(p, hair); c.drawOval(RectF(0f, 0f, 124f, 120f), p)
            val tail = Path(); tail.moveTo(6f, 50f); tail.cubicTo(-4f, 120f, 10f, 160f, 40f, 176f); tail.cubicTo(70f, 150f, 80f, 110f, 90f, 60f); tail.close(); c.drawPath(tail, p)
        })
        m["hairFront"] = save(dir, "hair_front.png", bmp(124, 56) { c, p ->
            fill(p, hair); val f = Path(); f.moveTo(0f, 56f); f.cubicTo(0f, 0f, 90f, -10f, 124f, 30f); f.lineTo(112f, 34f); f.cubicTo(80f, 18f, 40f, 24f, 20f, 56f); f.close(); c.drawPath(f, p)
        })
        m["eyeOpen"] = save(dir, "eye_open.png", bmp(26, 22) { c, p -> fill(p, 0xFFF2F2F2.toInt()); c.drawOval(RectF(0f, 0f, 26f, 22f), p); fill(p, 0xFF10121A.toInt()); c.drawCircle(18f, 11f, 7f, p); fill(p, 0xFFFFFFFF.toInt()); c.drawCircle(20f, 8f, 2f, p) })
        m["eyeHalf"] = save(dir, "eye_half.png", bmp(26, 22) { c, p -> fill(p, 0xFFF2F2F2.toInt()); c.drawOval(RectF(0f, 6f, 26f, 18f), p); fill(p, 0xFF10121A.toInt()); c.drawCircle(18f, 12f, 5f, p); fill(p, skin); c.drawRect(0f, 0f, 26f, 8f, p) })
        m["eyeClosed"] = save(dir, "eye_closed.png", bmp(26, 22) { c, p -> fill(p, 0xFF2A2018.toInt()); c.drawRoundRect(RectF(1f, 10f, 25f, 14f), 2f, 2f, p) })
        m["brow"] = save(dir, "brow.png", bmp(34, 10) { c, p -> fill(p, hair); c.drawRoundRect(RectF(0f, 1f, 34f, 9f), 4f, 4f, p) })
        val mouthSpecs = listOf("closed", "small", "medium", "wide", "smile", "fear")
        mouthSpecs.forEachIndexed { i, n ->
            m["mouth_$n"] = save(dir, "mouth_$n.png", bmp(50, 34) { c, p ->
                fill(p, 0xFF2B0D12.toInt()); p.strokeCap = Paint.Cap.ROUND
                when (i) {
                    0 -> { p.style = Paint.Style.STROKE; p.strokeWidth = 4f; p.color = 0xFF3A1A1A.toInt(); c.drawLine(8f, 17f, 42f, 17f, p) }
                    1 -> c.drawOval(RectF(14f, 11f, 36f, 23f), p)
                    2 -> { c.drawOval(RectF(10f, 7f, 40f, 27f), p); fill(p, 0xFFB04A55.toInt()); c.drawOval(RectF(16f, 17f, 34f, 26f), p) }
                    3 -> { c.drawOval(RectF(6f, 2f, 44f, 32f), p); fill(p, 0xFFF0F0F0.toInt()); c.drawRect(14f, 4f, 36f, 9f, p); fill(p, 0xFFB04A55.toInt()); c.drawOval(RectF(14f, 20f, 36f, 31f), p) }
                    4 -> { p.style = Paint.Style.STROKE; p.strokeWidth = 4f; p.color = 0xFF3A1A1A.toInt(); val a = Path(); a.moveTo(6f, 12f); a.quadTo(25f, 32f, 44f, 12f); c.drawPath(a, p) }
                    else -> { c.drawOval(RectF(8f, 3f, 42f, 33f), p); fill(p, 0xFFF0F0F0.toInt()); c.drawRect(14f, 5f, 36f, 10f, p); c.drawRect(14f, 25f, 36f, 30f, p) }
                }
            })
        }
        m["torso"] = save(dir, "torso.png", bmp(104, 178) { c, p ->
            fill(p, coat); c.drawRoundRect(RectF(0f, 0f, 104f, 178f), 26f, 26f, p)
            fill(p, coatLight); c.drawRoundRect(RectF(60f, 8f, 100f, 170f), 20f, 20f, p)
            fill(p, 0xFF0C0F15.toInt()); c.drawRect(0f, 120f, 104f, 130f, p); fill(p, 0xFF8A7440.toInt()); c.drawRect(44f, 118f, 60f, 132f, p)
            fill(p, 0xFF0C0F15.toInt()); c.drawRect(50f, 30f, 53f, 120f, p)
        })
        m["upperArm"] = save(dir, "arm_upper.png", bmp(40, 100) { c, p -> fill(p, coat); c.drawRoundRect(RectF(0f, 0f, 40f, 100f), 18f, 18f, p); fill(p, coatLight); c.drawRoundRect(RectF(22f, 6f, 36f, 94f), 8f, 8f, p) })
        m["forearm"] = save(dir, "arm_fore.png", bmp(36, 94) { c, p -> fill(p, coat); c.drawRoundRect(RectF(0f, 0f, 36f, 94f), 16f, 16f, p); fill(p, 0xFF0C0F15.toInt()); c.drawRect(0f, 80f, 36f, 90f, p) })
        m["hand"] = save(dir, "hand.png", bmp(32, 40) { c, p -> fill(p, skin); c.drawRoundRect(RectF(2f, 0f, 30f, 38f), 12f, 12f, p); c.drawRoundRect(RectF(22f, 18f, 32f, 38f), 5f, 5f, p) })
        m["thigh"] = save(dir, "thigh.png", bmp(54, 132) { c, p -> fill(p, pants); c.drawRoundRect(RectF(0f, 0f, 54f, 132f), 22f, 22f, p); fill(p, 0x22FFFFFF); c.drawRoundRect(RectF(34f, 8f, 48f, 120f), 8f, 8f, p) })
        m["shin"] = save(dir, "shin.png", bmp(48, 124) { c, p -> fill(p, pants); c.drawRoundRect(RectF(0f, 0f, 48f, 124f), 18f, 18f, p); fill(p, 0x22FFFFFF); c.drawRoundRect(RectF(30f, 8f, 42f, 110f), 6f, 6f, p) })
        m["foot"] = save(dir, "foot.png", bmp(94, 40) { c, p -> fill(p, shoe); val f = Path(); f.moveTo(10f, 0f); f.lineTo(40f, 0f); f.lineTo(70f, 14f); f.quadTo(94f, 20f, 92f, 34f); f.lineTo(4f, 38f); f.quadTo(-2f, 18f, 10f, 0f); f.close(); c.drawPath(f, p) })
        m["scarf"] = save(dir, "scarf.png", bmp(84, 38) { c, p -> fill(p, scarfC); c.drawRoundRect(RectF(0f, 0f, 84f, 38f), 18f, 18f, p); fill(p, 0x33000000); c.drawRoundRect(RectF(6f, 20f, 78f, 34f), 8f, 8f, p) })
        m["scarfTail"] = save(dir, "scarf_tail.png", bmp(36, 150) { c, p -> fill(p, scarfC); val t = Path(); t.moveTo(0f, 0f); t.lineTo(36f, 0f); t.lineTo(30f, 150f); t.lineTo(18f, 138f); t.lineTo(6f, 150f); t.close(); c.drawPath(t, p); fill(p, 0x33000000); c.drawRect(24f, 0f, 34f, 140f, p) })
        return m
    }

    private fun voiceWav(file: File, seconds: Float) {
        val n = (seconds * SR).toInt(); val d = FloatArray(n)
        var phase = 0.0
        for (i in 0 until n) {
            val t = i / SR.toFloat(); val syl = floor(t * 4.6f).toInt(); val u = t * 4.6f - syl
            val pause = Anim.hash2(syl / 5, 9) < 0.2f || (syl % 9 == 8)
            val env = if (pause) 0f else sin(PI.toFloat() * u).pow(0.6f) * (0.4f + 0.6f * Anim.hash2(syl, 4))
            val f0 = 105f + 28f * Anim.hash2(syl, 2) + 8f * sin(t * 3f)
            phase += 2.0 * PI * f0 / SR
            var s = 0f
            for (h in 1..9) s += sin(phase * h).toFloat() / h * (if (h in 3..5) 1.4f else 1f)
            d[i] = s * env * 0.4f + (Anim.hash(i) - .5f) * 0.03f * env
        }
        Sfx.wav(file, d)
    }

    // ------------------------------------------------------------------ rig builder
    private class Parts(val a: Map<String, String>)

    private fun lay(sc: Scene, name: String, file: String, w: Int, h: Int, ch: Character, bone: Bone?, x: Float, y: Float, rot: Float, px: Float, py: Float): Layer {
        val l = Layer(newId(), name); l.image = file; l.imgW = w; l.imgH = h; l.px = px; l.py = py
        l.charId = ch.id; l.boneId = bone?.id ?: ""; l.x = x; l.y = y; l.rot = rot; l.depth = 50f
        sc.layers.add(l); return l
    }

    fun buildCharacter(p: Project, sc: Scene, a: Map<String, String>, name: String, x: Float, y: Float, ghost: Boolean): Character {
        val ch = Character(newId(), name); ch.x = x; ch.y = y
        sc.characters.add(ch)
        RigTools.createHumanoid(sc, ch, true)
        sc.bones.removeAll { it.charId == ch.id && (it.role == "hair" || it.role == "scarf" || it.role == "coat") }
        fun b(role: String) = sc.boneByRole(ch.id, role)!!
        val head = b("head"); val spine = b("spine"); val neck = b("neck")
        val first = sc.layers.size
        // far side (L) behind the body, tinted darker
        lay(sc, "Hair Back", a["hairBack"]!!, 150, 176, ch, head, 74f, -26f, 90f, .5f, .5f).also { it.swayAmt = 9f; it.swaySpeed = 0.9f }
        lay(sc, "Left Upper Arm", a["upperArm"]!!, 40, 100, ch, b("armL1"), 0f, 0f, -90f, .5f, .1f).tint = 0xFF9AA0AA.toInt()
        lay(sc, "Left Forearm", a["forearm"]!!, 36, 94, ch, b("armL2"), 0f, 0f, -90f, .5f, .08f).tint = 0xFF9AA0AA.toInt()
        lay(sc, "Left Hand", a["hand"]!!, 32, 40, ch, b("handL"), 0f, 0f, -90f, .5f, .05f).tint = 0xFF9AA0AA.toInt()
        lay(sc, "Left Thigh", a["thigh"]!!, 54, 132, ch, b("legL1"), 0f, 0f, -90f, .5f, .06f).tint = 0xFF8A8F99.toInt()
        lay(sc, "Left Lower Leg", a["shin"]!!, 48, 124, ch, b("legL2"), 0f, 0f, -90f, .5f, .05f).tint = 0xFF8A8F99.toInt()
        lay(sc, "Left Foot", a["foot"]!!, 94, 40, ch, b("footL"), 0f, 0f, 0f, .28f, .18f).tint = 0xFF8A8F99.toInt()
        lay(sc, "Right Thigh", a["thigh"]!!, 54, 132, ch, b("legR1"), 0f, 0f, -90f, .5f, .06f)
        lay(sc, "Right Lower Leg", a["shin"]!!, 48, 124, ch, b("legR2"), 0f, 0f, -90f, .5f, .05f)
        lay(sc, "Right Foot", a["foot"]!!, 94, 40, ch, b("footR"), 0f, 0f, 0f, .28f, .18f)
        lay(sc, "Torso", a["torso"]!!, 104, 178, ch, spine, 0f, 0f, 90f, .5f, .86f)
        lay(sc, "Scarf Tail", a["scarfTail"]!!, 36, 150, ch, spine, 124f, 14f, 90f, .5f, .03f).also { it.swayAmt = 14f; it.swaySpeed = 1.1f }
        lay(sc, "Head", a["head"]!!, 134, 126, ch, head, 63f, 6f, 90f, .5f, .5f)
        lay(sc, "Scarf", a["scarf"]!!, 84, 38, ch, neck, 8f, 0f, 90f, .5f, .5f).also { it.swayAmt = 3f }
        lay(sc, "Hair Front", a["hairFront"]!!, 124, 56, ch, head, 108f, 2f, 90f, .5f, .5f)
        for ((i, side) in listOf("L" to 14f, "R" to 48f).withIndex()) {
            val e = lay(sc, "${if (side.first == "L") "Left" else "Right"} Eye", a["eyeOpen"]!!, 26, 22, ch, head, 66f, side.second, 90f, .5f, .5f)
            e.role = "eye"; e.side = side.first; e.states = mutableListOf(a["eyeOpen"]!!, a["eyeHalf"]!!, a["eyeClosed"]!!)
            val br = lay(sc, "${if (side.first == "L") "Left" else "Right"} Brow", a["brow"]!!, 34, 10, ch, head, 88f, side.second + (if (i == 1) 2f else 0f), 90f, .5f, .5f)
            br.role = "brow"; br.side = side.first
        }
        lay(sc, "Mouth", a["mouth_closed"]!!, 50, 34, ch, head, 30f, 38f, 90f, .5f, .5f).also {
            it.role = "mouth"; it.states = listOf("closed", "small", "medium", "wide", "smile", "fear").map { n -> a["mouth_$n"]!! }.toMutableList() }
        lay(sc, "Right Upper Arm", a["upperArm"]!!, 40, 100, ch, b("armR1"), 0f, 0f, -90f, .5f, .1f)
        lay(sc, "Right Forearm", a["forearm"]!!, 36, 94, ch, b("armR2"), 0f, 0f, -90f, .5f, .08f)
        lay(sc, "Right Hand", a["hand"]!!, 32, 40, ch, b("handR"), 0f, 0f, -90f, .5f, .05f)
        if (ghost) sc.layers.drop(first).forEach { l ->
            l.ghost = true; l.opacity = 0.9f
            if (l.tint == 0 || true) l.tint = 0xFFBFD3FF.toInt()
            l.blend = if (l.role == "") Blend.NORMAL else Blend.NORMAL
        }
        // IK end bones (feet & hands) for the IK tool
        b("legL2").ikLen = 2; b("legR2").ikLen = 2; b("armL2").ikLen = 2; b("armR2").ikLen = 2
        return ch
    }

    private fun clip(sc: Scene, ch: Character, preset: String, start: Float, dur: Float, edit: (ProcClip) -> Unit = {}): ProcClip {
        val c = ProcClip(newId(), ch.id, preset); c.start = start; c.duration = dur; c.params = Presets.defaultParams(preset); edit(c); sc.clips.add(c); return c
    }
    private fun key(sc: Scene, target: String, prop: String, vararg tv: Pair<Float, Float>, ease: Ease = Ease.EASE_IN_OUT) {
        val tr = sc.trackOrCreate(target, prop); tv.forEach { Anim.setKey(tr, it.first, it.second, ease) }
    }
    private fun bgLayers(sc: Scene, a: Map<String, String>) {
        fun add(name: String, f: String, w: Int, h: Int, x: Float, y: Float, depth: Float, py: Float = 0f): Layer {
            val l = Layer(newId(), name); l.image = f; l.imgW = w; l.imgH = h; l.px = 0.5f; l.py = py; l.x = x; l.y = y; l.depth = depth; sc.layers.add(l); return l }
        add("Sky", a["sky"]!!, 1920, 1080, 960f, 540f, 160f, 0.5f).also { it.sx = 1.25f; it.sy = 1.25f }
        add("Mansion", a["mansion"]!!, 1920, 760, 960f, 880f, 100f, 1f).also { it.sx = 1.1f; it.sy = 1.1f }
        add("Ground", a["ground"]!!, 1920, 360, 960f, 1080f, 62f, 1f).also { it.sx = 1.3f; it.sy = 1f }
        add("Gate Fence", a["fence"]!!, 1920, 360, 960f, 930f, 74f, 1f).also { it.sx = 1.2f }
        sc.layers.first { it.name == "Sky" }.opacity = 1f
    }
    private fun fgLayers(sc: Scene, a: Map<String, String>) {
        fun add(name: String, f: String, w: Int, h: Int, x: Float, y: Float, depth: Float, py: Float): Layer {
            val l = Layer(newId(), name); l.image = f; l.imgW = w; l.imgH = h; l.px = 0.5f; l.py = py; l.x = x; l.y = y; l.depth = depth; sc.layers.add(l); return l }
        add("Foreground Branches", a["branches"]!!, 1920, 520, 960f, -20f, 20f, 0f).also { it.sx = 1.3f; it.sy = 1.2f }
        add("Foreground Grass", a["grass"]!!, 1920, 190, 960f, 1110f, 20f, 1f).also { it.sx = 1.4f; it.sy = 1.2f }
    }
    private fun mood(sc: Scene, rain: Float, fog: Float) {
        sc.effects.add(FxDefs.create(FxType.FOG).also { it.params["density"] = fog; it.params["height"] = 0.5f; it.intensity = 1f })
        sc.effects.add(FxDefs.create(FxType.RAIN).also { it.params["density"] = rain; it.params["speed"] = 1700f; it.params["opacity"] = 0.5f })
        sc.effects.add(FxDefs.create(FxType.GRADE)); sc.effects.add(FxDefs.create(FxType.VIGNETTE)); sc.effects.add(FxDefs.create(FxType.GRAIN))
        sc.effects.add(FxDefs.create(FxType.WIND).also { it.params["strength"] = 0.45f })
        sc.ambient = 0.55f
    }

    // ------------------------------------------------------------------ the project
    fun create(ctx: Context, repo: ProjectRepo): String {
        val p = repo.create("Sample – The Gate", 1920, 1080, 30)
        val dir = repo.assetsDir(p.id)
        val a = art(dir)
        p.assets.addAll(a.values)
        val sfx = HashMap<String, String>()
        for (n in listOf("Rain loop", "Horror drone", "Thunder", "Footsteps (walk loop)", "Jump scare hit", "Heartbeat", "Gate squeak")) sfx[n] = Sfx.generate(n, dir).also { p.assets.add(it) }
        val voice = File(dir, "sample_voice.wav"); voiceWav(voice, 7f); p.assets.add(voice.name)
        fun dur(f: String) = AudioDecoder.durationSeconds(File(dir, f))
        fun audio(sc: Scene, file: String, name: String, kind: AudioKind, start: Float, len: Float? = null, gain: Float = 1f, loop: Boolean = false): AudioClip {
            val c = AudioClip(newId(), file, name); c.kind = kind; c.start = start; c.sourceLen = dur(file); c.length = len ?: c.sourceLen; c.gain = gain; c.loop = loop; sc.audio.add(c); return c }

        // ================= Scene 1 : the walk =================
        val s1 = p.scenes[0]; s1.name = "1 · Walk to the gate"; s1.duration = 12f
        bgLayers(s1, a)
        val vik = buildCharacter(p, s1, a, "Vikram", 140f, 600f, false); fgLayers(s1, a)
        // order: keep foreground last (already added after character)
        mood(s1, 1.3f, 0.8f)
        val lg = FxDefs.create(FxType.LIGHTNING).also { it.params["auto"] = 0f; it.intensity = 1f }
        s1.effects.add(lg)
        key(s1, lg.id, "intensity", 0f to 0f, 7.99f to 0f, 8.03f to 1f, 8.12f to 0.15f, 8.2f to 0.85f, 8.5f to 0f, ease = Ease.LINEAR)
        s1.lights.add(Light(newId(), LightType.LANTERN).also { it.name = "Gate lantern"; it.x = 1440f; it.y = 560f; it.radius = 520f; it.flicker = 0.35f; it.intensity = 1.1f })
        val handR = s1.boneByRole(vik.id, "handR")!!
        s1.lights.add(Light(newId(), LightType.FLASHLIGHT).also { it.name = "Flashlight"; it.followChar = vik.id; it.followBone = handR.id; it.x = 0f; it.y = 0f; it.angle = -78f; it.radius = 620f; it.cone = 20f; it.color = 0xFFFFF2CC.toInt(); it.flicker = 0.1f })
        clip(s1, vik, "Walking", 0f, 6.2f) { it.params["speed"] = 0.5f; it.params["travel"] = 215f; it.params["stride"] = 24f; it.fade = 0.5f }
        clip(s1, vik, "Idle", 6.2f, 5.8f) { it.fade = 0.6f }
        clip(s1, vik, "Looking Around", 6.4f, 4.5f) { it.fade = 0.6f }
        clip(s1, vik, "Blinking", 0f, 12f)
        s1.camera.handheld = 0.5f; s1.camera.parallax = 1.2f; s1.camera.followChar = vik.id; s1.camera.followAmt = 0.45f; s1.camera.followOffY = -230f; s1.camera.followLag = 0.6f
        key(s1, "cam", "zoom", 0f to 1.0f, 6f to 1.1f, 12f to 1.32f, ease = Ease.EASE_IN_OUT)
        audio(s1, sfx["Rain loop"]!!, "Rain", AudioKind.AMBIENT, 0f, 12f, 0.5f, true)
        audio(s1, sfx["Horror drone"]!!, "Drone", AudioKind.MUSIC, 0f, 12f, 0.55f, true)
        audio(s1, sfx["Footsteps (walk loop)"]!!, "Footsteps", AudioKind.SFX, 0.15f, 6f, 0.8f, true)
        audio(s1, sfx["Thunder"]!!, "Thunder", AudioKind.SFX, 8.15f, null, 1f)

        // ================= Scene 2 : talking =================
        val s2 = Scene(newId(), "2 · He speaks"); s2.duration = 9f; p.scenes.add(s2)
        bgLayers(s2, a)
        val v2 = buildCharacter(p, s2, a, "Vikram", 720f, 640f, false); fgLayers(s2, a)
        mood(s2, 0.7f, 0.6f); s2.ambient = 0.5f
        s2.lights.add(Light(newId(), LightType.LANTERN).also { it.name = "Gate lantern"; it.x = 1440f; it.y = 560f; it.radius = 480f; it.flicker = 0.3f })
        s2.lights.add(Light(newId(), LightType.BULB).also { it.name = "Window glow"; it.x = 1040f; it.y = 600f; it.radius = 380f; it.flicker = 0.55f; it.color = 0xFFFFC861.toInt() })
        clip(s2, v2, "Idle", 0f, 9f); clip(s2, v2, "Blinking", 0f, 9f)
        val vc = audio(s2, voice.name, "Voice (synthetic demo)", AudioKind.VOICE, 0.6f, 6.4f, 1f); vc.charId = v2.id
        clip(s2, v2, "Talking", 0.6f, 6.4f) { it.params["rate"] = 4.6f; it.fade = 0.2f }   // gesturing, head & brow motion
        run { val pcm = AudioDecoder.get(File(dir, voice.name))!!; LipSync.generate(s2, vc, v2.id, pcm) }   // audio-driven mouth keyframes (overrides procedural mouth)
        clip(s2, v2, "Pointing", 5.4f, 2.0f) { it.params["side"] = 0f }
        clip(s2, v2, "Fear Reaction", 7.4f, 1.6f)
        key(s2, "cam", "zoom", 0f to 1f, 1.2f to 1f, 4.5f to 1.85f, 9f to 2.0f)
        key(s2, "cam", "x", 0f to 960f, 1.2f to 960f, 4.5f to 760f, 9f to 770f)
        key(s2, "cam", "y", 0f to 540f, 1.2f to 540f, 4.5f to 360f, 9f to 370f)
        s2.camera.handheld = 0.7f; s2.camera.dof = 0.8f; s2.camera.focusDepth = 50f
        key(s2, "cam", "shake", 0f to 0f, 7.35f to 0f, 7.4f to 1f, 8.2f to 0.4f, 9f to 0f, ease = Ease.LINEAR)
        audio(s2, sfx["Rain loop"]!!, "Rain", AudioKind.AMBIENT, 0f, 9f, 0.45f, true)
        audio(s2, sfx["Horror drone"]!!, "Drone", AudioKind.MUSIC, 0f, 9f, 0.5f, true)
        audio(s2, sfx["Heartbeat"]!!, "Heartbeat", AudioKind.SFX, 7.4f, null, 1f)

        // ================= Scene 3 : the ghost =================
        val s3 = Scene(newId(), "3 · The ghost"); s3.duration = 9f; p.scenes.add(s3)
        bgLayers(s3, a)
        val v3 = buildCharacter(p, s3, a, "Vikram", 520f, 640f, false)
        val gh = buildCharacter(p, s3, a, "Ghost", 1330f, 640f, true)
        gh.sx = -1.2f; gh.sy = 1.2f
        fgLayers(s3, a)
        mood(s3, 2.2f, 1.2f); s3.ambient = 0.62f
        s3.effects.add(FxDefs.create(FxType.GHOST)); s3.effects.add(FxDefs.create(FxType.GHOST_DISTORT))
        s3.effects.add(FxDefs.create(FxType.SHADOW_MOVE).also { it.intensity = 0.7f })
        s3.effects.add(FxDefs.create(FxType.CHROMATIC).also { it.intensity = 0.5f })
        s3.effects.add(FxDefs.create(FxType.FLICKER).also { it.intensity = 0.3f })
        val glitch = FxDefs.create(FxType.GLITCH).also { it.intensity = 0f }; s3.effects.add(glitch)
        key(s3, glitch.id, "intensity", 0f to 0f, 4.9f to 0f, 5f to 1f, 5.8f to 1f, 5.9f to 0f, ease = Ease.LINEAR)
        val rf = FxDefs.create(FxType.RED_FLASH).also { it.intensity = 0f }; s3.effects.add(rf)
        key(s3, rf.id, "intensity", 0f to 0f, 4.98f to 0f, 5.02f to 1f, 5.5f to 0f, 6.5f to 0f, 6.55f to 0.8f, 7.1f to 0f, ease = Ease.LINEAR)
        val bl = FxDefs.create(FxType.BLOOD).also { it.intensity = 0f }; s3.effects.add(bl)
        key(s3, bl.id, "intensity", 0f to 0f, 5f to 0f, 6.5f to 0.7f, 9f to 0.9f)
        s3.lights.add(Light(newId(), LightType.CANDLE).also { it.name = "Candle"; it.x = 640f; it.y = 640f; it.radius = 340f; it.flicker = 0.6f })
        key(s3, gh.id, "opacity", 0f to 0f, 1.0f to 0f, 3.0f to 0.85f, 9f to 0.95f)
        key(s3, gh.id, "x", 0f to 1500f, 3f to 1330f, 9f to 1050f)
        clip(s3, gh, "Idle", 0f, 9f) { it.params["breath"] = 2f }
        clip(s3, gh, "Slow Walking", 3f, 6f) { it.params["travel"] = -60f; it.params["speed"] = 0.35f }
        clip(s3, v3, "Idle", 0f, 3.2f); clip(s3, v3, "Looking Around", 1f, 2.5f) { it.params["range"] = 0.5f }
        clip(s3, v3, "Fear Reaction", 4.0f, 5f) { it.params["intensity"] = 1.3f; it.params["tremble"] = 2f }
        clip(s3, v3, "Blinking", 0f, 9f)
        key(s3, v3.id, "lookx", 0f to 0f, 3.2f to 0f, 3.8f to 1f)
        key(s3, "cam", "zoom", 0f to 1f, 4.9f to 1.05f, 5.0f to 1.25f, 5.35f to 1.7f, 7f to 1.75f, 9f to 1.2f, ease = Ease.EASE_OUT)
        key(s3, "cam", "x", 0f to 960f, 5f to 1050f, 9f to 1100f); key(s3, "cam", "y", 0f to 540f, 5f to 430f, 9f to 460f)
        key(s3, "cam", "shake", 0f to 0f, 4.95f to 0f, 5f to 1.4f, 6f to 0.6f, 9f to 0.15f, ease = Ease.LINEAR)
        s3.camera.handheld = 0.5f
        audio(s3, sfx["Rain loop"]!!, "Rain", AudioKind.AMBIENT, 0f, 9f, 0.55f, true)
        audio(s3, sfx["Horror drone"]!!, "Drone", AudioKind.MUSIC, 0f, 9f, 0.6f, true)
        audio(s3, sfx["Jump scare hit"]!!, "Stinger", AudioKind.SFX, 5f, null, 0.9f)
        audio(s3, sfx["Heartbeat"]!!, "Heartbeat", AudioKind.SFX, 5.2f, null, 1f)
        audio(s3, sfx["Gate squeak"]!!, "Gate", AudioKind.SFX, 1.5f, null, 0.6f)

        repo.save(p)
        return p.id
    }
}
